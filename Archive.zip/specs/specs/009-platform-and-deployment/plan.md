# Implementation Plan: Platform and deployment

## Technical Context
**Platform**: Kubernetes 1.30+ or OpenShift 4.16+ · **Packaging**: Helm 3 · **CI**: build, scan, sign images; deploy via GitOps (Argo CD) [NEEDS CLARIFICATION: CI/CD and GitOps tools in use] · **DB**: PostgreSQL 16 (operator-managed) · **Auth**: corporate OIDC

## Constitution Check
VII SoD for admins ✅ · II hash chain verified ✅

## Structure
```
deploy/helm/smokey/ (api, apps, jobs, reconciler, networkpolicies)
deploy/demo/        (existing smokey/deploy: static demo)
```
