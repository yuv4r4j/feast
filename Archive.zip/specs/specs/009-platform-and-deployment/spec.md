# Feature Specification: Platform, security and deployment

**Feature Branch**: `009-platform-and-deployment` · **Created**: 2026-11-22 · **Status**: Draft
**Input**: "How to deploy this demo in Kubernetes"; administrator console design (X1, X2).

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Deploy to Kubernetes or OpenShift (Priority: P1)
Operators deploy the API, apps, jobs and reconciler with one command per environment.

**Independent Test**: `make deploy ENV=nonprod` brings all services to ready; health checks pass.

### User Story 2 - Access with second approval (Priority: P1)
Role grants need a second approver; administrators cannot hold governance roles.

### User Story 3 - Platform status against objectives (Priority: P2)
The admin console shows each integration (Feast, MLflow, cluster, Driverless AI, IdP, database) against its objective, and verifies the event hash chain and backups.

### User Story 4 - Demo deployment (Priority: P3)
The static walkthrough demo deploys behind SSO using `smokey/deploy`.

## Requirements *(mandatory)*
- **FR-001**: Container images for api, apps (4), jobs, reconciler; non-root, read-only file systems, resource limits.
- **FR-002**: Helm chart or Kustomize overlays per environment; secrets from the cluster secret store; NetworkPolicies default-deny.
- **FR-003**: OIDC single sign-on for all apps; service identities for jobs and the reconciler (cluster read-only).
- **FR-004**: PostgreSQL with point-in-time recovery; daily backup restore test.
- **FR-005**: GrantRole requires a second approver; administrators are excluded from governance roles.
- **FR-006**: Audit: hash-chain verification job daily; alerts on break.

## Success Criteria *(mandatory)*
- **SC-001**: Fresh environment from zero to ready in under 30 minutes.
- **SC-002**: Restore test passes daily; recovery point objective 15 minutes. [NEEDS CLARIFICATION: RPO/RTO targets]
