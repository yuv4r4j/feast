# Tasks: Platform and deployment

## Phase 1: Setup
- [ ] T001 Dockerfiles (non-root) in `docker/` for api, apps, jobs, reconciler
- [ ] T002 Helm chart in `deploy/helm/smokey/` with `values-nonprod.yaml`, `values-prod.yaml`; NetworkPolicies
- [ ] T003 `Makefile` with `deploy ENV=<env>` wrapping `helm upgrade --install`

## Phase 2: User Story 1 - Deploy (P1)
- [ ] T004 [US1] Non-production deployment; readiness and liveness checks on every service

**Checkpoint**: `make deploy ENV=nonprod` reaches ready from an empty namespace

## Phase 3: User Story 2 - Access (P1)
- [ ] T005 [P] [US2] Test N11: administrator excluded from governance roles; grant needs a second approver
- [ ] T006 [US2] GrantRole in `api/commands/grant_role.py`

## Phase 4: User Story 3 - Status (P2)
- [ ] T007 [US3] `apps/admin/pages/1_Status.py`: integrations against objectives, hash-chain verification, backup status
- [ ] T008 [US3] Daily restore-test and chain-verification CronJobs

## Phase 5: User Story 4 - Demo (P3)
- [ ] T009 [US4] Static demo behind SSO from `smokey/deploy`
