# Tasks: Lifecycle commands, governance and exceptions

## Phase 1: Setup
- [ ] T001 Command bus skeleton, OIDC auth, role resolution from `policy/roles.yaml`
- [ ] T002 [P] DB roles: append-only grants on `events`

## Phase 2: Foundational
- [ ] T003 Refusal type and rule registry
- [ ] T004 [P] Contract tests from `contracts/commands.yaml`
- [ ] T004a One test file per ID in `acceptance-tests.md` under `tests/acceptance/`, all failing first

## Phase 3: User Story 1 - Stages (P1)
- [ ] T005 [P] [US1] Negative tests IND-HIST-01, VAL-01, FND-CLOSE-01
- [ ] T006 [US1] Stage commands from RegisterModel to Approve
- [ ] T007 [US1] RecordReplication with tolerances blocking conclusion

## Phase 4: User Story 2 - Release authorisation (P1)
- [ ] T008 [P] [US2] Four pipeline attack tests (none, expired, wrong digest, wrong environment)
- [ ] T009 [US2] AuthoriseRelease with signing; pipeline verification step (shared action for CI)

## Phase 5: User Story 3 - Exceptions (P1)
- [ ] T010 [P] [US3] One test per condition E1–E9, open and close
- [ ] T011 [US3] Exception engine on event and on schedule

## Phase 6: User Story 4 - Breach disposition (P2)
- [ ] T012 [US4] AcknowledgeBreach, RecordDisposition (overlay, restrict, suspend, replace), RequestException, ConcurException

## Phase 6b: User Story 5 - Reviews, retirement, policy (P2)
- [ ] T012a [P] [US5] Tests: review dates recompute on TierApproved; RetireModel refused with live deployments; unapproved policy not activated
- [ ] T012b [US5] Review scheduler in `api/scheduler/reviews.py`
- [ ] T012c [US5] ProposeRetirement, RetireModel in `api/commands/retire.py`
- [ ] T012d [US5] Policy loader with PolicyActivated event in `api/policy/loader.py`
- [ ] T012e [US5] Vendor model record fields and stage checks (FR-012)

## Phase 7: Polish
- [ ] T013 Read-model rebuild and checksum comparison
- [ ] T014 Hash-chain verification endpoint for administrators
