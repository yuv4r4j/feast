# Data model (shared by all features)

All tables below are read models rebuilt from `events` unless marked *source*.

## events *(source)*
| column | type | notes |
|---|---|---|
| seq | bigint pk | monotonic |
| ts | timestamptz | |
| actor | text | OIDC subject |
| role | text | role used |
| command | text | e.g. ApproveTiering |
| aggregate | text | model key, tool ID or policy |
| payload | jsonb | validated by command schema |
| rule_version | text | policy version applied |
| prev_hash / hash | bytea | SHA-256 chain |

## models / versions
model_id (uuid, stable, never displayed) · key (unique, e.g. QCE05) · model_name (QCE) · counter · previous_key · legacy_name · reservation_state (reserved, released, withdrawn) · the 40 inventory columns · proposed additions (see 001 FR-002) · stage · approval_state · approval_expiry

## tiers
key · impact · uncertainty · implementation · score · proposed_tier · in_force_tier · floor · override · policy_version · attested_at

## monitoring
key · month · psi · ks_drop · csi_by_feature (jsonb) · ed_ratio · ed_maturity · dd_ratio · band per metric · mmr_status

## exceptions
id · condition (E1–E9) · key · opened_at · closed_at · evidence (event seqs)

## findings
id · key · severity · issued_by · owner · due · state (open, response awaiting verification, closed)

## authorisations
id · key · digest · environment · issued_by · signature · expires_at

## sources *(snapshots)*
feast_views · feast_features · model_features · mlflow_versions (registered model `smk-<model_id>`, version, alias, digest, `smokey.key` tag) · cluster_observations (namespace, digest, since)

## tools
tool_id · name · kind · business_unit · feeds_key · exposure · control_rating · control_status · last_attested · source_key

## queue_items
id · rule (R1–R4) · title · accountable · options · follow_up · state
