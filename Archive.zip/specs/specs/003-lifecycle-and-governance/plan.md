# Implementation Plan: Lifecycle commands, governance and exceptions

**Branch**: `003-lifecycle-and-governance` | **Spec**: [spec.md](./spec.md) | **Data model**: [data-model.md](./data-model.md) | **Contract**: [contracts/commands.yaml](./contracts/commands.yaml)

## Summary
A command bus in FastAPI: authenticate (OIDC), authorise by role and separation-of-duties policy, validate payload, evaluate rules, append event, update read models. An exception engine re-evaluates E1–E9 on every event and on a schedule.

## Technical Context
**Language**: Python 3.12 · **Dependencies**: FastAPI, Pydantic, SQLAlchemy, Authlib (OIDC), cryptography (authorisation signing), APScheduler · **Storage**: PostgreSQL 16 · **Testing**: pytest, schemathesis (contract), acceptance suite of 30 tests · **Constraints**: no UPDATE/DELETE on `events` (DB role without those grants)

## Constitution Check
I ✅ · II ✅ (append-only grants) · III ✅ (policy/*.yaml) · VII ✅ (SoD matrix in policy/roles.yaml) · XI ✅

## Structure
```
api/commands/       (one module per command; schema + rules)
api/rules/          (refusal rules keyed by ID)
api/exceptions/     (E1–E9 evaluators)
api/readmodels/
policy/roles.yaml  policy/sla.yaml  policy/exceptions.yaml
tests/acceptance/   (30 scenarios, 19 negative)
```

## Design notes
- Rules return `Refusal(rule, message, what_to_do)`; the UI shows them verbatim.
- Authorisation signing with a KMS-held key; the pipeline step verifies signature, digest, environment and expiry.
- Read models are projections; a rebuild command replays all events into fresh tables and compares checksums.
