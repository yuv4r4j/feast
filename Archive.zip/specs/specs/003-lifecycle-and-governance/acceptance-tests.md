# Acceptance tests (30; 19 negative)

Negative tests pass when the system refuses or flags. IDs are stable; each maps to one automated test in `tests/acceptance/`.

## Positive (11)
| ID | Test |
|---|---|
| A01 | RegisterModel creates a model with a key and an internal Model ID |
| A02 | CreateVersion reserves the next key under the same Model ID |
| A03 | A version moves from Experimenting to Approved with each step issued by the permitted role |
| A04 | RecordReplication within tolerance allows SubmitConclusion |
| A05 | AuthoriseRelease produces a signed authorisation; the pipeline deploys that digest |
| A06 | Read models rebuilt from the event log match the live read models (checksum) |
| A07 | ApproveTiering writes Model Risk Tier and recomputes review dates |
| A08 | RecordDisposition (overlay) records an interim control and updates the SVP queue item |
| A09 | The issuing validator closes a finding after verification |
| A10 | Reconciler closes E2 once alias, authorisation and cluster agree |
| A11 | AssignFollowUp tracks a follow-up to closure without changing model state |

## Negative: refusals (12)
| ID | Test | Rule |
|---|---|---|
| N01 | Code with a letter outside the standard is refused | NAME-01 |
| N02 | CreateVersion when the name has reached 99 is refused | NAME-02 |
| N03 | Validator who authored runs in the version history cannot be assigned | IND-HIST-01 |
| N04 | Validator cannot approve | VAL-01 |
| N05 | Owner cannot close a finding | FND-CLOSE-01 |
| N06 | ApproveTiering with an unattested input is refused | TIER-01 |
| N07 | Override that lowers a tier is refused | TIER-02 |
| N08 | Ensemble for a T1 or T2 model is refused | AML-02 |
| N09 | Feature on the protected-proxy list is refused | AML-01 |
| N10 | ReclassifyToTool on a statistical model is refused | SR 26-2 definition |
| N11 | An administrator cannot be granted a governance role; a grant without a second approver is refused | SOD-ADMIN-01 |
| N12 | A screen or API call that tries to set a status, tier or approval directly is refused | CMD-ONLY-01 |

## Negative: pipeline halts (4)
| ID | Test |
|---|---|
| N13 | Deployment with no authorisation halts |
| N14 | Deployment with an expired authorisation halts |
| N15 | Deployment of a digest other than the authorised one halts |
| N16 | Deployment to an environment other than the authorised one halts |

## Negative: flags (3)
| ID | Test |
|---|---|
| N17 | Moving an MLflow alias to an unapproved version and serving it opens E2 within one cycle |
| N18 | A monitoring report missed at the tier's frequency opens E6 and shows health Unknown |
| N19 | A live model whose approval lapsed opens E1 |
