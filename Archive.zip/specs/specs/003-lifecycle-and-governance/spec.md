# Feature Specification: Lifecycle commands, governance and exceptions

**Feature Branch**: `003-lifecycle-and-governance` · **Created**: 2026-11-22 · **Status**: Draft
**Input**: Design canvas pages D1–D4, V1–V5, G1–G3, O1–O3, Patterns, Action index.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Take a version from registration to approval (Priority: P1)
Developer, validator and approval authority move a version through stages with every step recorded as an event.

**Independent Test**: A tier 3 model goes Registered → Experimenting → Frozen → Evidence submitted → Intake accepted → In validation → Conclusion → Approved, each step by the permitted role only.

**Acceptance Scenarios**:
1. **Given** a validator who authored runs in the version's history, **When** they are assigned, **Then** AssignValidator is refused (IND-HIST-01).
2. **Given** a validator, **When** they try to approve, **Then** it is refused (VAL-01); they submit a conclusion instead.
3. **Given** a model owner, **When** they try to close a finding, **Then** it is refused (FND-CLOSE-01) and their update is recorded as a response awaiting verification.

### User Story 2 - Authorise a release, and only that release, to run (Priority: P1)
Approval produces a signed release authorisation naming the artifact digest and environment; the pipeline deploys only that digest.

**Independent Test**: Four pipeline attacks (no authorisation, expired, wrong digest, wrong environment) each halt.

### User Story 3 - Exceptions open and close by rule (Priority: P1)
The system evaluates conditions E1–E9 continuously and opens or closes exceptions with evidence.

**Acceptance Scenarios**:
1. **Given** a live model whose approval lapsed, **Then** E1 opens.
2. **Given** the cluster digest differs from the authorised digest, **Then** E2 opens within one reconciler cycle.
3. **Given** a monitoring report missed at the frequency the model's tier requires (monthly T1–T2, quarterly T3), **Then** E6 opens and health is Unknown. T4 models have no scheduled report and do not open E6.

### User Story 4 - Owners dispose of breaches (Priority: P2)
On a monitoring breach the owner chooses overlay, restrict, suspend or replace; the choice states who must agree and its effect on the SVP queue.

### User Story 5 - Reviews, retirement and policy changes (Priority: P2)
Periodic reviews fall due by tier; owners retire models; policy rules change by reviewed pull request.

**Acceptance Scenarios**:
1. **Given** TierApproved changes a model from T2 to T1, **Then** Next Periodic Review is recomputed on a 12-month cycle.
2. **Given** a model with live deployments, **When** RetireModel runs, **Then** it is refused until deployments are withdrawn.
3. **Given** a policy pull request without head of model risk approval, **Then** the policy loader refuses to activate it.

### Edge Cases
- Urgent use before validation: allowed only with a time-limited exception, added limits and monitoring (SR 26-2).
- Commands arriving out of order are refused with the current state named.
- Role changes take effect immediately; in-progress tasks are re-routed.

## Requirements *(mandatory)*
- **FR-001**: Every state change MUST be a command (see contracts/commands.yaml) that appends an event or returns a refusal with rule ID and the reason.
- **FR-002**: Lifecycle stages: Proposed, Registered, Experimenting, Frozen, Evidence submitted, Intake, In validation, Conclusion, Approved (with or without conditions), Release authorised, Deploying, Live, Retiring, Retired.
- **FR-003**: Separation of duties MUST be enforced server-side: developer, validator, approval authority, model owner, head of validation, head of model risk, model operations, IT administrator, SVP (read-only plus follow-ups).
- **FR-004**: Exception conditions: E1 live without valid approval · E2 unverified deployment · E3 overdue condition · E4 high-severity finding on live T1/T2 · E5 breach unacknowledged · E6 health unknown · E7 periodic review overdue · E8 stage over service level · E9 milestone forecast to miss.
- **FR-005**: Findings have severity, owner, due date; only the issuing validator closes after verification.
- **FR-006**: Release authorisations MUST be signed, name one digest and environment, and expire.
- **FR-007**: Validators MUST record replication results with tolerances; out-of-tolerance blocks the conclusion.
- **FR-008**: The event log MUST be hash-chained; an administrator can verify the chain but cannot change it.
- **FR-009**: A review scheduler MUST set Next Periodic Review from the tier (12, 24, 36 months; none for T4) and recompute on TierApproved; overdue opens E7.
- **FR-010**: ProposeRetirement and RetireModel commands; a retired model keeps its key and history.
- **FR-011**: Policy files under `policy/` change only by pull request approved by the head of model risk and the platform lead; activation appends a PolicyActivated event with the version and hash, and every later event records the policy version applied.
- **FR-012**: Vendor models (SR 26-2 section VII) follow the same stages; where code or data are withheld, the record MUST hold the vendor's conceptual-soundness material, the firm's own outcome analysis and ongoing monitoring.
- **FR-013**: The 30 acceptance tests are listed in [acceptance-tests.md](./acceptance-tests.md); the list is the definition of done for SC-001.

### Key Entities
See [data-model.md](./data-model.md).

## Success Criteria *(mandatory)*
- **SC-001**: The 30 acceptance tests in acceptance-tests.md pass, 19 of them negative (refusals and flags).
- **SC-002**: Every state on every screen traces to at least one event (no orphan state).
- **SC-003**: E2 raised within one reconciler cycle (≤ 5 minutes) in the slice test.
