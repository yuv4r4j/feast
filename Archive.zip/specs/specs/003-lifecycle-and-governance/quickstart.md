# Quickstart: first vertical slice

Goal: one real tier 3 model from registration to a monitored non-production deployment, three people in three roles.

1. Seed the synthetic portfolio (`make seed`), then register the real model: `POST /commands/RegisterModel` → key issued.
2. Developer: CreateVersion → (optional AutoML experiment) → FreezeCandidate → SubmitEvidence.
3. Head of validation: AssignValidator (try the developer first: expect IND-HIST-01).
4. Validator: AcceptIntake → RecordReplication → IssueFinding → SubmitConclusion (try Approve: expect VAL-01).
5. Approval authority: Approve → AuthoriseRelease for non-production.
6. Pipeline: deploy; run the four attack cases (N13–N16), each must halt.
7. Move the MLflow alias by hand to another version and serve it: E2 within one reconciler cycle (N17).
8. Run the monitoring job; the model sheet shows a verdict.
9. Run `pytest tests/acceptance`: 30 pass.
