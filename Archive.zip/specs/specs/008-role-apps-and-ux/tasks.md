# Tasks: Role apps and UX

## Phase 1: Setup
- [ ] T001 `.streamlit/config.toml` theme; Streamlit ≥ 1.42 pinned in `requirements.txt`
- [ ] T002 Components in `apps/common/components/`: `model_sheet.py`, `tier_card.py`, `inventory_record.py`, `monitor_panel.py`, `refusal.py`, `look_for.py`

## Phase 2: User Story 1 - Role homes (P1)
- [ ] T003 [US1] `apps/common/auth.py`: `st.login`, roles from the API, page filtering
- [ ] T004 [P] [US1] `tests/ui/test_routing.py`: validator, SVP and administrator landings

## Phase 3: User Story 2 - Calm screens (P1)
- [ ] T005 [P] [US2] Look-for, verdict-first and fold patterns applied to every page
- [ ] T006 [P] [US2] `tests/ui/test_a11y.py`: Playwright + axe at 1440 and 390 px, reduced motion

**Checkpoint**: zero critical axe violations

## Phase 4: User Story 3 - Refusals (P1)
- [ ] T007 [US3] Refusal component wired to API 409 responses; test N12

## Phase 5: User Story 4 - Walkthroughs (P3)
- [ ] T008 [US4] Training mode in `apps/training/` with role walkthroughs on synthetic data

## Phase 6: Custom chart component (FR-006 to FR-012)
- [ ] T009 Spike (2 days): confirm the component API on the pinned Streamlit version and that the top-level scroll position is readable behind the proxy; record the result in `components/smokey_charts/README.md`
- [ ] T010 Scaffold `components/smokey_charts/` (TypeScript, Vite, D3 scales and shapes; no CDN) and the Python wrapper `smokey_chart()`
- [ ] T011 Scroll engine module `src/engine.ts` (ZENO 0.85, clamped maps, reduce-motion path), ported from the demo template
- [ ] T012 [P] Chart types `line_threshold`, `cohort_bars`, `multi_line`, `csi_heat`
- [ ] T013 [P] Chart types `factor_bars`, `count`, `spark_tile`
- [ ] T014 Chart type `unit_steps` (pinned regrouping) with step buttons (FR-012)
- [ ] T015 Selections returned to Python; pages call the API (no commands from the component)
- [ ] T016 [P] `tests/ui/test_scroll.py`: marks at expected positions per step; dash offset falls as a chart enters; reduce-motion sets no animated styles (port of `r2d3-scroll-2026-11-22/test_scroll.js`)
- [ ] T017 [P] Accessibility tests: text alternative, data table, keyboard selection (FR-011)
- [ ] T018 Degradation test: component blocked → verdicts, numbers and tables still render (SC-005)
- [ ] T019 Frame-rate check on the drift page (SC-004)
- [ ] T020 Replace native charts in the shared components (monitor panel, tier card) with `smokey_chart`

**Checkpoint**: T009 passes before T010 starts; if it fails, stop and revisit FR-008
