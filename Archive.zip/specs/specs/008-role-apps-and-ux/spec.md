# Feature Specification: Role apps, screen patterns and guided walkthroughs

**Feature Branch**: `008-role-apps-and-ux` · **Created**: 2026-11-22 · **Status**: Draft
**Input**: Design canvas (42 boards), ADHD-friendly pass, role-based walkthrough demo.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Each role lands on its own home (Priority: P1)
After single sign-on, the API returns the user's roles; the user lands on that role's home and sees only permitted pages.

**Independent Test**: A validator signs in and lands on the case queue; the SVP lands on L0; an IT administrator sees no model content.

### User Story 2 - Calm, consistent screens (Priority: P1)
Every screen starts with a "Look for" line, puts the verdict before detail, folds secondary detail, and ends with one obvious next action.

**Acceptance Scenarios**:
1. **Given** any page, **Then** it passes WCAG 2.2 AA automated checks and works at 390 px width without horizontal scroll.
2. **Given** reduced motion is set, **Then** no animation runs.

### User Story 3 - Refusals are designed screens (Priority: P1)
A refused command shows "Not done", the rule ID, why, and what to do instead; nothing changes.

### User Story 4 - Guided walkthrough per role (Priority: P3)
Training mode offers a 3–6 step walkthrough per role on the synthetic portfolio.

## Requirements *(mandatory)*
- **FR-001**: Four Streamlit apps: Portfolio (SVP), Governance (validator, head of validation, approval authority, head of model risk, owner, operations), Workbench (developer), Admin console (IT administrator).
- **FR-002**: Shared components: model sheet, tier card, inventory record, five-metric panel, refusal, Unknown.
- **FR-003**: Models are shown only by key (for example QCE03).
- **FR-004**: Theme from `.streamlit/config.toml` plus one style block; colour never the only carrier; chart labels direct.
- **FR-005**: Training mode uses the synthetic data and a role picker; production apps never show synthetic data.
- **FR-006**: Animation follows the R2D3 pattern used in the demo: one animation loop, scroll position eased (factor 0.85), every animated property a clamped linear function of it. Lines draw, bars grow, numbers count and blocks fade as they enter; step-through charts stay pinned while their marks regroup. No animation runs on a timer.
- **FR-007**: With reduce-motion set, content renders complete with no easing; stepped charts snap between steps.
- **FR-008**: Decided 2026-11-22: scroll animation in the production apps is delivered by one shared custom chart component, `smokey_charts`. Native Streamlit charts do not expose scroll position, so every animated chart (five-metric panel lines and bars, tier card bars, headline counts, the pinned step-through unit chart) MUST be drawn by this component; pages MUST NOT mix it with native charts for the same data.
- **FR-009**: The component takes data and a chart type from Python and returns selections (for example a clicked model key) to Python. It holds no state of record and issues no commands; a click is passed back to the page, which calls the API (constitution I).
- **FR-010**: The component MUST read the top-level page's scroll position. If it runs in an iframe it MUST use the parent window's scroll and its own frame offset, and MUST fall back to drawing complete, static charts when it cannot read them.
- **FR-011**: Every chart MUST carry a text alternative (title, summary sentence, and a data table available on request), keyboard access to selectable marks, and the same colours and bands as the theme.
- **FR-012**: The pinned step-through MUST also work without scrolling: step buttons move it, for keyboard and switch users.

## Success Criteria *(mandatory)*
- **SC-001**: Zero critical axe violations on every page.
- **SC-002**: New users complete their role walkthrough in under 10 minutes.
- **SC-003**: With reduce-motion emulated, no element has an animated style on any page (automated check).
- **SC-004**: The component keeps 50 frames a second or better while scrolling the drift page with 34 model tiles on a standard work laptop.
- **SC-005**: With the component failing to load, every page still shows its verdicts, numbers and tables (charts degrade, content does not).
