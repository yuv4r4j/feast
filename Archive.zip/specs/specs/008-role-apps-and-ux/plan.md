# Implementation Plan: Role apps and UX

## Technical Context
**Front end**: Streamlit ≥ 1.42 multipage apps, Altair · **Auth**: `st.login` with the corporate OIDC provider · **Testing**: Playwright + axe-core per page, visual snapshots at 1440 and 390 px · **Reference**: design canvas boards and `smokey-demo-roles.html`

## Constitution Check
I UI holds no authority ✅ · X accessibility ✅

## Structure
```
apps/common/components/ (model_sheet, tier_card, inventory_record, monitor_panel, refusal)
apps/portfolio/  apps/governance/  apps/workbench/  apps/admin/
.streamlit/config.toml
tests/ui/
```

## Animation
Reference implementation: the scroll engine in `r2d3-scroll-2026-11-22/demo_tpl-roles.html` (`scScan`, `scApply`, `scFrame`), taken from the technique in `r2d3-mirror/decision-trees-part-1-main.js`. Decision: one custom chart component (spec FR-008 to FR-012).

### `smokey_charts` component
- **Build**: TypeScript, D3 for scales and shapes only, bundled with Vite; no runtime CDN calls. Packaged as a Python wheel in `components/smokey_charts/`.
- **Embedding**: use Streamlit's frameless custom components if the pinned Streamlit version supports them, so the component shares the page's scroll. Otherwise the classic iframe component, reading `window.parent` scroll plus the frame's offset (same origin). [NEEDS CLARIFICATION: confirm which component API the pinned Streamlit version offers, and that the reverse proxy and content security policy allow same-origin frame access]
- **Engine**: port of `scScan` / `scApply` / `scFrame` from `r2d3-scroll-2026-11-22/demo_tpl-roles.html`: one rAF loop, ZENO easing 0.85, clamped linear maps, reduce-motion path.
- **Chart types**: `line_threshold` (PSI, KS), `cohort_bars` (early delinquency), `multi_line` (dynamic delinquency), `csi_heat`, `factor_bars` (tier card), `count`, `unit_steps` (pinned regrouping chart), `spark_tile`.
- **Python API**: `smokey_chart(kind, data, key, height=None) -> selection | None`.
- **Risk**: the pinned step-through needs the component to span the steps' scroll height; if the component API cannot do that, `unit_steps` falls back to step buttons (FR-012) with eased transitions between steps.
