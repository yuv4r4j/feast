# Feature Specification: Feast, MLflow and cluster reconciliation

**Feature Branch**: `005-sources-reconciliation` · **Created**: 2026-11-22 · **Status**: Draft
**Input**: "Feast and MLflow for now"; registry aliases are not approval.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Three readings agree or an exception opens (Priority: P1)
The reconciler compares the MLflow alias, the control-plane authorisation and the digest the cluster runs.

**Independent Test**: Moving MCD03's champion alias to an unapproved version and serving it opens E2 within one cycle.

**Acceptance Scenarios**:
1. **Given** alias, authorisation and cluster agree, **Then** deployment position is "Live · digest matches".
2. **Given** any two differ, **Then** E2 opens naming which reading differs.
3. **Given** serving configured to load `models:/name@champion`, **Then** the pipeline check fails: serving must load the authorised digest.

### User Story 2 - Feature usage and freshness (Priority: P1)
Feast feature views, features, feature services and freshness are read; stale views flag dependent models.

**Independent Test**: income_verification_feed past its TTL shows Stale and flags its dependent version.

### User Story 3 - Keys in sources (Priority: P2)
Each model has its own MLflow registered model, named from its internal Model ID, so each has its own champion alias. Each MLflow model version carries the `smokey.key` tag. Feast feature services are named by key.

**Independent Test**: Two models named ACE have two registered models; moving one champion alias does not affect the other.

## Requirements *(mandatory)*
- **FR-001**: Poll MLflow (registered models, versions, aliases, run IDs, artifact digests) and Feast (views, features, services, materialisation times) on a schedule; store snapshots.
- **FR-002**: Observe running digests per namespace from the cluster API (read-only service account).
- **FR-003**: Raise E2 on disagreement; close it when readings agree again with an authorisation.
- **FR-004**: The platform's only writes to MLflow are (a) moving an alias after AuthoriseRelease and (b) setting the `smokey.key` tag on a model version. It never writes approval, tier or status into MLflow, and writes nothing to Feast or the cluster.
- **FR-005**: SAS and vendor models are wrapped as MLflow pyfunc so each has a digest.

## Success Criteria *(mandatory)*
- **SC-001**: E2 within 5 minutes of a divergent deployment.
- **SC-002**: 100% of live versions have a digest in all three readings.
