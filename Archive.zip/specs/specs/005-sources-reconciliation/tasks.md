# Tasks: Sources reconciliation

## Phase 1: Setup
- [ ] T001 Snapshot tables migration; test MLflow and Feast servers in `tests/integration/conftest.py`

## Phase 2: User Story 1 - Three readings (P1)
- [ ] T002 [P] [US1] Test N17: alias moved and served → E2 within one cycle
- [ ] T003 [US1] `reconciler/mlflow_reader.py`, `cluster_observer.py`, `compare.py`; raise and close E2
- [ ] T004 [US1] `deploy/pipeline/verify_authorisation.py`: refuse `@champion` loading; deploy the authorised digest only

**Checkpoint**: tests N13–N17 and A10 pass

## Phase 3: User Story 2 - Feast (P1)
- [ ] T005 [US2] `reconciler/feast_reader.py`: views, services, freshness; stale view flags

## Phase 4: User Story 3 - Keys in sources (P2)
- [ ] T006 [P] [US3] Test: two models named ACE have separate registered models and champion aliases
- [ ] T007 [US3] Registered model per Model ID (`smk-<model_id>`), `smokey.key` tag, Feast services named by key
- [ ] T008 [P] [US3] Test: no MLflow write other than alias move and `smokey.key` tag (audit of client calls)

## Phase 5: Polish
- [ ] T009 pyfunc wrappers for SAS and vendor models in `wrappers/`
