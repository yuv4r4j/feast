# Implementation Plan: Model inventory and model keys

**Branch**: `001-inventory-and-keys` | **Spec**: [spec.md](./spec.md)

## Summary
Inventory as event-sourced aggregates with a read model that exposes the firm's 40 columns plus 29 additions. Each model has a hidden, stable Model ID (UUID) that links its version keys. A key service derives the 3-letter name and issues counters with row-level locking. Tools are a separate aggregate.

## Technical Context
**Language/Version**: Python 3.12
**Primary Dependencies**: FastAPI, Pydantic v2, SQLAlchemy 2, Alembic, Feast SDK (read), MLflow client (read; the only writes are the `smokey.key` version tag and alias moves after AuthoriseRelease, per constitution IV)
**Storage**: PostgreSQL 16: `events` (append-only, hash chain), `inventory_rm` (read model), `name_counters`, `tools`
**Testing**: pytest, hypothesis (key uniqueness), testcontainers-postgres
**Target Platform**: Kubernetes / OpenShift (see 009)
**Project Type**: web service (API) + Streamlit front ends
**Performance Goals**: key issue p95 < 100 ms; inventory read p95 < 300 ms for 1,000 models
**Constraints**: counters never reused; all writes via commands
**Scale/Scope**: 40 models and about 8 releases a year today. The key standard caps the inventory at 4,455 keys (45 names × 99) and at 99 per name, so the service is sized for that ceiling; anything larger depends on the blocking decision in spec.md

## Constitution Check
- I API decides: commands only ✅ · II events ✅ · III rules as data: letter tables in policy config ✅ · IX one key per version ✅ · XI refusals tested ✅

## Project Structure
```
api/
  domain/inventory/  (aggregates, commands, events)
  domain/keys/       (derive_name, issue_counter)
  domain/tools/
  readmodels/inventory.py
  routes/inventory.py
policy/
  naming.yaml        (letters, precedence, counter ceiling)
tests/
  contract/ integration/ unit/
migrations/
```

## Design notes
- `derive_name(version)`: bureau letter from Feast feature views (policy maps view → letter); type from Model Type; channel from Expected Usage. Returns letters plus Model Code Basis text.
- `issue_counter(name)`: `SELECT … FOR UPDATE` on `name_counters`; increments; writes `KeyReserved` event in the same transaction. Withdrawn reservations are marked, never reissued.
- MLflow: one registered model per Model ID (`smk-<model_id>`); the key is the `smokey.key` tag on each model version.
- Import: one-off loader maps the current inventory export to `ModelRegistered` + `VersionImported` events; legacy IDs go to Legacy Name.
- Derived fields (Periodically Reviewed Recently) are computed in the read model, never stored as input.

## Complexity Tracking
| Violation | Why needed | Simpler alternative rejected because |
|---|---|---|
| None | | |
