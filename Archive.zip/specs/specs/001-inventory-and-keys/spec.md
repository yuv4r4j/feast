# Feature Specification: Model inventory and model keys

**Feature Branch**: `001-inventory-and-keys`
**Created**: 2026-11-22
**Status**: Draft
**Input**: "The current inventory contains all the columns. All new models must adopt a standardized 5-letter Model Code. Model name is unique (ACE) and version (06) is the key; show only QCE07-like keys."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Register a model and get its key (Priority: P1)
A model owner registers a new model. The system derives the 3-letter Model Name from bureau or data scope, model type and channel, assigns the next free counter under that name, and shows the model everywhere only by that key.

**Why this priority**: Every other feature identifies models by key.

**Independent Test**: Register a credit risk, account-level, every-channel model when ACE01–ACE29 exist; the model is created as ACE30 and appears under that key in the inventory and model sheet.

**Acceptance Scenarios**:
1. **Given** the Feast feature service reads the Experian consumer bureau view, **When** a credit risk model for every channel is registered, **Then** its Model Name is XCE and its key is the next free XCE number.
2. **Given** a model reads no bureau and scores accounts, **When** it is registered, **Then** letter 1 is A.
3. **Given** an income estimation model, **When** it is registered, **Then** letter 2 is I (pending standard approval) and the record shows "letter I awaiting approval".
4. **Given** a requested code uses a letter outside the standard, **When** RegisterModel runs, **Then** it is refused with rule NAME-01 and nothing is created.

### User Story 2 - New release takes the next key (Priority: P1)
A developer creates a new version. The system reserves the next free counter under the same name; the release version (for example 3.0) stays in Model Version.

**Independent Test**: QCE03 v3.0 is created while QCE04 is reserved; the new version is reserved as QCE05.

**Acceptance Scenarios**:
1. **Given** QCE01–QCE04 are issued or reserved, **When** CreateVersion runs for QCE03, **Then** QCE05 is reserved and carries the same internal Model ID as QCE03, so the model sheet lists QCE03 as its previous release.
2. **Given** a name has used 99 numbers, **When** CreateVersion runs, **Then** it is refused with NAME-02 and the message names the open standard decision.

### User Story 3 - See and keep the inventory record (Priority: P2)
Any role opens a model and sees the inventory record with the firm's 40 existing columns and the proposed additions, grouped as Key, Identity, Risk and tier, Lifecycle and review, Documents.

**Independent Test**: Open XCE01; all 40 existing columns render with their exact names; proposed columns are marked and visually distinct.

**Acceptance Scenarios**:
1. **Given** a model with Next Periodic Review in the past, **When** the record renders, **Then** Periodically Reviewed Recently shows "No (derived)" and cannot be edited.
2. **Given** an owner, **When** they attest tier inputs, **Then** Tier Inputs Attested is set by the AttestTierInputs event, not by typing.

### User Story 4 - Tools register (Priority: P2)
Rule-based items with no statistical, economic or financial theory are held as tools with owners, controls and yearly attestation, outside model scope.

**Independent Test**: Reclassify QCE02 (business line assignment matrix) to tool TL-015; it leaves monitoring and appears in the tools register with controls.

**Acceptance Scenarios**:
1. **Given** a model whose methodology uses statistical theory, **When** ReclassifyToTool runs, **Then** it is refused (SR 26-2 model definition).
2. **Given** the yearly sweep finds a spreadsheet that fits a regression, **When** RegisterAsModel runs, **Then** a model record is created with a calculated tier.

### Edge Cases
- A model reads two bureaus: letter 1 precedence is undefined. [NEEDS CLARIFICATION: bureau precedence rule]
- Portfolio-level models (economic capital) have no scope letter; A is used provisionally and the record is flagged Incomplete. [NEEDS CLARIFICATION: portfolio scope letter]
- Retired models keep their key; their counter is never reused.
- Concurrent CreateVersion calls under the same name must not reserve the same number.
- A reserved key whose version is withdrawn before release is not reused; it is recorded as Withdrawn. This burns numbers, so see the blocking decision below.

### Blocking decision (must be settled before build)
Key capacity is 45 names × 99 numbers = 4,455 keys, and ACE alone holds 22 of today's 40 models and already uses 29 numbers. The standard's owner MUST decide what happens when a name reaches 99 (for example a fourth name letter for business unit, or a three-digit counter) before User Story 2 is implemented. [NEEDS CLARIFICATION: rule when a name reaches 99]

## Requirements *(mandatory)*

### Functional Requirements
- **FR-001**: System MUST store the firm's 40 existing inventory columns with their exact names: Model Name, Model Version, Full Model Name, Legacy Name, Model Risk Tier, Model Type, Model Methodology, Status, Associated Developer, Source, Business Area, Model Description, Adverse Actionable, Model Inputs, Current Production Environment, Expected Usage, Model Development Data, Model Development Date, Model Validation Date, Model Deployment Date, Exposure, Reliance, Uncertainty, MMR, Last MMR, Next MMR, MMR Status, Periodically Reviewed Recently, Last Periodic Review, Next Periodic Review, Model Initiation Form, Model Initiation Location, MDD, MDD Location, Model Sign-Off, Model Sign-Off Location, Model Validation, Model Validation Location, Last Updated, Open Comments.
- **FR-002**: System MUST add these 29 columns: Model Key, Model ID (internal, never displayed), Code at Next Version, Model Code Basis, Model Code Status, Model Code Issues, Model Owner, Validation Pod, Classification, Classification Reason, Upstream Models, Downstream Models, Use Category, Impact, Uncertainty score, Implementation Risk, Tier Score, Proposed Tier, Tier Floor Applied, Tier Override, Tier Inputs Attested, Approval State, Approval Expiry, Open Conditions, Open Exceptions, Open Findings, MLflow Registered Model, MLflow Version, Feast Feature Service.
- **FR-003**: Model Name MUST be 3 letters: (1) X Experian, T TransUnion, Q Equifax, or without bureau M multiple account (customer level), A account level; (2) C credit risk, P response propensity, I income estimation (pending approval); (3) D digital, M direct mail, E every channel.
- **FR-004**: The key MUST be Model Name + a two-digit counter shared by every model and release under that name, unique across the inventory, never reused.
- **FR-005**: Letter 1 MUST be derived from the Feast views the version reads; letters 2 and 3 from Model Type and Expected Usage; the system MUST record the derivation in Model Code Basis.
- **FR-006**: RegisterModel and CreateVersion MUST refuse letters outside the standard (NAME-01) and exhausted counters (NAME-02).
- **FR-007**: Every screen and export MUST identify models by key; Legacy Name holds prior identifiers and is searchable. The internal Model ID links a model's versions (lineage), appears only in API payloads and logs, and is assigned once at RegisterModel.
- **FR-008**: Periodically Reviewed Recently MUST be derived from Next Periodic Review and the as-of date.
- **FR-009**: Inventory fields MUST change only through commands that append events; Last Updated is the time of the latest event.
- **FR-010**: The tools register MUST hold tool ID, name, kind (rule engine, spreadsheet, calculator, report), business unit, model fed, exposure, control rating, control status and last attestation.
- **FR-011**: Each model MUST have its own MLflow registered model, named from its internal Model ID (one champion alias per model). Each MLflow model version MUST carry the tag `smokey.key` with its key. A registered model MUST NOT be shared by models that merely share a 3-letter name. Feast feature services are named by key (for example fs_qce05).
- **FR-012**: A withdrawn reservation MUST be recorded as Withdrawn and its number never reissued.

### Key Entities
- **Model**: internal Model ID (stable, hidden), Model Name, owner, classification, ordered list of version keys.
- **ModelVersion**: key, Model Version, status, dates, documents, inputs.
- **NameCounter**: Model Name, last issued number, reservations.
- **Tool**: tool ID, kind, controls, attestation, source model if reclassified.
- **InventoryEvent**: command, actor, timestamp, payload, hash, previous hash.

## Success Criteria *(mandatory)*
- **SC-001**: 100% of models and versions in the inventory have a unique key; zero duplicate keys under concurrent load (1,000 parallel CreateVersion calls in test).
- **SC-002**: The 40 existing columns import from the current inventory without renaming or loss (round-trip test on the full export).
- **SC-003**: Every NAME-01 and NAME-02 refusal is covered by a negative test.
- **SC-004**: A user finds any model by key or legacy name in under 5 seconds.

## Assumptions
- The synthetic portfolio maps bureau_attrs_v7 to Experian (X) and business_bureau_feed to Equifax (Q).
- Existing models are keyed in legacy-ID order after the five new models keep their numbers (ACE01, MIE01, MCM01, MID01, ACD01).
- The synthetic generator writes a thirtieth added column, Model Code Applies, which is now always "Now"; it is not part of this spec and should be dropped from the generator.
