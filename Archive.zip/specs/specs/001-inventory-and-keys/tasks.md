# Tasks: Model inventory and model keys

**Input**: spec.md, plan.md · `[P]` = can run in parallel · `[USn]` = user story

## Phase 1: Setup
- [ ] T001 Create `api/domain/inventory`, `api/domain/keys`, `api/domain/tools` packages and `policy/naming.yaml`
- [ ] T002 [P] Alembic migration: `events`, `name_counters`, `inventory_rm`, `tools`

## Phase 2: Foundational
- [ ] T003 Event envelope with SHA-256 hash chain in `api/domain/events.py`
- [ ] T004 [P] Policy loader for `naming.yaml` with schema validation

## Phase 3: User Story 1 - Register and key (P1)
- [ ] T005 [P] [US1] Unit tests for `derive_name` covering X, T, Q, M, A, C, P, I, D, M, E
- [ ] T006 [P] [US1] Negative test: letter outside standard → NAME-01
- [ ] T007 [US1] Implement `derive_name` with Model Code Basis text
- [ ] T008 [US1] Implement `issue_counter` with row lock and `KeyReserved` event
- [ ] T009 [US1] `POST /models` RegisterModel command assigning the internal Model ID, and contract test

## Phase 4: User Story 2 - Next release key (P1)
- [ ] T010 [P] [US2] Property test: 1,000 concurrent CreateVersion calls yield unique keys
- [ ] T011 [P] [US2] Negative test: counter at 99 → NAME-02
- [ ] T012 [US2] `POST /models/{key}/versions` CreateVersion reserving the next key under the same Model ID
- [ ] T012a [P] [US2] Test: two models named ACE get separate MLflow registered models, each with its own champion alias
- [ ] T012b [US2] Withdrawn reservations recorded and never reissued

**Checkpoint**: blocking decision on a name reaching 99 recorded in `policy/naming.yaml` before this phase starts

## Phase 5: User Story 3 - Inventory record (P2)
- [ ] T013 [P] [US3] Read model exposing the 40 existing columns with exact names and the additions
- [ ] T014 [US3] Derived field Periodically Reviewed Recently
- [ ] T015 [US3] AttestTierInputs command
- [ ] T016 [US3] Loader for the current inventory export; round-trip test on all 40 columns

## Phase 6: User Story 4 - Tools register (P2)
- [ ] T017 [P] [US4] Negative test: ReclassifyToTool on a statistical model is refused
- [ ] T018 [US4] ReclassifyToTool, RegisterAsModel, AttestTool commands
- [ ] T019 [US4] Tools read model and yearly sweep job

## Phase 7: Polish
- [ ] T020 [P] Search by key and legacy name
- [ ] T021 Seed from `synthetic-portfolio/model_inventory.csv` for demos
