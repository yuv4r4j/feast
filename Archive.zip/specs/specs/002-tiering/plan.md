# Implementation Plan: SR 26-2 tiering

**Branch**: `002-tiering` | **Spec**: [spec.md](./spec.md)

## Summary
A pure scoring function driven by `policy/tiering.yaml`, run on inventory events; proposals and decisions as events; a calibration notebook that searches weights and thresholds against in-force tiers under distribution constraints.

## Technical Context
**Language/Version**: Python 3.12 · **Dependencies**: FastAPI, Pydantic, pandas (calibration only) · **Storage**: PostgreSQL events and `tier_rm` · **Testing**: pytest with golden files from `synthetic-portfolio/model_tiering.csv` · **Performance**: full re-tier of 2,000 models < 5 s

## Constitution Check
III rules as data ✅ · VIII inherent risk, raise-only overrides ✅ · XI refusals tested ✅

## Structure
```
api/domain/tiering/score.py      (pure function: inputs + policy -> score, tier, floor)
api/domain/tiering/commands.py   (ProposeTier, ApproveTiering, OverrideTier)
policy/tiering.yaml
tools/calibrate_tiers.py         (grid search; reports changes and distribution)
tests/golden/tiering_v3.csv
```

## Design notes
- `score()` is deterministic and side-effect free so audit can replay any tier with the stored policy version.
- On ApproveTiering, emit one `TierApproved` per model; the review scheduler (003) recomputes due dates from the event.
- The tier card is a read model: inputs, factor explanations, score, scale, floor, meaning.
