# Tasks: SR 26-2 tiering

## Phase 1: Setup
- [ ] T001 `policy/tiering.yaml` with bands, use uplifts, reliance adjustments, weights (4,1,1), thresholds (16,12,10), floors

## Phase 2: User Story 1 - Calculate (P1)
- [ ] T002 [P] [US1] Golden test: synthetic inventory → 12/9/11/6
- [ ] T003 [P] [US1] Floor tests: stress and capital T1, CECL ≥ T2, Adverse Actionable ≥ T3
- [ ] T004 [US1] Implement `score.py`
- [ ] T005 [US1] ProposeTier on inventory input change

## Phase 3: User Story 2 - Approve (P1)
- [ ] T006 [P] [US2] Negative tests: TIER-01 (missing attestation), TIER-02 (lowering override)
- [ ] T007 [US2] ApproveTiering and OverrideTier commands; Model Risk Tier written by event
- [ ] T008 [US2] Review-cycle recompute on TierApproved

## Phase 4: User Story 3 - Tier card (P2)
- [ ] T009 [US3] Tier card read model and `GET /models/{key}/tier`
- [ ] T010 [US3] Transition grid read model and change list

## Phase 5: User Story 4 - Calibrate (P3)
- [ ] T011 [US4] `calibrate_tiers.py` with distribution guardrails and change report
- [ ] T012 [US4] Replay endpoint for audit: tier at date with policy version
