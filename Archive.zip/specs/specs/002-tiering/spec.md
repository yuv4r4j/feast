# Feature Specification: SR 26-2 tiering

**Feature Branch**: `002-tiering` · **Created**: 2026-11-22 · **Status**: Draft
**Input**: "Add tier 1 to tier 4 and tools based on SR 11-7 and SR 26-2 transition; tier calculated from complexity, dollar impact and reproducibility; validated against Kiritz, Ravitz and Levonian (2019); use the inventory's Exposure, Reliance and Uncertainty."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Calculate a proposed tier (Priority: P1)
The system scores every model from its attested inventory inputs and proposes a tier.

**Independent Test**: XCE01 (Exposure $14.0bn, credit decisioning, Reliance High, Uncertainty High, pinned Python) scores 16 and is proposed T1.

**Acceptance Scenarios**:
1. **Given** Impact, Uncertainty and Implementation risk, **When** the score is computed, **Then** Score = 4 × Impact + Uncertainty + Implementation (range 6 to 18).
2. **Given** a score of 16–18, 12–15, 10–11 or 6–9, **Then** the tier is T1, T2, T3 or T4.
3. **Given** a stress testing or economic capital model, **Then** the tier is T1 whatever the score; **given** a CECL model, never below T2; **given** Adverse Actionable = Y, never below T3.

### User Story 2 - Approve the re-tiering (Priority: P1)
The head of model risk approves the proposed tiers; Model Risk Tier is then written by the event, never typed.

**Independent Test**: ApproveTiering records 16 changes; review due dates recompute from the new tiers.

**Acceptance Scenarios**:
1. **Given** any input lacks owner attestation, **When** ApproveTiering runs, **Then** it is refused with TIER-01.
2. **Given** a request to lower a tier by override, **When** it comes from the head of model risk, **Then** it is refused with TIER-02 and routed to the committee; raising is allowed with a rationale.

### User Story 3 - See why a model has its tier (Priority: P2)
Any role sees the tier card: three factor bars, score, scale, floors and what the tier means.

**Independent Test**: The XCE01 card shows Impact 3 (Exposure $14.0bn band 3 · credit decisioning +0.5 · Reliance High +0), Uncertainty High, Implementation 1, score 16.

### User Story 4 - Calibrate and monitor the tool (Priority: P3)
Model risk recalibrates weights and thresholds against current tiers, within distribution guardrails, and reviews the tiering rule like a model.

**Acceptance Scenarios**:
1. **Given** a calibration run, **Then** each tier holds at least 10% of models and no tier holds more than 35%.
2. **Given** TIER-01 changes, **Then** they ship by pull request with a calibration report, and internal audit can replay any historical tier.

### Edge Cases
- A model with no attested inputs shows "Tier inputs missing" and keeps its in-force tier.
- Tools carry no tier; they carry a control rating.
- A tier change on an in-flight version applies to the version being validated from its next stage.

## Requirements *(mandatory)*
- **FR-001**: Impact = Exposure band (<$2bn 1, $2–10bn 2, ≥$10bn 3) + use (general business 0, credit decisioning +0.5, accounting, regulatory or ability-to-pay +1) + Reliance (High 0, Medium −0.5, Low −1), bounded to 1..3.
- **FR-002**: Uncertainty = the inventory's Low/Medium/High (1/2/3), raised one step if Model Inputs include another model's output or the method is new to the firm.
- **FR-003**: Implementation risk from Source, Current Production Environment and Model Development Data: pinned Python in an IT-controlled pipeline 1; AutoML or legacy SAS 2; vendor black box, manual steps or no lineage 3. Validation results MUST NOT change it.
- **FR-004**: Weights, bands, thresholds and floors MUST live in `policy/tiering.yaml` (rule TIER-01) and be versioned.
- **FR-005**: The system MUST keep the in-force tier (Model Risk Tier) separate from the proposed tier until ApproveTiering.
- **FR-006**: Overrides MUST only raise a tier (TIER-02) and record a rationale.
- **FR-007**: Validation depth, review cycle and monitoring frequency MUST follow the tier: T1 full with replication, 12 months, monthly; T2 full, 24 months, monthly; T3 targeted, 36 months, quarterly; T4 conceptual soundness and outcomes, no periodic review.
- **FR-008**: Owners MUST re-attest tier inputs at least yearly; every model is re-tiered at least yearly.
- **FR-009**: The transition view MUST show in-force × proposed counts and list every change with its reason.
- **FR-010**: T4 models MUST be watched for the conditions that would make them material (SR 26-2): the system re-scores on any change to Exposure, Expected Usage or Reliance and flags a model whose score crosses into T3.
- **FR-011**: The tier belongs to the model and applies to every version; a version in flight is validated at the tier in force when its current stage began.

### Key Entities
TierPolicy (version, weights, bands, floors) · TierAssessment (key, inputs, score, proposed tier, policy version) · TierDecision (approved tier, override, rationale).

## Success Criteria *(mandatory)*
- **SC-001**: Recomputing tiers from the synthetic inventory reproduces T1 12, T2 9, T3 11, T4 6 exactly.
- **SC-002**: Any historical tier can be replayed from events and the policy version within 1 second.
- **SC-003**: TIER-01 and TIER-02 refusals covered by negative tests.

## Assumptions
- SR 26-2 prescribes no tiers; the four tiers are firm policy and placeholders until the policy baseline is confirmed. [NEEDS CLARIFICATION: confirmed bands and thresholds]
