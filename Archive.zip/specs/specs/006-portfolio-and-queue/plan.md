# Implementation Plan: SVP portfolio app

## Technical Context
**Front end**: Streamlit ≥ 1.42 (multipage; 1.42 is the first release with `st.login`, used in 008), Altair charts, `st.dataframe` with `on_select` · **Back end**: read models from 003/004/005 via API · **Testing**: pytest for queue rules; Playwright smoke tests per page; executive test protocol

## Constitution Check
I read-only UI ✅ · V never one score ✅ · X look-for line, verdict first ✅

## Structure
```
apps/portfolio/pages/0_L0_Decisions.py 1_L1_Posture.py 2_L2_Why.py 3_L2_Drift.py 4_L3_Model.py 5_L4_Evidence.py
api/queue/rules.py   policy/queue.yaml
```
