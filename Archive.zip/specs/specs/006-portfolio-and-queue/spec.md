# Feature Specification: SVP portfolio app and decision queue

**Feature Branch**: `006-portfolio-and-queue` · **Created**: 2026-11-22 · **Status**: Draft
**Input**: Design canvas pages L0–L4, L2 Drift, SVP actions; executive test with planted issues.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Decisions required now (Priority: P1)
The SVP sees at most seven items, each admitted by a written rule, with why now, who is accountable, options and one action.

**Independent Test**: The synthetic portfolio yields exactly three items: (1) outside approved basis (R1): 2 lapsed exceptions and MCD03's unauthorised build; (2) shared cause (R2): one incident owner for the bureau feed across 6 models; (3) capacity (R2, R4): add validation capacity or choose which date slips.

**Acceptance Scenarios**:
1. **Given** 7 overdue tier 3 reviews with no shared cause, **Then** they are listed as delegated, with their reason, and not on the queue.
2. **Given** the SVP assigns a follow-up, **Then** it is tracked to closure and re-enters the queue if overdue; no model state changes.

### User Story 2 - Why is this here? (Priority: P1)
A four-step explanation collapses troubled models into their shared Feast view, the same features in breach, and the owners.

### User Story 3 - Posture, drift and the model sheet (Priority: P2)
L1 counts by in-force and proposed tier and health (Unknown beside Breach); L2 Drift scorecard with verdicts; L3 model sheet with four positions, tier card, inventory record and monitoring; L4 source evidence for any status.

### Edge Cases
- More than seven qualifying items: order by condition, tier, age; the rest stay delegated with a count.
- A queue item whose cause resolves closes with the event that resolved it.

## Requirements *(mandatory)*
- **FR-001**: Admission rules in `policy/queue.yaml`: R1 tier 1 or 2 model outside approved basis; R2 one cause touching five or more models; R3 a call needing authority above the owner; R4 a committed date forecast to miss. [NEEDS CLARIFICATION: the design tags the capacity item "R2 and R4", but it involves four versions in one pod, which does not meet R2 as written. Either R2's threshold or the item's rule tag must change; R3 and R4 alone may be the right tag.]
- **FR-002**: Each item shows rule, why now, accountable role, options, follow-up button.
- **FR-003**: The SVP app is read-only except AssignFollowUp and AcknowledgeBriefing.
- **FR-004**: Every count opens the list of models behind it.
- **FR-005**: Every status links to its source evidence (L4).

## Success Criteria *(mandatory)*
- **SC-001**: Executive test: at least 4 of 5 executives find all three issues and the accountable role in 15 minutes; none ranks the overdue tier 3 reviews in their top three.
- **SC-002**: L0 renders in under 2 seconds.
