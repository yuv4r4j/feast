# Tasks: SVP portfolio app

## Phase 1: Setup
- [ ] T001 `policy/queue.yaml` with R1–R4 once the R2 clarification is settled

## Phase 2: User Story 1 - Decisions (P1)
- [ ] T002 [P] [US1] `tests/unit/test_queue_rules.py`: synthetic portfolio yields exactly 3 items; overdue reviews delegated
- [ ] T003 [US1] Queue builder in `api/queue/rules.py`; AssignFollowUp (test A11)
- [ ] T004 [US1] `apps/portfolio/pages/0_L0_Decisions.py`

**Checkpoint**: L0 shows three items from the synthetic data

## Phase 3: User Story 2 - Why (P1)
- [ ] T005 [US2] `apps/portfolio/pages/2_L2_Why.py` four-step explanation

## Phase 4: User Story 3 - Posture, drift, model sheet (P2)
- [ ] T006 [P] [US3] `1_L1_Posture.py` with in-force and proposed tiers and the aggregate view
- [ ] T007 [P] [US3] `3_L2_Drift.py` scorecard and tiles
- [ ] T008 [US3] `4_L3_Model.py`: positions, tier card, inventory record, monitoring panel
- [ ] T009 [US3] `5_L4_Evidence.py`

## Phase 5: Proof
- [ ] T010 Run the executive test (SC-001) and record results in `docs/executive-test.md`
