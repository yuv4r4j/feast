# Tasks: AutoML guardrails

## Phase 1: Setup
- [ ] T001 `policy/automl.yaml`, `policy/protected_features.yaml`, `policy/fair_lending.yaml` (threshold from compliance)
- [ ] T002 Stub Driverless AI server for CI in `tests/stubs/dai.py`

## Phase 2: User Story 1 - Configured by policy (P1)
- [ ] T003 [P] [US1] Tests N08 (AML-02) and N09 (AML-01)
- [ ] T004 [US1] `api/automl/config_builder.py` from tier and Feast views; StartAutoMLExperiment in `api/automl/submit.py`

**Checkpoint**: a T2 config has interpretability ≥ 7, single model, monotone list, fixed seed

## Phase 3: User Story 2 - Compare (P1)
- [ ] T005 [US2] Leaderboard and baseline comparison in `api/automl/collect_artifacts.py`

## Phase 4: User Story 3 - Explain and document (P2)
- [ ] T006 [US3] MLI and AutoDoc artifacts logged to one MLflow run

## Phase 5: User Story 4 - Freeze (P1)
- [ ] T007 [P] [US4] Tests: freeze refused on failed monotonicity or failed fair-lending policy check
- [ ] T008 [US4] `api/automl/freeze.py` with MOJO parity check
- [ ] T009 [US4] Replication harness for validators in `tools/replicate.py`

## Phase 6: UI
- [ ] T010 `apps/workbench/pages/2b_AutoML.py` (setup, leaderboard, interpretability, hand-off)
