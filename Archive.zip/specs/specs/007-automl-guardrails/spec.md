# Feature Specification: AutoML experiments within policy guardrails (H2O Driverless AI)

**Feature Branch**: `007-automl-guardrails` · **Created**: 2026-11-22 · **Status**: Draft
**Input**: "For developer add AutoML features like H2O Driverless AI."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Start an experiment configured by policy (Priority: P1)
A developer starts a Driverless AI experiment for a version; the platform builds the config from the tier and the approved feature space.

**Independent Test**: For QCE03 v3.0 (proposed T2, release key QCE05) the experiment runs with interpretability ≥ 7, reproducible seed, monotonic constraints on the listed drivers, single model only, features only from approved Feast views.

**Acceptance Scenarios**:
1. **Given** a T1 or T2 model, **When** the developer requests an ensemble, **Then** it is refused (AML-02).
2. **Given** a feature outside approved views or on the protected-proxy list (e.g. business_zip), **Then** it is refused (AML-01).
3. **Given** a T3 or T4 model, **Then** interpretability ≥ 5 and ensembles of up to 3 models are allowed.

### User Story 2 - Compare candidates (Priority: P1)
The leaderboard shows allowed models against the legacy baseline with KS, AUC, out-of-time KS, monotonicity checks and lowest adverse impact ratio; disallowed results are shown but cannot be selected.

### User Story 3 - Explain and document (Priority: P2)
MLI outputs (Shapley, K-LIME, surrogate tree, PDP/ICE, sensitivity, disparate impact, reason codes) and AutoDoc are attached to the run; AutoDoc fills the MDD template.

### User Story 4 - Freeze and hand off (Priority: P1)
FreezeCandidate stores config hash, seed, MOJO digest, MLI artifacts and AutoDoc in one MLflow run and reserves the key; validation replicates from the frozen config.

**Acceptance Scenarios**:
1. **Given** monotonicity fails, or the fair-lending test set by compliance fails, **Then** FreezeCandidate is refused.
2. **Given** a rerun with the frozen config and seed, **Then** metrics match within tolerance.

### Edge Cases
- Driverless AI unavailable: experiment queued; no fallback to unrestricted tools.
- Disparate impact needs group labels; proxy estimation method must be approved. [NEEDS CLARIFICATION: method for estimating protected groups]
- The design shows an adverse impact ratio of 0.80 as the gate. That figure is a screening rule of thumb, not a legal standard for credit. The test, the threshold and whether it blocks or escalates are compliance decisions held in `policy/fair_lending.yaml`. [NEEDS CLARIFICATION: fair-lending test and threshold, owned by compliance]
- Driverless AI version features differ; capabilities to confirm against the installed version. [NEEDS CLARIFICATION: installed Driverless AI version and MLflow export path]

## Requirements *(mandatory)*
- **FR-001**: Policy `policy/automl.yaml` maps tier → minimum interpretability, allowed model families, ensemble level, monotone drivers, transformer allow-list, reproducible mode.
- **FR-002**: Feature candidates come only from the version's approved Feast views; protected attributes and listed proxies are removed before submission.
- **FR-003**: The platform submits experiments through the Driverless AI Python client using a service identity; developers do not configure the server directly.
- **FR-004**: Every artifact (config, leaderboard, MLI downloads, AutoDoc .docx, MOJO, Python scoring pipeline) is logged to one MLflow run linked to the version key.
- **FR-005**: MOJO parity with the Python pipeline is checked on a sample before freeze.
- **FR-006**: Reason codes map to adverse-action statements for Adverse Actionable models.
- **FR-007**: The fair-lending check reads its test, groups and threshold from `policy/fair_lending.yaml`; no threshold is hard-coded.

## Success Criteria *(mandatory)*
- **SC-001**: 100% of experiments for T1/T2 models satisfy policy (audit query on configs).
- **SC-002**: Validator replication of a frozen candidate matches within tolerance in 100% of slice tests.
- **SC-003**: AutoDoc covers at least 11 of 14 MDD sections without manual text.
