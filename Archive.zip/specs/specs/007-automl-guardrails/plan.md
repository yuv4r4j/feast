# Implementation Plan: AutoML guardrails

## Technical Context
**Dependencies**: H2O Driverless AI Python client, MLflow, Feast · **Storage**: experiment records as events; artifacts in MLflow · **Testing**: config builder unit tests; a stub Driverless AI server for CI; one live run in the slice

## Constitution Check
III policy-driven config ✅ · VII developer cannot bypass guardrails (service identity) ✅ · XI AML-01/02 negative tests ✅

## Structure
```
api/automl/config_builder.py  submit.py  collect_artifacts.py  freeze.py
policy/automl.yaml  policy/protected_features.yaml
apps/workbench/pages/2b_AutoML.py
```
