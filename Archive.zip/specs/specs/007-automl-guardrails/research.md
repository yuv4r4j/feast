# Research: H2O Driverless AI

Sources: Driverless AI user guide 1.10.7 (key features, MLI overview, scoring pipelines) and H2O's 2019 blog on AutoML for regulated industry. Confirmed there: interpretability setting drives feature-engineering complexity and, at 7 or higher, monotonicity constraints in XGBoost; reproducible mode; ensembles can be disabled; MLI with K-LIME, Shapley, decision tree surrogate, partial dependence, ICE, sensitivity analysis and downloadable reason codes; AutoDoc as a Word report; MOJO (Java, C++) and Python scoring pipelines; Python client.

Not confirmed, so treated as platform work or open points:
- Native export to MLflow: the platform logs artifacts itself.
- Disparate impact testing in the installed version: the platform runs its own check from `policy/fair_lending.yaml`.
- Accuracy and time setting details and expert-setting names: confirm against the installed version.
