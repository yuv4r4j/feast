# Tasks: Five-metric monitoring

## Phase 1: Setup
- [ ] T001 `policy/monitoring.yaml`: bands per metric, frequency per tier

## Phase 2: User Story 1 - Monthly verdict (P1)
- [ ] T002 [P] [US1] Golden tests in `tests/golden/test_monitoring_nov.py` from synthetic November data (SC-001)
- [ ] T003 [P] [US1] Calculators in `jobs/monitoring/psi.py`, `ks.py`, `csi.py`, `delinquency.py`
- [ ] T004 [US1] Verdict, Unknown against the tier's frequency, and "Not measured" reasons in `jobs/monitoring/verdict.py`

**Checkpoint**: XCE01 and ACE09 verdicts match the spec's independent test

## Phase 3: User Story 2 - Feature drift (P1)
- [ ] T005 [US2] Feature × model CSI matrix and impact preview in `api/readmodels/feature_usage.py`

## Phase 4: User Story 3 - MMR (P2)
- [ ] T006 [P] [US3] Test N18: report missed at the tier's frequency opens E6; T4 never does
- [ ] T007 [US3] MMR, Last MMR, Next MMR, MMR Status derived in `api/readmodels/monitoring.py`

## Phase 5: Polish
- [ ] T008 Aggregate view (FR-008) in `api/readmodels/aggregate.py`
- [ ] T009 CronJob manifest in `deploy/helm/smokey/templates/monitoring-cronjob.yaml` and run log
