# Feature Specification: Five-metric monitoring and the MMR

**Feature Branch**: `004-monitoring` · **Created**: 2026-11-22 · **Status**: Draft
**Input**: "All features and model metrics measured at each model: KS, PSI, CSI, early delinquency and dynamic delinquency"; MMR is the monthly model monitoring report.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Monthly verdict per model (Priority: P1)
Each month the system computes five metrics on each model's own population and shows a verdict first, with the worst metric open.

**Independent Test**: XCE01 in November shows "3 of 5 metrics in breach. Read PSI first."; ACE09 (no evaluation since September) shows "Unknown, not a pass".

**Acceptance Scenarios**:
1. **Given** PSI ≥ 0.25, **Then** PSI band is Breach; 0.10–0.25 Watch; below 0.10 Stable. CSI uses the same bands per feature.
2. **Given** KS dropped ≥ 20% from validation KS, **Then** Breach; 10–20% Watch.
3. **Given** early delinquency actual / expected to date ≥ 1.25 on the latest observable cohort, **Then** Breach; ≥ 1.10 Watch. Cohorts mature after 3 months; partial cohorts are labelled.
4. **Given** dynamic delinquency (30+ DPD of accounts scored, against expected) ≥ 1.20, **Then** Breach; ≥ 1.10 Watch.
5. **Given** a non-scoring model (CECL, stress, collections), **Then** delinquency metrics show "Not measured" with the reason.

### User Story 2 - Feature drift across models (Priority: P1)
A user sees each feature's CSI inside every model that reads it, and the impact of a feature change before it happens.

**Independent Test**: bureau_utilisation shows CSI 0.35–0.39 across 6 models; impact preview lists 6 live models and 2 versions in flight.

### User Story 3 - MMR record in the inventory (Priority: P2)
MMR holds the frequency the tier requires (Monthly for T1–T2, Quarterly for T3, Outcomes only for T4). Last MMR, Next MMR and MMR Status update from monitoring runs; a run missed at that frequency sets Overdue and opens E6.

### Edge Cases
- Late data: evaluation older than the tier's monitoring frequency → Unknown.
- Metrics never combine into one score.
- Thresholds are placeholders for policy. [NEEDS CLARIFICATION: confirmed thresholds per metric and tier]

## Requirements *(mandatory)*
- **FR-001**: Compute PSI, KS drop, CSI per feature, early delinquency (30+ DPD within 3 months by scoring cohort) and dynamic delinquency (30+, 60+, 90+ DPD monthly) per model per month.
- **FR-002**: Bands from `policy/monitoring.yaml`.
- **FR-003**: Verdict text: count of metrics in breach and the one to read first, or Unknown when stale.
- **FR-004**: Monitoring frequency by tier: monthly T1–T2, quarterly T3, outcomes only T4. Staleness, Unknown and E6 are judged against the tier's frequency, never a fixed monthly clock. The MMR inventory column is derived from the tier.
- **FR-005**: Per-feature CSI uses the feature list from the version's Feast feature service.
- **FR-006**: Breach opens E5 until acknowledged; the owner's disposition is recorded via 003.
- **FR-007**: Portfolio summaries (counts by band) for the SVP, never averaged.
- **FR-008**: Aggregate view (SR 26-2: risk "individually and in aggregate"): counts by tier × band, models sharing a feed or an upstream model, and exposure in breach, each as a count or sum with its list, never as one score.

## Success Criteria *(mandatory)*
- **SC-001**: November synthetic run reproduces PSI 4/3/25/2, KS 4/1/27/2, CSI 7/1/24/2 (breach/watch/stable/not measured).
- **SC-002**: Monthly run for 2,000 models completes in under 30 minutes.
- **SC-003**: Every model page answers "which metric first?" without scrolling.
