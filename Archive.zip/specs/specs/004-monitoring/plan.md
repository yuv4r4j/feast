# Implementation Plan: Five-metric monitoring

## Summary
Batch jobs (Airflow or Kubernetes CronJob) compute metrics from scoring logs and outcomes, write `monitoring` read model, emit `MonitoringRecorded` events and update MMR fields.

## Technical Context
**Language**: Python 3.12 · **Dependencies**: pandas / polars, numpy, scipy (KS), Feast SDK (feature lists), SQLAlchemy · **Storage**: monitoring tables in PostgreSQL; inputs from the scoring log store [NEEDS CLARIFICATION: scoring log and outcome sources] · **Testing**: pytest with fixtures from `synthetic-portfolio/model_drift_monthly.csv`, `model_feature_csi_monthly.csv`, `delinquency_monthly.csv`

## Constitution Check
V never combined ✅ · VI Unknown ✅ · III thresholds in policy ✅

## Structure
```
jobs/monitoring/psi.py ks.py csi.py delinquency.py verdict.py
policy/monitoring.yaml
api/readmodels/monitoring.py
```
