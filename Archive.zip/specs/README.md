# SMOKEY specs (GitHub Spec Kit layout)

Spec-driven development for the card credit risk model lifecycle control plane. Reference material: the design canvas, the role-based demo (`smokey-demo-roles.html`), the proposal deck and the synthetic portfolio in `synthetic-portfolio/`.

## Layout
```
memory/constitution.md          principles every feature must pass
specs/001-inventory-and-keys/   inventory columns, 5-letter keys, tools register
specs/002-tiering/              SR 26-2 tiers from Exposure, Reliance, Uncertainty
specs/003-lifecycle-and-governance/  commands, separation of duties, E1–E9 (data-model.md, contracts/)
specs/004-monitoring/           PSI, KS, CSI, early and dynamic delinquency, MMR
specs/005-sources-reconciliation/    Feast, MLflow, cluster; E2
specs/006-portfolio-and-queue/  SVP queue R1–R4, L1–L4
specs/007-automl-guardrails/    H2O Driverless AI inside policy
specs/008-role-apps-and-ux/     Streamlit apps, screen patterns, walkthroughs
specs/009-platform-and-deployment/  Kubernetes/OpenShift, SSO, admin console
```
Each feature has `spec.md` (what and why: user stories, acceptance scenarios, requirements, success criteria), `plan.md` (how: technical context, constitution check, structure) and `tasks.md` (ordered tasks; `[P]` parallel, `[USn]` story).

## Build order (first vertical slice)
001 → 003 → 002 → 005 → 004 → 007 → 006 → 008 → 009. The slice from the deck takes one real tier 3 model from registration to a monitored non-production deployment with three people in three roles.

## Using with Spec Kit
Copy `memory/` into `.specify/memory/` and `specs/` to the repository root. Resolve every `[NEEDS CLARIFICATION]` with Spec Kit's clarify step before running its tasks or implement steps for that feature. Command names vary by Spec Kit version (recent versions prefix them, for example `/speckit.clarify`); check the version you install. The section headings follow the Spec Kit templates as I know them and were not checked against the current release.

Extra files: `002-tiering/research.md`, `007-automl-guardrails/research.md`, `003-lifecycle-and-governance/acceptance-tests.md` (the 30 tests), `quickstart.md` (the slice), `data-model.md`, `contracts/commands.yaml`.

## Blocking decision
- What happens when a 3-letter name reaches 99 (001). Capacity is 4,455 keys in total and ACE already uses 29 of 99.

## Open clarifications
- Bureau precedence for models reading two bureaus; portfolio scope letter (001)
- Confirmed tier bands and thresholds (002); monitoring thresholds (004)
- Scoring log and outcome sources (004)
- Queue rule R2 against the capacity item's tag (006)
- Fair-lending test and threshold, owned by compliance; protected-group estimation method; installed Driverless AI version (007)
- CI/CD and GitOps tools; RPO/RTO (009)

## Change log
- 2026-11-22 animation: demo moved to R2D3-style scroll-driven animation; constitution X (1.1.1) and 008 (FR-006 to FR-008, SC-003, Phase 6 tasks) updated. Decided: scroll animation in the Streamlit apps comes from one custom chart component, `smokey_charts` (008 FR-008 to FR-012, Phase 6). Open: which Streamlit component API the pinned version offers (008 plan; task T009 is a spike that gates the rest).
- 2026-11-22 review: each model gets a hidden internal Model ID and its own MLflow registered model (the shared 3-letter name could not carry one champion alias for 22 models); monitoring staleness follows the tier's frequency; the platform's two permitted MLflow writes are stated; Streamlit ≥ 1.42; fair-lending threshold moved to policy; added requirements for vendor models, aggregate risk, T4 materiality watch, review scheduler, retirement and policy changes; 30 acceptance tests enumerated; tasks for 004–009 given file paths, phases and checkpoints.
