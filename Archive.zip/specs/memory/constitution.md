# SMOKEY Constitution
Card credit risk · model lifecycle control plane

Version 1.1.1 · Ratified 2026-11-22 · Amended 2026-11-22 (IV write exception; IX internal model ID) · Applies to every feature under `specs/`

## Core principles

### I. The API decides; Streamlit shows
Every state change is a command to the control-plane API. The API either appends an event or refuses with the rule it applied. No screen accepts a typed status, tier or approval. Streamlit apps hold no authority and render only what the API returns.

### II. Events are the source of truth
State is derived from an append-only, hash-chained event log. Read models are rebuildable from the log at any time. Events are never edited or deleted; corrections are new events.

### III. Rules are data
Thresholds, tier weights, floors, queue admission rules, naming rules and refusal rules live in versioned policy configuration, changed by pull request and reviewed. Code reads rules; it does not hard-code them. Every refusal names its rule ID (for example TIER-02, NAME-02, AML-01).

### IV. Sources, never authority
Feast, MLflow, the deployment pipeline and the cluster are read and compared. A registry alias is a label, not an approval. When any two readings disagree, the reconciler raises an exception (E2). The platform writes to a source in exactly two cases: it moves an MLflow alias after AuthoriseRelease, and it sets the `smokey.key` tag on an MLflow model version. It never writes approval, tier or status into a source.

### V. Four positions, never one score
Every model is placed on development, governance, deployment and production health. Monitoring metrics are shown side by side and never combined. Exception conditions read across positions; nothing is averaged.

### VI. Unknown is never a pass
Missing, stale or late data is shown as Unknown, next to Breach. A missed monitoring report is health Unknown (E6), not Healthy.

### VII. Separation of duties is enforced server-side
Developers build, validators challenge and recommend, approval authorities approve, owners decide use, operations deploy. The API refuses any command that crosses these lines, whatever the UI shows.

### VIII. Tiering follows SR 26-2 and inherent risk
Materiality comes from purpose and exposure; inherent risk from complexity, assumptions and implementation. Tier inputs are facts known at registration, never validation results. Overrides only raise a tier. (SR 26-2, 17 Apr 2026; Kiritz, Ravitz and Levonian, JRMV 13(2), 2019.)

### IX. One key per model version
Every model version is identified by its 5-letter key: a 3-letter Model Name (bureau or scope, type, channel) and a two-digit counter shared under that name (for example QCE03). The key is what people see. Behind it, every model has a stable internal Model ID that links its versions, is never shown on a screen and never changes. Legacy IDs live only in Legacy Name.

### X. Calm, accessible screens
Each screen opens with one "Look for" line and a verdict before detail. Detail is one click away. Colour is never the only carrier of meaning. Every screen meets WCAG 2.2 AA, works at phone width and honours reduced motion. Motion follows the reader: marks animate from the scroll position, never on a timer, so nothing moves unless the reader moves it.

### XI. Test the refusals
Every rule has at least one negative test that proves the system refuses or flags. A feature is not done until its refusals are tested.

## Constraints
- Regulatory frame: SR 26-2 (supersedes SR 11-7), OCC Bulletin 2026-13, FDIC FIL-15-2026; ECOA / Reg B for adverse-action reasons.
- Data: production customer data never leaves approved stores; demos and tests use the synthetic 40-model portfolio in `synthetic-portfolio/`.
- Thresholds and tier boundaries are policy placeholders until the policy baseline is confirmed.

## Governance
- This constitution overrides feature specs. A plan that violates a principle must record the justification in its Complexity Tracking table, or change.
- Amendments: pull request with rationale, approval by the head of model risk and the platform lead; version bump (major for removed or redefined principles, minor for additions, patch for wording).
- Every plan includes a Constitution Check gate before design and again after design.
