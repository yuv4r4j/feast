#!/usr/bin/env bash
# Deploy or update the SMOKEY demo.
# Usage: ./deploy.sh            (Kubernetes, uses k8s/ingress.yaml)
#        ./deploy.sh openshift  (OpenShift, creates an edge Route)
set -euo pipefail
cd "$(dirname "$0")"
NS=smokey-demo
CLI=kubectl; [ "${1:-}" = "openshift" ] && CLI=oc

$CLI apply -f k8s/namespace.yaml
# create or update the page; restart so pods pick it up
$CLI -n "$NS" create configmap smokey-demo-html --from-file=index.html=index.html \
  -o yaml --dry-run=client | $CLI apply -f -
$CLI apply -f k8s/deployment.yaml -f k8s/service.yaml
if [ "${1:-}" = "openshift" ]; then
  $CLI -n "$NS" get route smokey-demo >/dev/null 2>&1 || $CLI -n "$NS" create route edge smokey-demo --service=smokey-demo
  $CLI -n "$NS" get route smokey-demo -o jsonpath='{.spec.host}{"\n"}'
else
  $CLI apply -f k8s/ingress.yaml
fi
$CLI -n "$NS" rollout restart deploy/smokey-demo
$CLI -n "$NS" rollout status deploy/smokey-demo
echo "Local check: $CLI -n $NS port-forward svc/smokey-demo 8080:80  ->  http://localhost:8080"
