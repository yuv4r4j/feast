# SMOKEY demo on Kubernetes or OpenShift

The demo is one static file, `index.html` (the role-based walkthrough demo, about 265 KB). It needs only a web server.

## Deploy or update

    ./deploy.sh              # Kubernetes (edit k8s/ingress.yaml first: host, class, TLS secret)
    ./deploy.sh openshift    # OpenShift: creates an edge Route and prints its host

The script puts `index.html` in a ConfigMap, serves it with unprivileged nginx (2 replicas), and restarts the pods.
To publish a new version of the demo, replace `index.html` and run the script again.

## Check it

    kubectl -n smokey-demo port-forward svc/smokey-demo 8080:80
    # open http://localhost:8080

## Built image instead of a ConfigMap (for CI)

    docker build -t <registry>/smokey-demo:1 .
    docker push <registry>/smokey-demo:1

Then in `k8s/deployment.yaml` set `image:` to that tag and remove the `html` volume and volumeMount.

## Before sharing

- Keep it on an internal host behind single sign-on (oauth2-proxy, or the OpenShift OAuth proxy). The data is synthetic, but it shows your inventory schema and governance design.
- The page loads Inter from Google Fonts. Without internet it falls back to system fonts; to remove the call, delete the two `fonts.googleapis.com` lines in `index.html`.
- Chosen walkthrough and tour mode are stored in each viewer's browser; nothing is stored server-side.

## Animation (updated 2026-11-22)

`index.html` now animates the way R2D3 does: nothing plays on a timer. One animation loop reads the scroll position, eases it (R2D3's ZENO easing, factor 0.85), and sets every mark from it: lines draw, bars grow, numbers count up and blocks fade in as they enter the screen. On the "Why is this here?" screen the chart stays pinned while the squares regroup step by step as you scroll.

With the operating system's reduce-motion setting on, nothing eases or fades: content is shown complete and the squares jump between steps.

No deployment change is needed; replace `index.html` and run `./deploy.sh` as before.
