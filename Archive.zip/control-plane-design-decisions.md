# Risk Model Lifecycle Control Plane: design decisions

As of 2026-11-21. Full design: https://claude.ai/artifact/JnVahcPVQQTo862LL4W2wY
Synthetic data: `synthetic-portfolio/` in the smokey folder (seeded generator, 400 models, three planted issues, one decoy).

## Positions the design takes

1. The product is a lifecycle control plane. AutoML is one producer of evidence that feeds it.
2. Streamlit is UI only. A control-plane API (FastAPI) is the sole writer of state, in front of one PostgreSQL database and one object store.
3. Status is never typed. It is a projection over an append-only, hash-chained event log fed by source systems and role-checked human decisions.
4. Four independent state dimensions: development and governance (per version), deployment (per version and environment), production health (per deployment). No percent-complete and no composite health score.
5. Nine named exception conditions (E1 to E9) are predicates across those dimensions, each with a holder of the next action. They drive the executive view.
6. Automation is asymmetric: systems may block, flag, expire and downgrade. Only named humans approve, accept risk or waive.
7. Missing or stale input resolves to Unknown, never to a passing state.
8. Segregation of duties is computed per model version from event history (who committed, ran experiments, authored evidence), plus roles. Administrators cannot hold governance roles.
9. Deployment consumes a signed, expiring release authorization bound to artifact digest, environment and intended use. The pipeline can verify one and cannot create one.
10. The SVP landing page is a decision queue of at most seven items, with drill-down to source events.

## Tool verdicts

Required: FastAPI, PostgreSQL, Git, enterprise OIDC SSO. Keep as UI only: Streamlit. Use for tracking and artifacts only: MLflow (registry labels are a mirror, never governance state). Library inside training jobs: Optuna. Use existing: CI/CD, OpenShift. Deferred: workflow orchestration engine, message broker.

## Unverified assumptions (A1 to A8)

US banking organization above about $30B under the April 2026 interagency guidance (SR 26-2 / OCC 2026-13, which superseded SR 11-7); mostly credit-risk portfolio; only a minority of models are AutoML candidates; validation is organizationally separate; an existing GRC inventory may or may not exist; OpenShift, OIDC, S3-compatible storage and CI/CD are available; scoring logs and outcomes are reachable; tier, severity and review-frequency values are placeholders.

## Open decisions

- Regulator and policy baseline; tier definitions, finding severities, review frequencies
- Whether an inventory system of record already exists
- Count of the 400 models by build type
- Approval authority per tier
- One tier 3 model and three people (developer, validator, approver) for the first vertical slice
- Pipeline team agreement to add an authorization-verification step in non-production
- Identity provider exposing groups and reporting lines

## Update 2026-11-22: what has changed since this note

This note was written on 2026-11-21 against a 400-model portfolio. Current state:

- **Portfolio:** 40 card credit risk models (38 models and 17 tools under SR 26-2), not 400.
- **Name:** the product is SMOKEY. Design canvas, role-based demo and deck are separate artifacts; local copies are in the dated folders here.
- **Sources:** Feast (feature usage and drift) and MLflow (registry) are read and compared; an alias is not an approval.
- **Monitoring:** five metrics per model: PSI, KS, CSI, early delinquency and dynamic delinquency, never combined.
- **Tiering:** four tiers scored from the inventory's Exposure, Reliance and Uncertainty plus implementation risk, checked against SR 26-2 and Kiritz, Ravitz and Levonian (2019). Proposed, pending approval.
- **Model keys:** every model is shown by a 5-letter key (for example QCE03). Open: what happens when a name reaches 99.
- **AutoML:** H2O Driverless AI inside policy guardrails is the developer's search tool (replaces the Optuna-only position above for AutoML candidates).
- **Animation:** the demo uses R2D3-style scroll-driven animation; see `r2d3-scroll-2026-11-22/README.md`.
- **Specs:** `specs/` holds the constitution and nine feature specs for the build. They supersede this note where they differ.
- **Deployment:** `deploy/` holds the Kubernetes and OpenShift files for the demo.
