# Demo with R2D3-style scroll animation (2026-11-22)

- `smokey-demo-roles.html`: the role-based walkthrough demo, now scroll-driven. Same file as `deploy/index.html`.
- `demo_tpl-roles.html`: its template (data placeholder `/*DATA*/`).
- `test_scroll.js`: Playwright check used to validate it (expects the demo at `demo/smokey-demo.html` beside it).

## What was taken from the R2D3 mirror (`r2d3-mirror/decision-trees-part-1-main.js`)
- One `requestAnimationFrame` loop; the scroll position is eased each frame with `ZENO(current, actual)`: remainder × 0.85, snapping below 0.05.
- Every animated property is a clamped linear function of that eased position (R2D3 uses clamped `d3.scale.linear`).
- The graphic stays pinned while the narrative scrolls past it.

## How it is applied
| Element | Behaviour |
|---|---|
| Blocks (cards, strips, verdicts, notes) | fade and rise 18px over 26% of the screen height as they enter at 92% |
| Chart lines | draw from left to right over 42% of the screen height |
| Early-delinquency bars | grow from the axis |
| Headline numbers | count up from 0 |
| "Why is this here?" squares | pinned chart; four scroll steps; squares move during the last 45% of each step |
| Page change | the eased position starts 0.9 screens above, so the first screen flows in top to bottom |

## Validation (headless Chromium, 1300×900 and 390×844)
- Squares sit at the expected coordinates at each of the four steps and at interpolated coordinates mid-step.
- A chart line's dash offset goes 540.7 → 386.6 → 0 as it scrolls into view.
- With reduce-motion emulated: no dash, fade or count styles are set; squares snap between steps.
- All 16 screens: no script errors, no sideways scroll, nothing left hidden at the bottom of the page. All 7 role walkthroughs still run end to end.
- Not checked: other browsers, real touch scrolling, performance on slow machines.
