import re,glob,json,os
P='canvas/project/'
src=open('gen_canvas.py').read()
HEAD=re.search(r"HEAD='''(.*?)'''",src,re.S).group(1)
STY=re.search(r"STY='''(.*?)'''",src,re.S).group(1)
G='<a href="Lifecycle.dc.html">Lifecycle</a><a href="ActionIndex.dc.html">All screens</a>'
changed=[]
def save(f,s,o):
    if s!=o: open(P+f,'w').write(s);changed.append(f)
for path in sorted(glob.glob(P+'*.dc.html')):
    f=os.path.basename(path);o=s=open(path).read()
    if f in('Lifecycle.dc.html',):continue
    if 'href="Lifecycle.dc.html"' not in s:
        m=re.search(r'(<nav class="nav"[^>]*>.*?)(</nav>)',s,re.S)
        if m: s=s[:m.end(1)]+G+s[m.start(2):]
    if f=='Main.dc.html': s=s.replace('<a href="#">{{r.id}}</a>','<a href="SVP-L3.dc.html">{{r.id}}</a>').replace('href="#"','href="SVP-L2.dc.html"')
    if f in('L1.dc.html','L1-states.dc.html'): s=s.replace('href="#"','href="SVP-L2.dc.html"')
    if f=='Ops-Alerts.dc.html': s=s.replace('<a href="#">Check feed</a>','<a href="Feat-Usage.dc.html">Check feed</a>')
    if f=='Gov-Approval.dc.html': s=s.replace('<a href="#">Decided</a>','<span class="mut" style="padding:10px 12px">Decided · not drawn</span>')
    if f=='Own-Inbox.dc.html': s=s.replace('<a class="btn" href="#">Escalate a resource conflict to the SVP</a>','<a class="btn" href="Main.dc.html">Escalate a resource conflict to the SVP</a>')
    if f=='SVP-L4.dc.html': s=s.replace('<a href="#">Open in {{r.sys}}</a>','<span class="mut">Opens {{r.sys}} · outside this design</span>')
    if f=='Login.dc.html' and 'Design navigation' not in s:
        a='<p class="mut">A person with two roles still cannot act in both on the same model version';assert a in s
        s=s.replace(a,'<p class="mut"><b>Design navigation · every role home:</b> <a href="Main.dc.html">SVP</a> · <a href="Own-Inbox.dc.html">Owner</a> · <a href="Dev-Queue.dc.html">Developer</a> · <a href="Val-Queue.dc.html">Validator</a> · <a href="Gov-HoV.dc.html">Head of validation</a> · <a href="Gov-Approval.dc.html">Approval authority</a> · <a href="Gov-HoMR.dc.html">Head of model risk</a> · <a href="Compliance.dc.html">Compliance</a> · <a href="Ops-Alerts.dc.html">Operations</a> · <a href="Audit.dc.html">Internal audit</a> · <a href="Adm-Status.dc.html">Administrator</a> · <a href="Lifecycle.dc.html">Lifecycle</a> · <a href="ActionIndex.dc.html">All screens</a></p>\n'+a,1)
    if f=='ActionIndex.dc.html' and 'Role home pages' not in s:
        a='<table class="t">\n<thead><tr><th scope="col" style="width:22%">Action</th>';assert a in s
        s=s.replace(a,'<div class="box"><div class="lab">Role home pages</div><span><a href="Lifecycle.dc.html"><b>Lifecycle: the 14 stages</b></a> · <a href="Login.dc.html">Login</a> · <a href="Main.dc.html">SVP</a> · <a href="Own-Inbox.dc.html">Owner</a> · <a href="Dev-Queue.dc.html">Developer</a> · <a href="Val-Queue.dc.html">Validator</a> · <a href="Gov-HoV.dc.html">Head of validation</a> · <a href="Gov-Approval.dc.html">Approval authority</a> · <a href="Gov-HoMR.dc.html">Head of model risk</a> · <a href="Policy.dc.html">Policy</a> · <a href="Compliance.dc.html">Compliance</a> · <a href="Ops-Alerts.dc.html">Operations</a> · <a href="Audit.dc.html">Internal audit</a> · <a href="Adm-Status.dc.html">Administrator</a> · <a href="Feat-Usage.dc.html">Features</a> · <a href="Registry.dc.html">Registry</a> · <a href="Tiering.dc.html">Tiering</a> · <a href="Standards.dc.html">Model Code standard</a> · <a href="Scenarios.dc.html">Scenarios</a> · <a href="Patterns.dc.html">Patterns</a> · <a href="Manifest.dc.html">Number manifest</a></span></div>\n'+a,1)
        b="g('Model developer · Workbench'),"
        s=s.replace(b,"""g('Full lifecycle · stages specified in 011, not yet drawn'),
r('Assess a candidate: model, tool or neither','Lifecycle 0','Lifecycle.dc.html','AssessCandidate','RegisterModel refused without an assessment (ID-01)'),
r('Approve a model charter','Lifecycle 1','Lifecycle.dc.html','ApproveCharter','Build refused without it (INIT-01)'),
r('Approve a model use and its decision strategy','Lifecycle 6 and 9','Lifecycle.dc.html','ProposeUse / ApproveUse / ChangeStrategy','No release without an approved use (USE-01); swap-set for a strategy change (USE-02); reason codes signed (RC-01)'),
r('Record implementation verification and fallback test','Lifecycle 7','Lifecycle.dc.html','RecordImplementationVerification / RecordFallbackTest','Release refused without them (IMPL-01, IMPL-02)'),
r('Raise and classify a change request','Lifecycle 12','Lifecycle.dc.html','RaiseChangeRequest / ClassifyChange','CreateVersion refused without a class (CHG-01); requester cannot lower it (CHG-02)'),
r('Record an upstream change (bureau attributes, vendor score)','Lifecycle 12','Lifecycle.dc.html','RecordUpstreamChange / SwitchInputVersion','Switch refused without an impact analysis (UP-01)'),
r('Open and close a review with attestation','Lifecycle 11','Lifecycle.dc.html','OpenReview / CloseReview','Overdue review opens an exception (REV-01); closes only with attestation (ATT-01)'),
r('Archive, hold and delete','Lifecycle 13','Lifecycle.dc.html','ArchiveVersion / SetLegalHold / ApproveDeletion','Retire refused with a live use (RET-01); delete refused under retention or hold (RET-02)'),
"""+b,1)
    save(f,s,o)
ST=[('Identify','Is it a model, a tool or neither? The reason is recorded.','ID-01','LIVE','Proposer; model risk decides',[('Tiering.dc.html','T1 Tiering and tools')],'part'),
('Initiate','Model charter: purpose, intended uses, target, windows, exclusions. Key issued.','INIT-01 · NAME-01','LIVE',' Owner; model risk',[('Own-Release.dc.html','O3 Register')],'part'),
('Source data','Approved feature views; data quality assessed; input versions pinned.','DATA-01 · AML-01','LIVE','Developer',[('Feat-Usage.dc.html','F1 Feature usage')],'part'),
('Build','Eight phases; AutoML suggests, the developer decides.','AML-02 to AML-04','PRACTICE','Developer',[('Dev-AutoML.dc.html','D2b Model build'),('Dev-Version.dc.html','D2 Version')],'drawn'),
('Developer evidence','Freeze, test battery, attest and submit.','AML-05 · evidence gate','LIVE','Developer',[('Dev-Evidence.dc.html','D3 Evidence')],'part'),
('Validate','Intake, own plan, sample and challenger, findings, conclusion.','IND-HIST-01 · VAL-PLAN-01','LIVE','Validator',[('Val-Intake.dc.html','V2 Intake'),('Val-Case.dc.html','V3 Case file'),('Val-Findings.dc.html','V4 Findings'),('Val-Conclusion.dc.html','V5 Conclusion')],'drawn'),
('Approve','Decision with terms; each use approved; reason codes signed.','VAL-01 · USE-01 · RC-01','LIVE · LAW','Approval authority; compliance',[('Gov-Approval.dc.html','G2 Approval'),('Compliance.dc.html','G5 Compliance')],'part'),
('Implement','The decision engine reproduces the approved score; fallback tested.','IMPL-01 · IMPL-02','POLICY','Technology owner; independent tester',[('Ops-Deploy.dc.html','P2 Deployment (parity only)')],'part'),
('Release','Signed authorisation; shadow or staged rollout.','OPS-ROLL-01','PRACTICE','Owner; operations',[('Own-Release.dc.html','O3 Release'),('Ops-Deploy.dc.html','P2 Deployment')],'drawn'),
('Use','Scoring records, overrides against limits, strategy tests, user attestation.','USE-01','LAW · LIVE','Operations; credit policy',[],'spec'),
('Monitor','Five metrics; breach disposition; outcomes analysis.','bands from policy','LIVE','Owner; operations',[('SVP-Drift.dc.html','L2 Drift'),('Ops-Alerts.dc.html','P1 Alerts'),('Own-Breach.dc.html','O2 Breach')],'part'),
('Review','Monitoring report, annual review, full revalidation; triggers; attestation.','REV-01 · ATT-01','POLICY · LAW','Model risk; owner',[('Own-Release.dc.html','O3 Attest continued use'),('Gov-HoV.dc.html','G1 Head of validation')],'part'),
('Change','Change request with a class; upstream changes; overlays; action plans.','CHG-01 to CHG-03 · UP-01 · OVL-01','LIVE','Owner; model risk',[('Dev-Queue.dc.html','D1 Propose change class'),('Own-Breach.dc.html','O2 Overlay'),('Ops-Incident.dc.html','P3 Incident')],'part'),
('Retire','Decommission, archive that can still score, retention, legal hold, deletion.','RET-01 · RET-02','LAW','Owner; operations; compliance',[('Own-Release.dc.html','O3 Propose retirement')],'part')]
rows=''
for i,x in enumerate(ST):
    links=' · '.join('<a href="%s">%s</a>'%l for l in x[5]) or '<span class="mut">No board yet</span>'
    chip={'drawn':'<span class="chip ok">Drawn</span>','part':'<span class="chip Watch">Partly drawn</span>','spec':'<span class="chip Unknown">Specified only</span>'}[x[6]]
    rows+='<tr class="rise"><td><span style="font-size:30px;font-weight:200;line-height:1">%d</span></td><td><b>%s</b><br><span class="mut">%s</span></td><td class="mono" style="font-size:11.5px">%s</td><td><span class="lab">%s</span></td><td class="mut">%s</td><td>%s</td><td>%s</td></tr>\n'%(i+1,x[0],x[1],x[2],x[3],x[4].strip(),links,chip)
nd=sum(1 for x in ST if x[6]=='drawn');npart=sum(1 for x in ST if x[6]=='part');ns=sum(1 for x in ST if x[6]=='spec')
track=''.join('<div style="flex:1;min-width:0;border-top:6px solid %s;padding-top:6px"><span class="lab">%d</span><div style="font-size:12px;line-height:1.25">%s</div></div>'%({'drawn':'#000','part':'#D3902A','spec':'#bbb'}[x[6]],i+1,x[0]) for i,x in enumerate(ST))
lc=HEAD%('Lifecycle: the 14 stages',STY)+'''<div style="font-family:Inter,system-ui,sans-serif;color:#1a1a1a;max-width:1440px;margin:0 auto;padding-bottom:72px">
<header class="hd">
<div style="display:flex;flex-wrap:wrap;gap:20px;align-items:center"><b>Model lifecycle</b>
<nav class="nav" aria-label="Pages"><a class="cur" href="Lifecycle.dc.html" aria-current="page">Lifecycle</a><a href="ActionIndex.dc.html">All screens</a><a href="Login.dc.html">Login</a><a href="Tiering.dc.html">Tiering</a></nav></div>
<div class="mut">Design map · start here</div>
</header>
<section class="sec" aria-labelledby="h">
<div class="lab rise">The model lifecycle · 14 stages · spec 011</div>
<div class="look"><b>Look for</b>Every stage links to the board that draws it. Grey stages are specified but not drawn yet.</div>
<h1 id="h" class="rise d1">From "is it a model?" to a deletion certificate</h1>
<div style="display:flex;gap:6px" aria-hidden="true">'''+track+'''</div>
<div class="strip" role="list" style="grid-template-columns:repeat(3,minmax(0,1fr))"><div role="listitem"><span class="count">'''+str(nd)+'''</span><span class="lab">Stages drawn</span></div><div role="listitem"><span class="count">'''+str(npart)+'''</span><span class="lab">Partly drawn</span><span class="mut">a board covers some of the stage</span></div><div role="listitem"><span class="count">'''+str(ns)+'''</span><span class="lab">Specified only</span><span class="mut">in spec 011</span></div></div>
</section>
<section class="sec" aria-labelledby="s">
<h2 id="s">Stage by stage</h2>
<div style="overflow-x:auto"><table class="t"><thead><tr><th></th><th>Stage</th><th>Gate (rule)</th><th>Why it exists</th><th>Owner</th><th>Boards</th><th>Design status</th></tr></thead><tbody>
'''+rows+'''</tbody></table></div>
<p class="mut">Why it exists: LAW = statute or regulation, to be confirmed by compliance and legal · LIVE = supervisory text in force (SR 26-2, OCC card lending booklet) · POLICY = was in SR 11-7; kept only if bank policy keeps it · PRACTICE = industry and platform practice.</p>
</section>
<section class="sec" aria-labelledby="o">
<h2 id="o">Seven other things with a lifecycle of their own</h2>
<div style="overflow-x:auto"><table class="t"><thead><tr><th>Object</th><th>States</th><th>Where it shows today</th></tr></thead><tbody>
<tr><td>Candidate assessment</td><td class="mut">Proposed → decided (model, tool, neither)</td><td><a href="Tiering.dc.html">T1 Tiering and tools</a> (reclassify only)</td></tr>
<tr><td>Model use · decision strategy</td><td class="mut">Draft → approved → live → suspended → withdrawn</td><td><a href="Gov-Approval.dc.html">G2 Approval</a> (usage limit only)</td></tr>
<tr><td>Change request</td><td class="mut">Raised → classified → in progress → closed</td><td><a href="Dev-Queue.dc.html">D1 Queue</a> (propose change class)</td></tr>
<tr><td>Overlay</td><td class="mut">Proposed → approved → active → expired or withdrawn</td><td><a href="Own-Breach.dc.html">O2 Breach</a></td></tr>
<tr><td>Finding and action plan</td><td class="mut">Open → plan agreed → evidence submitted → closed, or risk accepted</td><td><a href="Val-Findings.dc.html">V4 Findings</a> · <a href="Dev-Findings.dc.html">D4 Findings</a></td></tr>
<tr><td>External input · bureau attributes, vendor scores</td><td class="mut">Due diligence passed → in use → change pending → withdrawn</td><td><a href="Ops-Incident.dc.html">P3 Incident</a> (after the fact)</td></tr>
<tr><td>Scoring records</td><td class="mut">Active → under retention → on hold → expired → deleted</td><td><span class="mut">No board yet</span></td></tr>
</tbody></table></div>
<div class="ann">apps/governance/pages/lifecycle.py · GET /models/{key}/lifecycle returns the 14 stages with state, gate, authority and the artefact for each · the track is st.columns(14) or smokey_chart("track") · every stage is an st.page_link to the page that owns it · this page is the answer to "where am I, and what comes next"</div>
</section>
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1440,"height":2300}}'>
class Component extends DCLogic { renderVals(){ return {}; } }
</script>
</body>
</html>
'''
o=open(P+'Lifecycle.dc.html').read() if os.path.exists(P+'Lifecycle.dc.html') else ''
save('Lifecycle.dc.html',lc,o)
c=json.load(open(P+'canvas.json'))
c['boards']['Lifecycle.dc.html']={'x':4560,'y':0,'w':1440,'h':2300,'title':'Lifecycle: the 14 stages, their gates and the board for each (start here)','page':'access','expand':'fill'}
if 'Lifecycle.dc.html' not in c['order']: c['order'].insert(0,'Lifecycle.dc.html')
json.dump(c,open(P+'canvas.json','w'),indent=2)
print(len(changed));print(json.dumps([{'path':'project/'+f} for f in changed if f!='Lifecycle.dc.html']+[{'path':'project/canvas.json'}]))
