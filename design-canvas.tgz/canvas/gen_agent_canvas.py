import json,html,re,os
P='canvas/project/';A=json.load(open('agd.json'))
X={ # boards with no demo screen of the same scope
'Dev-Queue':['Change request','What is asked, parent version, feature and parameter difference, downstream models','Version record · dependency map','Model developer','The proposed change class and its reason'],
'Dev-Evidence':['Developer evidence pack','Test battery results, frozen digests, dataset definitions, calibration and stability tables','Build log · test runs','Model developer','The developer\'s attestation'],
'Dev-Findings':['Response to findings','Each finding, the evidence gathered since, what changed in the new version','Findings register · version difference','Model developer','Whether the developer agrees; the commitment and date'],
'Val-Queue':['Case queue summary','Cases by tier and age, due dates, what is blocked and on whom','Case queue','Validator','Nothing: this page takes no decision'],
'Val-Intake':['Intake note','Completeness check against the evidence standard, what is missing','Submitted evidence · policy','Validator','Accept or return, and why'],
'Val-Findings':['Findings register entries','The observation, the evidence and the affected section for each finding','Validation case file','Validator','Severity and the required action'],
'Val-Conclusion':['Validation report: conclusion pages','Summary of work done and findings by severity','Validation case file','Validator','The conclusion and the recommendation'],
'Own-Inbox':['Owner\'s monthly summary','Decisions waiting, models by state, what changed since last month','Decision queue · monitoring','Model owner','Nothing: this page takes no decision'],
'Own-Release':['Release authorisation and annual attestation text','Version, digest, environment, usage limit, conditions carried from approval','Approval record · inventory','Model owner','The attestation that use matches the approval'],
'Ops-Deploy':['Deployment record','Authorisation checked, shadow and parity results, promotion steps with times','Deployments · parity runs','Model operations','The decision to promote'],
'Ops-Incident':['Incident record','Timeline, affected models and decisions, actions taken, rollback evidence','Alerts · deployments · event log','Model operations','Root cause and the break-glass justification'],
'Adm-Status':['Platform status report','Integrations up or down, last sync times, failed jobs','Health checks','IT administrator','Nothing: this page takes no decision'],
'Adm-Access':['Access review workpaper','Who holds which role, grants and removals since the last review, conflicts','Role grants · event log','IT administrator; reviewed by model risk','Approval of each grant'],
'Standards':['Model Code gap report','Models whose key breaks the standard and what a compliant key would be','Inventory · naming standard','Head of model risk','Any amendment to the standard'],
'SVP-L4':['Evidence index','The source records behind each number on the path, with hashes','Event log · sources','SVP office','Nothing: this page takes no decision'],
'SVP-Actions':['Follow-up note and briefing','The item, who it is assigned to, the due date, the evidence','Decision queue','SVP, card credit risk','The instruction itself'],
'Assistant':['Monitoring Q&A log extract','Questions asked, answers given, the records cited','Assistant log','Model owner','Anything sent outside the team'],
'Patterns':['Shared pattern: agent draft','Every board ends with this block: what an agent drafts, from which records, who signs','Control-plane read APIs','The named role on each board','Judgement, conclusions, approvals, attestations'],
}
MAP={'Dev-Version':'automl','Dev-AutoML':'automl','Val-Case':'validator','Gov-HoV':'hov','Gov-Approval':'approval','Gov-HoMR':'homr','Own-Breach':'owner','Ops-Alerts':'ops','Audit':'audit','Policy':'policy','Compliance':'compliance','Tiering':'tier','Feat-Usage':'feature','Registry':'registry','Main':'l0','L1':'l1','SVP-L2':'l2','SVP-Drift':'drift','SVP-L3':'model','Lifecycle':'lifecycle','Campaign':'campaign','LiveTest':'livetest','CycleTime':'cycle','Recalibration':'recal','Research':'research','Platform':'platform'}
SKIP={'Adjust','Monitor','TierCard','InventoryRecord','Login','Scenarios','L1-states','Manifest','ActionIndex'}
e=html.escape
def block(a,extra=''):
    td='style="text-align:left;padding:6px 16px 6px 0;vertical-align:top;border-bottom:1px solid #dccdee;font-size:13px"'
    th='style="text-align:left;padding:6px 16px 6px 0;vertical-align:top;border-bottom:1px solid #dccdee;font-size:10.5px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;width:150px;color:#6B2FA0"'
    rows=[('Drafts','<b>%s</b>'%e(a[0])),('Fills in',e(a[1])),('Reads only',e(a[2])),('Signed by',e(a[3])),('Never writes',e(a[4]))]
    return ('<section data-agd="1" aria-label="AI agent documentation" style="margin:28px 40px 0;border-left:6px solid #6B2FA0;background:#F3ECFA;padding:16px 20px;display:flex;flex-direction:column;gap:8px">'
     '<div style="font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#6B2FA0"><span style="display:inline-block;background:#6B2FA0;color:#fff;padding:3px 8px;margin-right:8px">AI agent</span>What it can document here</div>'
     '<table style="border-collapse:collapse;width:100%;max-width:980px"><tbody>'+''.join('<tr><th scope="row" %s>%s</th><td %s>%s</td></tr>'%(th,k,td,v) for k,v in rows)+'</tbody></table>'
     '<div style="font-size:12.5px;color:#555">The draft is not a record until the named person signs it (rule AGENT-02). Judgement sections are left blank (AGENT-03).'+extra+' POST DraftDocument returns a draft with a hash and the agent, model and prompt version; SignDocument is a person\'s command · Streamlit: st.expander("Agent draft") + st.button("Sign").</div></section>\n')
c=json.load(open(P+'canvas.json'));done=[];skipped=[]
for f in sorted(os.listdir(P)):
    if not f.endswith('.dc.html'):continue
    n=f[:-8]
    if n in SKIP: skipped.append(n);continue
    a=X.get(n) or A.get(MAP.get(n,''))
    if not a: skipped.append(n+'?');continue
    s=open(P+f).read()
    if 'data-agd="1"' in s: continue
    m=re.search(r'</div>\s*</x-dc>',s);assert m,f
    extra=' The validator\'s agent cannot read the developer\'s draft (AGENT-04).' if n.startswith('Val-') else ''
    s=s[:m.start()]+block(a,extra)+s[m.start():]
    open(P+f,'w').write(s);done.append(f)
    b=c['boards'].get(f)
    if b: b['h']+=300
c['notes']['agent_note']={'fill':'blue','page':'access','size':'m','w':420,'x':4560,'y':700,'text':'AI agents and documents (spec 012). Every role board ends with a block: the document an agent can draft there, the records it reads, who signs, and what it never writes. Three rules: AGENT-02 a draft is not a record until the named person signs; AGENT-03 judgement sections (conclusions, approvals, attestations, risk acceptance) are left blank for that person; AGENT-04 the validator\'s agent cannot read the developer\'s draft. AGENT-01 still holds: an agent reads and drafts, it issues no command.'}
json.dump(c,open(P+'canvas.json','w'),indent=2)
json.dump(done,open('agd_done.json','w'))
print(len(done),'skipped',skipped)
