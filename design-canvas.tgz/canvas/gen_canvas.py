import json,re
P='canvas/project/'
HEAD='''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>%s</title>
<script src="./support.js"></script>
<link rel="stylesheet" href="/_blob/fc9ff7c17f572b55423d55fed258e58c">
</head>
<body>
<x-dc>
<helmet>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&amp;family=JetBrains+Mono:wght@400;500&amp;display=swap" rel="stylesheet">
<style>
body{margin:0;background:#fff}
a{color:#104683}
%s
</style>
</helmet>
'''
R=lambda msg,rule:msg+'|'+rule
# page -> config. field: [label, kind, default, [[value,label,note,refusal]...]]
CFG={
'val-queue':{'t':'validator · case queue','seen':'nobody: these are view choices','f':[['Sort cases by','lens','sla',[['sla','Days over service level'],['tier','Tier first'],['age','Oldest first']]],['Show','lens','mine',[['mine','My cases'],['pod','My pod']]]]},
'val-intake':{'t':'validator · intake','seen':'the head of validation, who sets the final depth','up':[['Developer','Observation window','30 months','36 months'],['Developer','months_since_delinq','out (correlation)','forced in'],['Developer','Recalibration','none','Platt scaling']],'f':[['Depth you propose','lim','min',[['min','Tier minimum'],['deep','Add replication','Your reason goes to the head of validation.'],['less','Targeted only','',R('Depth cannot go below the tier minimum.','Rule VAL-SCOPE-01')]]],['Evidence you ask the developer for','dec','std',[['std','Standard manifest'],['plus','Add build specification and dataset hashes','Returned to the developer as an intake request.']]]]},
'val-case':{'t':'validator · your plan, sample and challenger','seen':'the developer, once findings are issued; the head of validation; the approval authority','up':[['Developer','Observation window','30 months','36 months'],['Developer','months_since_delinq','out (correlation 0.74)','forced in'],['Developer','Recalibration','none','Platt scaling']],'f':[
 ['Tests in your plan','lim','min',[['min','5 tier minimum tests'],['plus','Add November 2025 bureau replay','6 tests. Added tests are recorded in the plan.'],['less','Drop a minimum test','',R('A tier 1 minimum test cannot be removed.','Rule VAL-PLAN-01 · the minimum set comes from policy')]]],
 ['Out-of-time sample','dec','dev',[['dev','Jul–Dec 2024 · developer\'s hold-out','KS 0.428 · calibration slope 0.97'],['new','Jan–Jun 2025 · developer never saw it','KS 0.419 · calibration slope 0.94'],['nov','Nov 2025 · after the bureau change','KS 0.391 · calibration slope 0.81: outside 0.88 to 1.12. Raise a finding.']]],
 ['Challenger','dec','none',[['none','None'],['glm','GLM on optimal bins','Built in the model build studio from your own build specification.'],['own','Same algorithm, your settings','Built in the model build studio from your own build specification.']]],
 ['Replication tolerance','lim','0.005',[['0.005','0.005'],['0.003','0.003','All four measures still within.'],['0.002','0.002','KS out of time differs by 0.003: outside your level.'],['0.010','0.010','',R('You can tighten the tolerance, not loosen it.','Rule VAL-TOL-01 · policy level 0.005')]]]]},
'val-findings':{'t':'validator · finding terms','seen':'the finding owner; the head of validation; the approval authority','f':[['Severity','dec','3',[['2','2 · high','Blocks approval until closed.'],['3','3 · medium'],['4','4 · low']]],['Due in','lim','60',[['30','30 days'],['60','60 days'],['90','90 days'],['180','180 days','',R('A severity 3 finding is due within 90 days.','Rule FND-DUE-01')]]],['Evidence that closes it','dec','rerun',[['rerun','Re-run on a later sample'],['doc','Documented analysis'],['both','Both']]]]},
'val-conclusion':{'t':'validator · recommended terms','seen':'the approval authority, as suggested values it may change','up':[['You','Out-of-time sample','developer\'s hold-out','Nov 2025'],['You','Challenger','none','GLM on optimal bins']],'f':[['Recommendation','dec','cond',[['ok','Approve'],['cond','Approve with conditions'],['rej','Do not approve']]],['Usage limit you recommend','dec','all',[['all','All intended uses'],['cap','Offers up to $10,000'],['exist','Existing customers only']]],['Re-validate when','dec','psi',[['psi','PSI in breach two months running'],['cal','Calibration slope leaves 0.88 to 1.12'],['yr','In 12 months regardless']]]]},
'gov-hov':{'t':'head of validation · assignment and scope','seen':'the validator (scope); developer and owner (service level); the SVP queue (a date at risk)','f':[['Rank nominees by','lens','load',[['load','Lightest workload'],['skill','Best skill match']]],['Depth of validation','lim','full',[['full','Tier minimum'],['deep','Add replication','About 12 more working days. Your reason is recorded.'],['less','Below the minimum','',R('Depth cannot go below the tier minimum.','Rule VAL-SCOPE-01')]]],['Service level for this case','dec','5',[['3','3 days'],['5','5 days'],['10','10 days · with a reason','The SVP queue shows the later date as at risk.']]]]},
'gov-approval':{'t':'approval authority · conditions as terms','seen':'the owner; operations (rollout must respect the usage limit); monitoring (the trigger becomes an alert rule)','up':[['Developer','Observation window','30 months','36 months · accepted by the validator'],['Developer','months_since_delinq','out','forced in · raised as a finding'],['Validator','Out-of-time sample','developer\'s hold-out','Nov 2025 · slope 0.81']],'f':[['Usage limit','dec','all',[['all','All intended uses'],['cap','Offers up to $10,000'],['exist','Existing customers only']]],['Approval expires after','lim','12',[['6','6 months'],['12','12 months'],['24','24 months','',R('A tier 1 approval lasts at most 12 months.','Rule APR-EXP-01 · set in policy')]]],['Approval is withdrawn if','dec','psi',[['psi','PSI in breach two months running'],['ks','KS falls more than 0.05'],['cal','Calibration slope leaves 0.88 to 1.12']]]]},
'gov-homr':{'t':'head of model risk · your list','seen':'nobody for the view choice; decisions are recorded as before','up':[['Owner Acq-owner-03','XCE01 Exposure','$14.0bn','$9.7bn with evidence · proposed tier T1 → T2'],['Owner Acq-owner-03','XCE01 early warning on PSI','policy 0.10','0.08']],'f':[['Order decisions by','lens','age',[['age','Oldest first'],['tier','Tier first'],['kind','By kind']]],['Tier-input correction from an owner','dec','ask',[['ask','Ask for more evidence'],['acc','Accept','The proposed tier is re-computed. A lower tier from a corrected input is not an override.'],['rej','Reject with a reason']]]]},
'tiering':{'t':'head of model risk · tiering view','seen':'nobody: view choices. Bands and weights are changed on the Policy board','f':[['Show tiers','lens','both',[['both','In force and proposed'],['prop','Proposed only'],['moved','Only models that move']]],['Bands and weights','fix','p3',[['p3','Policy version 3 · change on the Policy board']]]]},
'own-inbox':{'t':'owner · inbox view','seen':'nobody: view choices','f':[['Group by','lens','due',[['due','Due date'],['model','Model'],['kind','Kind of decision']]]]},
'own-breach':{'t':'owner · overlay, early warning, tier input','seen':'the head of model risk (tier input, overlay terms); operations and the SVP (early warning)','f':[['Overlay · cut-off rise','dec','20',[['10','+10 points','Approval rate 41% → 39% (illustrative).'],['20','+20 points','Approval rate 41% → 37% (illustrative).'],['30','+30 points','Approval rate 41% → 34% (illustrative).']]],['Overlay · expiry','lim','60',[['30','30 days'],['60','60 days'],['90','90 days'],['180','180 days','',R('A temporary exception lasts at most 90 days.','Rule EXC-MAX-01 · longer is a model change')]]],['Early warning on PSI','lim','none',[['none','Policy only · 0.10'],['0.08','0.08','Alerts you and operations before the policy level.'],['0.06','0.06','3 alerts in 12 months against 1: earlier warning costs false alarms.'],['0.15','0.15','',R('An owner can warn earlier than policy, not later.','Rule MON-OWN-01')]]],['Exposure used for your tier','dec','keep',[['keep','$14.0bn · inventory'],['fix','$9.7bn · your correction','Score 16 → 14, proposed tier T1 → T2. Sent to the head of model risk with evidence; the tier in force does not change until accepted (TIER-01).']]],['Monitoring segment','lens','all',[['all','All accounts'],['new','New accounts'],['old','Existing accounts']]]]},
'own-release':{'t':'owner · release terms','seen':'operations; the approval authority if a condition is touched','up':[['Operations','Rollout of XCE05','shadow 14 days','staged 25% for 14 days'],['Approval authority','Usage limit','all uses','offers up to $10,000']],'f':[['Release window','dec','next',[['next','Next release window'],['me','After month-end close'],['now','Today','',R('A release outside a window needs the change board.','Rule REL-WIN-01')]]],['Who is told at go-live','dec','std',[['std','Owner, operations, validator'],['plus','Add the business line head']]]]},
'ops-alerts':{'t':'operations · alert handling','seen':'owners of the affected models','up':[['Owner Acq-owner-03','XCE01 early warning on PSI','policy 0.10','0.08']],'f':[['Group alerts','lens','model',[['model','By model · 6 rows'],['feed','By feed · 1 incident']]],['Repeat alerts for the same cause','dec','day',[['each','Every evaluation'],['day','Once a day'],['3d','Once in 3 days']]],['Mute','lim','none',[['none','Nothing muted'],['watch','Watch-level repeats','Breaches still alert.'],['breach','Breaches','',R('A breach cannot be muted.','Rule OPS-MUTE-01 · acknowledge it with a cause instead')]]]]},
'ops-deploy':{'t':'operations · rollout plan','seen':'the owner, on the release page; the approval authority if a condition is touched','up':[['Approval authority','Usage limit','all uses','offers up to $10,000 · fixed for you'],['Approval authority','Withdraw if','—','PSI in breach two months running · now an alert rule']],'f':[['How to roll out','lim','shadow',[['shadow','Shadow first'],['staged','Staged share'],['direct','Straight to full use','',R('A tier 1 model cannot go straight to full use.','Rule OPS-ROLL-01')]]],['Share of traffic in stage 1','dec','10',[['5','5%'],['10','10%'],['25','25%']]],['Length of stage 1','dec','14',[['7','7 days'],['14','14 days'],['30','30 days']]],['Roll back when PSI reaches','lim','0.10',[['0.08','0.08'],['0.10','0.10'],['0.15','0.15','',R('The rollback level cannot be looser than the policy watch level.','Rule OPS-ROLL-02')]]],['Digest, environment, parity tolerance','fix','x',[['x','From the signed authorisation · 1e-6']]]]},
'ops-incident':{'t':'operations · incident handling','seen':'the incident owner; owners of the six models; the SVP queue','f':[['Scope of the incident','dec','feed',[['feed','One feed · 6 models'],['vendor','Whole vendor · 9 models','Adds 3 models not yet in breach.']]],['Updates to owners','dec','day',[['day','Daily'],['change','On change only'],['hour','Hourly']]],['Close the incident','fix','x',[['x','When two evaluations are healthy · not a setting']]]]},
'dev-queue':{'t':'developer · queue view','seen':'nobody: view choices','f':[['Sort by','lens','next',[['next','What is next'],['due','Due date'],['tier','Tier']]]]},
'dev-evidence':{'t':'developer · your test battery','seen':'the validator, at intake','f':[['Tests you add','dec','none',[['none','Tier battery only'],['seg','Add stability by segment','Runs with the battery; results join the evidence.'],['rej','Add reject inference check','Runs with the battery; results join the evidence.']]],['Remove a tier test','lim','no',[['no','Tier battery kept'],['yes','Skip calibration test','',R('A test in the tier battery cannot be skipped.','Rule GATE-BAT-01 · record a deviation for model risk instead')]]],['Sample for the battery','dec','test',[['test','Test set'],['both','Test and hold-out','Counts as the one hold-out opening (AML-03).']]]]},
'dev-findings':{'t':'developer · your response','seen':'the validator, who alone closes the finding','up':[['Validator','Out-of-time sample','your hold-out','Nov 2025 · slope 0.81'],['Validator','Challenger','none','GLM · slope 0.95']],'f':[['Respond with','dec','ver',[['ans','An answer'],['ver','A new version','Opens the model build studio with your frozen settings as the start.'],['disp','A dispute','Goes to the head of validation to arbitrate.']]]]},
'main':{'t':'SVP · your view of the queue','seen':'nobody: view choices. The queue is set by rule','f':[['What just missed the queue','lens','hide',[['hide','Hide'],['show','Show','XIE01 (R1 needs a score breach) · 4 models on partner_application_feed (R2 needs five) · ACE21 (already in item 1)']]],['Business area','lens','all',[['all','All'],['acq','Acquisition'],['am','Account management']]],['Remove an item','fix','x',[['x','Not possible · an item leaves when its condition clears (QUEUE-01)']]]]},
'l1':{'t':'SVP · posture view','seen':'nobody: view choices','f':[['Tiers shown','lens','both',[['both','In force and proposed'],['force','In force'],['prop','Proposed']]],['Period','lens','now',[['now','Latest month'],['q','Last quarter']]],['Levels used','fix','p3',[['p3','Policy version 3 · set by model risk']]]]},
'svp-l2':{'t':'SVP · grouping','seen':'nobody: view choices','f':[['Group troubled models by','lens','view',[['view','Shared feature view'],['own','Owner'],['bu','Business area']]]]},
'svp-drift':{'t':'SVP · drift view','seen':'nobody: view choices','f':[['Lead metric','lens','worst',[['worst','Worst metric per model'],['psi','PSI'],['dd','Dynamic delinquency']]],['Period','lens','12',[['6','6 months'],['12','12 months']]],['Levels used','fix','p3',[['p3','Watch 0.10 · breach 0.25 · policy version 3']]]]},
'svp-l3':{'t':'model sheet · comparison','seen':'nobody: view choices','f':[['Compare against','lens','dev',[['dev','Development sample'],['yr','Same month last year'],['prev','Previous version']]],['Segment','lens','all',[['all','All accounts'],['new','New accounts'],['old','Existing accounts']]]]},
'feat-usage':{'t':'features · baseline and period','seen':'nobody: view choices. Recorded monitoring results do not change','f':[['Drift baseline','lens','dev',[['dev','Each model\'s development sample'],['yr','Same month last year','Separates a vendor change from slow population shift.']]],['Period','lens','12',[['6','6 months'],['12','12 months'],['24','24 months']]],['Levels used','fix','p3',[['p3','Watch 0.10 · breach 0.25 · policy version 3']]]]},
'registry':{'t':'registry · view','seen':'nobody: view choices','f':[['Show','lens','dis',[['all','All versions'],['dis','Only disagreements']]],['An alias as approval','fix','x',[['x','Never · the signed authorisation decides']]]]},
'adm-status':{'t':'administrator · objectives and schedules','seen':'operations; the head of model risk for anything that delays monitoring','f':[['Feed freshness objective','dec','60',[['30','30 minutes'],['60','60 minutes'],['240','4 hours','Monitoring would read Unknown later in the day.']]],['Reconciler cycle','dec','15',[['5','5 minutes'],['15','15 minutes'],['60','60 minutes']]],['Deploy configuration','lim','two',[['two','With a second approver'],['one','Alone','',R('A configuration deploy needs a second approver.','Rule SOD-ADMIN-01')]]]]},
'adm-access':{'t':'administrator · access reviews','seen':'internal audit','f':[['Review grants every','lim','q',[['m','Month'],['q','Quarter'],['y','Year','',R('Grants are reviewed at least quarterly.','Rule ACC-REV-01')]]],['Grant yourself a governance role','fix','x',[['x','Not possible · SOD-ADMIN-01']]]]},
'compliance':{'t':'compliance · the fair-lending test','seen':'developers, as a limit in phase 7 of the model build; validators; the approval authority','f':[['Measure','dec','air',[['air','Adverse impact ratio'],['smd','Standardised mean difference'],['both','Both']]],['Flag below a ratio of','dec','0.80',[['0.80','0.80','0 of 7 models below. A screening level you choose, not a legal standard.'],['0.85','0.85','2 of 7 models below: MID01, XCD01.'],['0.90','0.90','4 of 7 models below: MID01, XCD01, XCE02, XCE03.']]],['When a model falls below','dec','block',[['block','Block freeze'],['esc','Escalate to compliance']]],['How groups are estimated','dec','pending',[['pending','Not yet approved','No real result can be computed until a method is approved.'],['est','Estimated from name and geography'],['self','Self-reported only']]],['Stand-in features','dec','base',[['base','business_zip'],['plus','Add business_zip3','2 feature views carry it. Builds selecting it are refused (AML-01) from the effective date.']]],['Who can edit this page','fix','x',[['x','Compliance only · second approver in compliance']]]]},
'audit':{'t':'internal audit · your sample','seen':'everyone, once you export: the export is itself an event','f':[['Period','lens','q4',[['q3','Jul–Sep 2026','1,510 events'],['q4','Oct–Nov 2026','1,842 events'],['y','Last 12 months','6,907 events']]],['Events','lens','all',[['all','All'],['ref','Refusals','61 in Oct–Nov'],['ovr','Overrides and changes','137 in Oct–Nov'],['acc','Access grants','24 in Oct–Nov']]],['Sample size','lens','25',[['25','25'],['50','50'],['100','100']]],['Correct an event','fix','x',[['x','Not possible for any role · append-only (AUD-01)']]]]},
}
STYLE_ADJ='''.adj{font-family:Inter,system-ui,sans-serif;color:#1a1a1a;background:#fff;display:flex;flex-direction:column;gap:12px;border-top:3px solid #000;padding-top:12px}
.adj .af{display:grid;grid-template-columns:240px minmax(0,1fr);gap:8px 20px;align-items:start;border-top:1px solid #eee;padding-top:12px}
@media (max-width:820px){.adj .af{grid-template-columns:1fr}}
.adj .ac{display:flex;flex-direction:column;gap:6px;min-width:0}
.adj .kind{display:block;font-size:10.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;margin-top:5px;color:#666}
.adj .kind.dec{color:#104683}.adj .kind.lim{color:#9A6410}
.seg{display:inline-flex;flex-wrap:wrap;border:2px solid #000;align-self:flex-start}
.seg button{font:inherit;font-size:12px;font-weight:700;letter-spacing:.04em;min-height:40px;padding:0 14px;border:0;border-right:1px solid #ccc;background:#fff;cursor:pointer}
.seg button:last-child{border-right:0}
.seg button[aria-pressed="true"]{background:#000;color:#fff}
.seg small{font-weight:400;letter-spacing:0;opacity:.7}
.adj .ref{padding:10px 14px;display:flex;flex-direction:column;gap:4px}
.adj .hid{display:none}
.adj table.t{border-collapse:collapse;width:100%;font-size:13px}
.adj table.t th,.adj table.t td{text-align:left;padding:6px 8px;vertical-align:top;border-bottom:1px solid #eee}
.adj .up{border-left:3px solid #4A6FC0;background:#EEF2F9;padding:10px 14px;display:flex;flex-direction:column;gap:6px}'''
adj=HEAD%('Adjust block',STYLE_ADJ)+'''<section class="adj" aria-label="Adjust: {{title}}">
<div style="display:flex;flex-wrap:wrap;gap:6px 16px;align-items:baseline"><span class="lab">Adjust · {{title}}</span><span class="mut" style="font-size:12px">The system suggests. You change what is yours. Each change is counted and shown to the next role.</span></div>
<sc-if value="{{hasUp}}" hint-placeholder-val="{{true}}">
<div class="up rise"><span class="lab">Changed before it reached you</span>
<div style="overflow-x:auto"><table class="t"><thead><tr><th>By</th><th>Setting</th><th>Suggested</th><th>Chosen</th></tr></thead><tbody><sc-for list="{{up}}" as="u" hint-placeholder-count="3"><tr><td>{{u.who}}</td><td>{{u.what}}</td><td class="mut">{{u.was}}</td><td><b>{{u.now}}</b></td></tr></sc-for></tbody></table></div></div>
</sc-if>
<div class="{{verd.cls}}" role="status"><span class="lab">Your settings</span><span class="vt">{{verd.text}}</span><button class="vbtn" type="button" onClick="{{reset}}">Reset to suggested</button></div>
<sc-for list="{{fields}}" as="f" hint-placeholder-count="4">
<div class="af rise d1"><div><span class="lab">{{f.name}}</span><span class="{{f.kc}}">{{f.kind}}</span></div>
<div class="ac"><div class="seg" role="group" aria-label="{{f.name}}"><sc-for list="{{f.opts}}" as="o" hint-placeholder-count="3"><button type="button" aria-pressed="{{o.p}}" onClick="{{o.go}}">{{o.name}} <small>{{o.def}}</small></button></sc-for></div>
<span class="mut">{{f.note}}</span>
<div class="{{f.refCls}}" role="alert"><b>{{f.refT}}</b><p class="mut" style="margin:0">{{f.refR}}</p></div></div></div>
</sc-for>
<p class="mut" style="margin:0"><b>Seen by:</b> {{seen}}</p>
<div class="ann">st.expander("Adjust") · one st.segmented_control per setting, default marked "suggested" · view choices live in st.session_state and are not logged · decisions POST a Set… command and are stored as overrides (setting, suggested, chosen, who, when) · limits come from policy: the API refuses a looser value and names the rule · the next role's page lists the overrides</div>
</section>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"page":{"editor":"text","default":"val-case"},"$preview":{"width":1300,"height":720}}'>
class Component extends DCLogic {
constructor(p){ super(p); this.state={v:{},r:{}}; }
renderVals(){ var s=this, st=this.state;
var CFG='''+json.dumps(CFG,ensure_ascii=False)+''';
var KIND={lens:'View only · not logged',dec:'Your decision · logged',lim:'Limit · stricter only',fix:'Fixed · not yours to change'};
var c=CFG[this.props.page]||CFG['val-case'],n=0;
var fields=c.f.map(function(f,i){var cur=st.v[i]===undefined?f[2]:st.v[i];if(cur!==f[2]&&f[1]!=='lens')n++;var note='',rf=st.r[i]||'';
 var opts=f[3].map(function(o){if(o[0]===cur)note=o[2]||'';return {name:o[1],p:o[0]===cur?'true':'false',def:o[0]===f[2]&&f[3].length>1?'· suggested':'',go:function(){var v={},r={};Object.keys(st.v).forEach(function(k){v[k]=st.v[k];});Object.keys(st.r).forEach(function(k){r[k]=st.r[k];});if(o[3]){r[i]=o[3];}else{delete r[i];v[i]=o[0];}s.setState({v:v,r:r});}};});
 var q=rf.split('|');return {name:f[0],kind:KIND[f[1]],kc:'kind '+f[1],opts:opts,note:note,refCls:rf?'ref':'hid',refT:rf?'Not done. '+q[0]:'',refR:rf?(q[1]||'')+' · nothing changed':''};});
return {title:c.t,seen:c.seen,hasUp:!!(c.up&&c.up.length),up:(c.up||[]).map(function(u){return {who:u[0],what:u[1],was:u[2],now:u[3]};}),fields:fields,
 verd:{cls:'verdict'+(n?' Watch':''),text:n?n+' change'+(n===1?'':'s')+' from the suggested values, each logged with your name.':'All suggested values. Change any setting marked "your decision".'},
 reset:function(){s.setState({v:{},r:{}});}};
}
}
</script>
</body>
</html>
'''
open(P+'Adjust.dc.html','w').write(adj)

# insert the block into role boards
MAP={'Val-Queue':'val-queue','Val-Intake':'val-intake','Val-Case':'val-case','Val-Findings':'val-findings','Val-Conclusion':'val-conclusion','Gov-HoV':'gov-hov','Gov-Approval':'gov-approval','Gov-HoMR':'gov-homr','Tiering':'tiering','Own-Inbox':'own-inbox','Own-Breach':'own-breach','Own-Release':'own-release','Ops-Alerts':'ops-alerts','Ops-Deploy':'ops-deploy','Ops-Incident':'ops-incident','Dev-Queue':'dev-queue','Dev-Evidence':'dev-evidence','Dev-Findings':'dev-findings','Main':'main','L1':'l1','SVP-L2':'svp-l2','SVP-Drift':'svp-drift','SVP-L3':'svp-l3','Feat-Usage':'feat-usage','Registry':'registry','Adm-Status':'adm-status','Adm-Access':'adm-access'}
c=json.load(open(P+'canvas.json'))
for b,k in MAP.items():
    f=P+b+'.dc.html';s=open(f).read()
    if 'name="Adjust"' in s: continue
    hgt=150+90*len(CFG[k]['f'])+(60+34*len(CFG[k].get('up',[])) if CFG[k].get('up') else 0)+140
    blk='<section style="padding:28px 40px 0" aria-label="Adjust"><dc-import name="Adjust" page="%s" hint-size="100%%,%dpx"></dc-import></section>\n'%(k,hgt)
    m=list(re.finditer(r'</div>\s*</x-dc>',s));assert m,b
    i=m[-1].start();s=s[:i]+blk+s[i:]
    open(f,'w').write(s)
    c['boards'][b+'.dc.html']['h']+=hgt+60

# developer leftovers
f=P+'Dev-Version.dc.html';s=open(f).read()
m=re.search(r'<section class="drawer" aria-labelledby="ls">.*?</section>',s,re.S);assert m
s=s[:m.start()]+'''<section class="drawer" aria-labelledby="ls">
<h2 id="ls">Build the model</h2>
<p>Search, settings and comparison now happen in the model build studio. AutoML suggests each setting; you can change it in every phase.</p>
<a class="btn bp" href="Dev-AutoML.dc.html" style="align-self:flex-start;display:inline-flex;align-items:center;text-decoration:none">Open the model build studio</a>
<div class="ref" role="alert"><b>Not done. Principal components are not allowed for a T2 model.</b><p>A setting the tier forbids is refused in the studio and named by rule.</p><p class="mut">Rule AML-02 · nothing changed</p></div>
<div class="ann">st.page_link("pages/2b_Model_Build.py") · the old search dialog is removed: one place to build</div>
</section>'''+s[m.end():]
s=s.replace('<b>Look for</b>Search only inside the approved space. Freeze when the comparison is done.','<b>Look for</b>The model is built in the studio, phase by phase. This page keeps the version\'s tier, record and freeze.')
s=s.replace('>Launch search</button>','>Open model build studio</button>').replace('Freezing verifies the artifact digest','Freeze is refused if the calibration slope is outside limits (AML-05). Freezing verifies the artifact digest')
open(f,'w').write(s)

# three new boards
STY='''.hd{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px;padding:14px 40px;font-size:14px}
.nav{display:flex;flex-wrap:wrap;gap:4px}.nav a{padding:10px 12px}
.sec{padding:28px 40px 0;display:flex;flex-direction:column;gap:12px}
.strip{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));border-top:3px solid #000}
.strip>div{padding:16px 20px 14px 0;display:flex;flex-direction:column;gap:6px}
table.t{border-collapse:collapse;width:100%;font-size:13px}
table.t th,table.t td{text-align:left;padding:6px 8px;vertical-align:top;border-bottom:1px solid #eee}
.seg{display:inline-flex;flex-wrap:wrap;border:2px solid #000;align-self:flex-start}
.seg button{font:inherit;font-size:12px;font-weight:700;letter-spacing:.04em;min-height:40px;padding:0 14px;border:0;border-right:1px solid #ccc;background:#fff;cursor:pointer}
.seg button:last-child{border-right:0}
.seg button[aria-pressed="true"]{background:#000;color:#fff}
.seg small{font-weight:400;letter-spacing:0;opacity:.7}
.af{display:grid;grid-template-columns:240px minmax(0,1fr);gap:8px 20px;align-items:start;border-top:1px solid #eee;padding-top:12px}
.kind{display:block;font-size:10.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;margin-top:5px;color:#104683}
.mono{font-family:'JetBrains Mono',monospace;font-weight:500}
.grid{display:grid;grid-template-columns:90px repeat(5,minmax(0,1fr));gap:2px;max-width:760px}
.grid>div{min-height:54px;display:flex;flex-direction:column;justify-content:center;padding:4px 8px;background:#f4f5f2;font-size:12px}
.grid>div.h{background:#fff;font-weight:700;font-size:11px;letter-spacing:.06em;text-transform:uppercase}
.grid>div.n{font-size:26px;font-weight:200}
.grid>div.same{background:#000;color:#fff}.grid>div.up{background:#FDEEE8}.grid>div.dn{background:#E4F1E0}.grid>div.z{color:#bbb}
.sq{display:flex;flex-wrap:wrap;gap:3px;max-width:240px}.sq i{width:14px;height:14px;background:#000;display:block}.sq i.up{background:#F2552C}.sq i.dn{background:#fff;box-shadow:inset 0 0 0 2px #D3902A}.sq i.tool{background:#ccc}
.cols{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:20px;border-top:3px solid #000;padding-top:12px}
.cols>div{display:flex;flex-direction:column;gap:8px}
.res{padding:12px 16px;display:flex;flex-direction:column;gap:4px}.res.ok{border-left:3px solid #5A9A41;background:#E4F1E0}.res.no{border-left:3px solid #F2552C;background:#FDEEE8}.hid{display:none}
.btn{font:inherit;padding:0 16px;cursor:pointer}'''
T=json.load(open('tiering/tier.json'))
TM=[{k:m[k] for k in ['id','type','t0','t','d','c','i','s','exp','use','rel','aa','cls']} for m in T['models']]
hdr=lambda area,cur:'''<div style="font-family:Inter,system-ui,sans-serif;color:#1a1a1a;max-width:1440px;margin:0 auto;padding-bottom:72px">
<header class="hd">
<div style="display:flex;flex-wrap:wrap;gap:20px;align-items:center"><b>'''+area+'''</b>
<nav class="nav" aria-label="Pages">'''+cur+'''</nav></div>
<div class="mut">[Name] · <a href="Login.dc.html">Sign out</a></div>
</header>
'''
policy=HEAD%('G4 Policy: bands, thresholds, limits',STY)+hdr('Governance · Head of model risk','<a href="Gov-HoMR.dc.html">Decisions</a><a class="cur" href="Policy.dc.html" aria-current="page">Policy</a><a href="Tiering.dc.html">Tiering and tools</a>')+'''<section class="sec" aria-labelledby="h">
<div class="lab rise">Policy version 3 in force · every value below is read by a rule</div>
<div class="look"><b>Look for</b>Change a band. The counts and the squares show what moves before you propose anything.</div>
<h1 id="h" class="rise d1">Set the policy, and see what moves before you propose it</h1>
<div class="{{verd.cls}}" role="status"><span class="lab">Your settings</span><span class="vt">{{verd.text}}</span><button class="vbtn" type="button" onClick="{{reset}}">Reset to version 3</button></div>
<p class="mut"><b>Seen by:</b> every owner whose model moves, before the effective date; developers and validators, as limits; the SVP, as a banner on portfolio posture.</p>
</section>
<section class="sec" aria-labelledby="b">
<h2 id="b">Tier bands</h2>
<sc-for list="{{bands}}" as="f" hint-placeholder-count="3"><div class="af rise"><div><span class="lab">{{f.name}}</span><span class="kind">Your decision · logged</span></div><div style="display:flex;flex-direction:column;gap:6px"><div class="seg" role="group"><sc-for list="{{f.opts}}" as="o" hint-placeholder-count="3"><button type="button" aria-pressed="{{o.p}}" onClick="{{o.go}}">{{o.name}} <small>{{o.def}}</small></button></sc-for></div><span class="mut">{{f.note}}</span></div></div></sc-for>
<div class="strip" role="list"><div role="listitem"><span class="count">{{n.moved}}</span><span class="lab">Models change tier</span><span class="mut">against today's proposal</span></div><div role="listitem"><span class="count">{{n.up}}</span><span class="lab">Move up</span><span class="mut">more validation work</span></div><div role="listitem"><span class="count">{{n.dn}}</span><span class="lab">Move down</span></div><div role="listitem"><span class="count">{{n.t1}}</span><span class="lab">Tier 1 models</span><span class="mut">12 today</span></div></div>
<div class="cols" role="list" aria-label="Models by tier with your change"><sc-for list="{{cols}}" as="c" hint-placeholder-count="5"><div role="listitem"><span class="lab">{{c.name}} · {{c.n}}</span><div class="sq"><sc-for list="{{c.sq}}" as="q" hint-placeholder-count="9"><i class="{{q.cls}}" title="{{q.id}}"></i></sc-for></div></div></sc-for></div>
<p class="mut">Each square is one model. Black: same tier as today's proposal. Red: moves up. Open: moves down. Grey: tool. In the Streamlit app the squares regroup as you scroll (smokey_chart("units")).</p>
<h3 style="margin:8px 0 0;font-size:15px">Models that move</h3>
<div style="overflow-x:auto"><table class="t"><thead><tr><th>Key</th><th>Model</th><th>Score</th><th>Today's proposal</th><th>With your change</th></tr></thead><tbody><sc-for list="{{moved}}" as="r" hint-placeholder-count="6"><tr><td class="mono">{{r.id}}</td><td>{{r.type}}</td><td>{{r.s}}</td><td>{{r.a}}</td><td><span class="{{r.chip}}">{{r.b}}</span></td></tr></sc-for></tbody></table></div>
<p class="mut">{{none}}</p>
</section>
<section class="sec" aria-labelledby="m">
<h2 id="m">Monitoring and build limits</h2>
<sc-for list="{{limits}}" as="f" hint-placeholder-count="3"><div class="af rise"><div><span class="lab">{{f.name}}</span><span class="kind">Your decision · logged</span></div><div style="display:flex;flex-direction:column;gap:6px"><div class="seg" role="group"><sc-for list="{{f.opts}}" as="o" hint-placeholder-count="3"><button type="button" aria-pressed="{{o.p}}" onClick="{{o.go}}">{{o.name}} <small>{{o.def}}</small></button></sc-for></div><span class="mut">{{f.note}}</span></div></div></sc-for>
<div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn bp" type="button" onClick="{{propose}}">Propose policy change</button><button class="btn" type="button" onClick="{{now}}">Try: apply it now</button></div>
<div class="{{res.cls}}" role="status"><b>{{res.t}}</b><p class="mut" style="margin:0">{{res.d}}</p></div>
<div class="ann">policy/tiering.yaml, policy/monitoring.yaml, policy/automl.yaml · GET /policy/preview?… recomputes tiers and alert counts without writing · POST ProposePolicyChange → second approver → ApprovePolicyChange with an effective date (POL-01) · every rule reads the version in force on the event's date · tier floors and "override raises only" (TIER-02) are not settings · Streamlit: st.segmented_control per value, st.metric for counts, smokey_chart("units") for the squares</div>
</section>
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1440,"height":2300}}'>
class Component extends DCLogic {
constructor(p){ super(p); this.state={v:{},res:''}; }
renderVals(){ var s=this, st=this.state;
var M='''+json.dumps(TM)+''';
var DEF={t1:'16',t2:'12',t3:'10',psi:'0.10',bads:'1200',cal:'0.12'},g=function(k){return st.v[k]===undefined?DEF[k]:st.v[k];};
var calc=function(m){var band=m.exp>=10?3:(m.exp>=2?2:1),d=band+({'accounting, regulatory or adverse action':1,'credit decisioning':.5,'general business':0})[m.use]+({High:0,Medium:-.5,Low:-1})[m.rel];d=Math.max(1,Math.min(3,d));var sc=4*d+m.c+m.i,t=sc>=+g('t1')?1:(sc>=+g('t2')?2:(sc>=+g('t3')?3:4));var fl=/Stress|Economic capital/.test(m.type)?1:(/^CECL/.test(m.type)?2:(m.aa==='Y'?3:4));return Math.min(t,fl);};
var set=function(k,v){return function(){var n={};Object.keys(st.v).forEach(function(q){n[q]=st.v[q];});n[k]=v;s.setState({v:n,res:''});};};
var fld=function(name,k,opts,notes){return {name:name,note:(notes&&notes[g(k)])||'',opts:opts.map(function(o){return {name:o[1],p:g(k)===o[0]?'true':'false',def:DEF[k]===o[0]?'· version 3':'',go:set(k,o[0])};})};};
var up=0,dn=0,t1=0,moved=[],cols=[['T1',1],['T2',2],['T3',3],['T4',4],['Tool',0]].map(function(c){return {name:c[0],k:c[1],sq:[]};});
M.slice().sort(function(a,b){return a.id<b.id?-1:1;}).forEach(function(m){var tool=m.cls==='Tool',n=tool?0:calc(m),cl=tool?'tool':(n<m.t?'up':(n>m.t?'dn':''));if(!tool){if(n<m.t)up++;if(n>m.t)dn++;if(n===1)t1++;if(n!==m.t)moved.push({id:m.id,type:m.type,s:m.s,a:'T'+m.t,b:'T'+n+(n<m.t?' · up':' · down'),chip:'chip '+(n<m.t?'Breach':'Watch')});}
 cols.filter(function(c){return c.k===n;})[0].sq.push({cls:cl,id:m.id});});
cols.forEach(function(c){c.n=c.sq.length;});
var ch=Object.keys(st.v).filter(function(k){return st.v[k]!==DEF[k];}).length;
var res={cls:'hid',t:'',d:''};
if(st.res==='now')res={cls:'res no',t:'Not done. A policy change needs a second approver and an effective date.',d:'Rule POL-01 · policy version 3 stays in force · nothing changed'};
if(st.res==='prop')res=ch?{cls:'res ok',t:'Proposed: policy version 4 with '+ch+' change'+(ch===1?'':'s')+'.',d:'Event PolicyChangeProposed · needs a second approver · effective 1 January 2027 if approved · '+(up+dn)+' model owners are told before then'}:{cls:'res no',t:'Nothing to propose.',d:'Every value equals policy version 3.'};
return {verd:{cls:'verdict'+(ch?' Watch':''),text:ch?ch+' change'+(ch===1?'':'s')+' from policy version 3. Nothing takes effect until a second approver agrees.':'Policy version 3, unchanged.'},reset:function(){s.setState({v:{},res:''});},
 bands:[fld('Tier 1 starts at a score of','t1',[['15','15'],['16','16'],['17','17']]),fld('Tier 2 starts at','t2',[['11','11'],['12','12'],['13','13']]),fld('Tier 3 starts at','t3',[['9','9'],['10','10'],['11','11']],{'9':'Score = 4 × impact + uncertainty + implementation risk, from 6 to 18.','10':'Score = 4 × impact + uncertainty + implementation risk, from 6 to 18.','11':'Score = 4 × impact + uncertainty + implementation risk, from 6 to 18.'})],
 n:{moved:up+dn,up:up,dn:dn,t1:t1},cols:cols,moved:moved,none:moved.length?'':'No model moves with these bands.',
 limits:[fld('PSI watch level','psi',[['0.08','0.08'],['0.10','0.10'],['0.15','0.15']],{'0.08':'8 live models at watch or worse (today: 7).','0.10':'7 live models at watch or worse.','0.15':'5 live models at watch or worse (today: 7).'}),
  fld('Minimum bads per dataset','bads',[['1200','1,200'],['2000','2,000'],['3000','3,000']],{'1200':'QCE05 at its default split passes.','2000':'QCE05 at its default split passes: 2,554 bads in each of validation, test and hold-out.','3000':'QCE05 would be blocked: validation, test and hold-out fall short (AML-04).'}),
  fld('Calibration slope allowed at freeze','cal',[['0.10','0.90 to 1.10'],['0.12','0.88 to 1.12'],['0.15','0.85 to 1.15']],{'0.10':'QCE05\\'s best-ranking candidate (slope 0.86) is blocked until recalibrated (AML-05).','0.12':'QCE05\\'s best-ranking candidate (slope 0.86) is blocked until recalibrated (AML-05).','0.15':'QCE05\\'s best-ranking candidate (slope 0.86) could freeze without recalibration.'})],
 propose:function(){s.setState({res:'prop'});},now:function(){s.setState({res:'now'});},res:res};
}
}
</script>
</body>
</html>
'''
open(P+'Policy.dc.html','w').write(policy)
comp=HEAD%('G5 Compliance: fair-lending test',STY)+hdr('Compliance · Fair lending','<a class="cur" href="Compliance.dc.html" aria-current="page">Fair-lending test</a><a href="Dev-AutoML.dc.html">Where builders meet it</a><a href="Gov-Approval.dc.html">Where approvers see it</a>')+'''<section class="sec" aria-labelledby="h">
<div class="lab rise">Compliance · the role that owns this decision now has a page</div>
<div class="look"><b>Look for</b>You choose the measure, the level and what a failure does. Builders see it as a limit they cannot edit.</div>
<h1 id="h" class="rise d1">You set the fair-lending test. Builders see it as a limit.</h1>
<p class="mut">Applies to the 7 models and candidates that can cause an adverse action. All results are synthetic.</p>
<div class="strip" role="list"><div role="listitem"><span class="count">7</span><span class="lab">Models in scope</span><span class="mut">Adverse Actionable = Y</span></div><div role="listitem"><span class="count">0.82</span><span class="lab">Lowest ratio</span><span class="mut">MID01</span></div><div role="listitem"><span class="count">3</span><span class="lab">Features locked</span><span class="mut">2 protected · 1 stand-in</span></div><div role="listitem"><span class="count">0</span><span class="lab">Approved group methods</span><span class="mut">results stay illustrative until one is</span></div></div>
</section>
<section class="sec"><dc-import name="Adjust" page="compliance" hint-size="100%,900px"></dc-import></section>
<section class="sec" aria-labelledby="r">
<h2 id="r">Lowest adverse impact ratio, by model</h2>
<div style="overflow-x:auto"><table class="t"><thead><tr><th>Key</th><th>Lowest ratio</th><th>At 0.80</th><th>At 0.85</th><th>At 0.90</th></tr></thead><tbody>
<tr><td class="mono">XCE05</td><td>0.93</td><td><span class="chip ok">Above</span></td><td><span class="chip ok">Above</span></td><td><span class="chip ok">Above</span></td></tr>
<tr><td class="mono">XCE01</td><td>0.91</td><td><span class="chip ok">Above</span></td><td><span class="chip ok">Above</span></td><td><span class="chip ok">Above</span></td></tr>
<tr><td class="mono">QCE05</td><td>0.91</td><td><span class="chip ok">Above</span></td><td><span class="chip ok">Above</span></td><td><span class="chip ok">Above</span></td></tr>
<tr><td class="mono">XCE03</td><td>0.88</td><td><span class="chip ok">Above</span></td><td><span class="chip ok">Above</span></td><td><span class="chip Breach">Below</span></td></tr>
<tr><td class="mono">XCE02</td><td>0.87</td><td><span class="chip ok">Above</span></td><td><span class="chip ok">Above</span></td><td><span class="chip Breach">Below</span></td></tr>
<tr><td class="mono">XCD01</td><td>0.84</td><td><span class="chip ok">Above</span></td><td><span class="chip Breach">Below</span></td><td><span class="chip Breach">Below</span></td></tr>
<tr><td class="mono">MID01</td><td>0.82</td><td><span class="chip ok">Above</span></td><td><span class="chip Breach">Below</span></td><td><span class="chip Breach">Below</span></td></tr>
</tbody></table></div>
<div class="ann">policy/fair_lending.yaml and policy/protected_features.yaml · POST ProposeFairLendingPolicy → second approver in compliance → effective date · the build studio reads the level in force (phase 7) and FreezeCandidate applies "block" or "escalate" · developers, owners and model risk have read access only · the level is a screening choice, not a legal standard · Streamlit: st.bar_chart or smokey_chart("bars") with the level as a rule line</div>
</section>
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1440,"height":2200}}'>
class Component extends DCLogic { renderVals(){ return {}; } }
</script>
</body>
</html>
'''
open(P+'Compliance.dc.html','w').write(comp)
aud=HEAD%('A1 Internal audit: draw a sample',STY)+hdr('Internal audit · read only','<a class="cur" href="Audit.dc.html" aria-current="page">Sample the record</a><a href="Adm-Access.dc.html">Access log</a><a href="Policy.dc.html">Policy versions</a>')+'''<section class="sec" aria-labelledby="h">
<div class="lab rise">Internal audit · read only</div>
<div class="look"><b>Look for</b>You choose the period, the kind of event and the sample. Nobody hands you one.</div>
<h1 id="h" class="rise d1">Draw your own sample from the record</h1>
<p class="mut">Every command, refusal and override is one event in an append-only chain.</p>
<div class="strip" role="list"><div role="listitem"><span class="count">1842</span><span class="lab">Events · Oct–Nov 2026</span></div><div role="listitem"><span class="count">61</span><span class="lab">Refusals</span></div><div role="listitem"><span class="count">137</span><span class="lab">Overrides and changes</span></div><div role="listitem"><span class="count">0</span><span class="lab">Gaps in the chain</span><span class="mut">hash chain checked</span></div></div>
</section>
<section class="sec"><dc-import name="Adjust" page="audit" hint-size="100%,640px"></dc-import></section>
<section class="sec" aria-labelledby="s">
<h2 id="s">Your sample · first 6 of 25</h2>
<div style="overflow-x:auto"><table class="t"><thead><tr><th>Sequence</th><th>Event</th><th>Role</th><th>Model</th><th>Detail</th></tr></thead><tbody>
<tr><td class="mono">48211</td><td>BuildSpecChanged</td><td>developer</td><td>QCE05</td><td class="mut">observation window 30 → 36 months</td></tr>
<tr><td class="mono">48377</td><td>CommandRefused</td><td>validator</td><td>XCE05</td><td class="mut">VAL-01 · tried to approve</td></tr>
<tr><td class="mono">48590</td><td>TierInputCorrected</td><td>owner</td><td>XCE01</td><td class="mut">exposure, with evidence</td></tr>
<tr><td class="mono">48902</td><td>HoldOutOpened</td><td>developer</td><td>QCE05</td><td class="mut">first and only opening</td></tr>
<tr><td class="mono">49104</td><td>AccessGranted</td><td>administrator</td><td>—</td><td class="mut">validator role · second approver recorded</td></tr>
<tr><td class="mono">49415</td><td>ValidationPlanChanged</td><td>validator</td><td>XCE05</td><td class="mut">added November 2025 replay</td></tr>
</tbody></table></div>
<div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn bp" type="button">Draw again</button><button class="btn" type="button">Export sample</button><button class="btn" type="button">Try: correct an event</button></div>
<div class="res no" role="alert"><b>Not done. The record is append-only, for every role.</b><p class="mut" style="margin:0">Rule AUD-01 · a mistake is corrected by a new event that refers to the old one · nothing changed</p></div>
<div class="ann">GET /audit/events?from&to&type · sampling is done server-side with a seed the auditor can record · POST CreateAuditExport writes AuditExportCreated with the period, filter, seed and sample size · each exported event carries its hash and the previous hash · the audit role has no command other than the export · Streamlit: st.dataframe + st.download_button</div>
</section>
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1440,"height":2000}}'>
class Component extends DCLogic { renderVals(){ return {}; } }
</script>
</body>
</html>
'''
open(P+'Audit.dc.html','w').write(aud)
B=c['boards']
B['Adjust.dc.html']={'x':4100,'y':0,'w':1300,'h':760,'title':'Shared component: Adjust block (suggested, adjusted, counted, seen) on every role board','page':'tier','is_interactive':True}
B['Policy.dc.html']={'x':4560,'y':0,'w':1440,'h':2300,'title':'G4 Policy: tier bands, thresholds and build limits with a preview of what moves','page':'gov','expand':'fill','is_interactive':True}
B['Compliance.dc.html']={'x':6080,'y':0,'w':1440,'h':2200,'title':'G5 Compliance: the fair-lending test, level and locked features','page':'gov','expand':'fill','is_interactive':True}
B['Audit.dc.html']={'x':3040,'y':0,'w':1440,'h':2000,'title':'A1 Internal audit: draw your own sample from the record','page':'adm','expand':'fill','is_interactive':True}
for n in ['Policy.dc.html','Compliance.dc.html','Audit.dc.html','Adjust.dc.html']:
    if n not in c['order']:c['order'].append(n)
json.dump(c,open(P+'canvas.json','w'),indent=2)
# nav links and action index
s=open(P+'Gov-HoMR.dc.html').read().replace('<a href="#">Policy versions</a>','<a href="Policy.dc.html">Policy</a>');open(P+'Gov-HoMR.dc.html','w').write(s)
s=open(P+'ActionIndex.dc.html').read()
a="g('Model developer · Workbench'),";assert a in s
if 'SetValidationPlan' not in s:
    s=s.replace(a,"""g('Controls by role · suggested, adjusted, counted, seen'),
r('Set validation plan, own sample and challenger','V3 Case file','Val-Case.dc.html','SetValidationPlan, BuildChallenger','Tier-minimum tests cannot be removed (VAL-PLAN-01); tolerance stricter only (VAL-TOL-01)'),
r('Accept or raise a developer override','V3 Case file','Val-Case.dc.html','ReviewOverride','Each build override is accepted or becomes a finding'),
r('Set approval terms','G2 Approval','Gov-Approval.dc.html','DecideApproval {terms}','Usage limit, expiry (APR-EXP-01), withdrawal trigger'),
r('Correct a tier input with evidence','O2 Breach','Own-Breach.dc.html','CorrectTierInput','Head of model risk accepts; tier in force unchanged until then (TIER-01)'),
r('Set an early-warning level','O2 Breach','Own-Breach.dc.html','SetEarlyWarning','Stricter than policy only (MON-OWN-01)'),
r('Set a rollout plan','P2 Deployment','Ops-Deploy.dc.html','SetRolloutPlan','Tier 1 not straight to full use (OPS-ROLL-01); digest, environment and usage limit fixed'),
r('Set assignment scope and service level','G1 Head of validation','Gov-HoV.dc.html','AssignValidator {scope}','Not below the tier minimum (VAL-SCOPE-01)'),
r('Propose a policy change with a preview','G4 Policy','Policy.dc.html','ProposePolicyChange','Second approver and effective date (POL-01)'),
r('Set the fair-lending test','G5 Compliance','Compliance.dc.html','ProposeFairLendingPolicy','Compliance only; second approver in compliance'),
r('Draw and export an audit sample','A1 Audit','Audit.dc.html','CreateAuditExport','Read only; the record is append-only (AUD-01)'),
"""+a)
open(P+'ActionIndex.dc.html','w').write(s)
print('ok',len(MAP))
