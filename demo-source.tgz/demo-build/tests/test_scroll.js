const { chromium } = require('playwright');
const U='file://'+process.cwd()+'/demo/smokey-demo.html';
(async()=>{const b=await chromium.launch();
for(const rm of [false,true]){
 const ctx=await b.newContext({viewport:{width:1300,height:900},reducedMotion:rm?'reduce':'no-preference'});
 const p=await ctx.newPage();const e=[];p.on('pageerror',x=>e.push(x.message));
 // L2: dots regroup with scroll
 await p.goto(U+'#l2');await p.waitForTimeout(1500);
 const pos=async()=>p.$$eval('#l2unit .d',els=>els.map(x=>x.getAttribute('data-dot')+':'+Math.round(parseFloat(x.style.left))+','+Math.round(parseFloat(x.style.top))+','+x.style.opacity).join(' '));
 const step=async()=>p.$eval('#l2unit',x=>x.getAttribute('aria-label'));
 const tops=await p.$$eval('.l2step',els=>els.map(x=>x.getBoundingClientRect().top+scrollY));
 console.log('RM',rm,'step tops',tops.map(Math.round).join(','));
 console.log(' s0',await step(),'|',await pos());
 for(let i=1;i<4;i++){await p.evaluate(y=>scrollTo(0,y),tops[i]-440);await p.waitForTimeout(1500);console.log(' s'+i,await step(),'|',await pos());}
 // mid-transition (only meaningful without RM)
 await p.evaluate(y=>scrollTo(0,y),(tops[0]+tops[1])/2-450+ (tops[1]-tops[0])*0.3);await p.waitForTimeout(1500);console.log(' mid',await pos());
 const sticky=await p.$eval('.l2fig',x=>Math.round(x.getBoundingClientRect().top));console.log(' fig top while scrolled',sticky);
 if(!rm){await p.screenshot({path:'shots/scroll-l2.png'});}
 // drift: line draws with scroll, counts
 await p.goto(U+'#drift');await p.waitForTimeout(1500);
 const st=async()=>p.evaluate(()=>{const q=document.querySelector('details.m[open] path.ln');const c=document.querySelector('.count');const f=document.querySelector('details.m');return {dash:q?q.style.strokeDasharray:'',off:q?q.style.strokeDashoffset:'',count:c.textContent,fade:f.style.opacity};});
 console.log(' drift top',JSON.stringify(await st()));
 const y=await p.evaluate(()=>{const q=document.querySelector('details.m[open] svg');return q.getBoundingClientRect().top+scrollY;});
 await p.evaluate(y=>scrollTo(0,y),y-900*0.80);await p.waitForTimeout(1200);console.log(' drift partial',JSON.stringify(await st()));
 await p.evaluate(y=>scrollTo(0,y),y-300);await p.waitForTimeout(1200);console.log(' drift full',JSON.stringify(await st()));
 // bottom of page: everything complete
 await p.evaluate(()=>scrollTo(0,document.documentElement.scrollHeight));await p.waitForTimeout(1500);
 console.log(' bottom: incomplete items',await p.evaluate(()=>[...document.querySelectorAll('#view *')].filter(x=>x.style.opacity!==''&&parseFloat(x.style.opacity)<1&&!x.closest('#l2unit')).length));
 // every route: no errors, nothing stuck hidden after settling at bottom, no hscroll
 for(const r of ['start','l0','l2','l1','drift','model','feature','tier','automl','validator','homr','registry','owner','hov','ops','close']){
  await p.goto(U+'#'+r);await p.waitForTimeout(250);await p.evaluate(()=>scrollTo(0,document.documentElement.scrollHeight));await p.waitForTimeout(1300);
  const bad=await p.evaluate(()=>({hid:[...document.querySelectorAll('#view *')].filter(x=>x.style.opacity!==''&&parseFloat(x.style.opacity)<1&&!x.closest('#l2unit')).length,hs:document.documentElement.scrollWidth>document.documentElement.clientWidth}));
  if(bad.hid||bad.hs)console.log('  PROBLEM',r,JSON.stringify(bad));}
 console.log(' errors',e);await ctx.close();}
// phone
const ctx=await b.newContext({viewport:{width:390,height:844}});const p=await ctx.newPage();await p.goto(U+'#l2');await p.waitForTimeout(1200);
console.log('phone hscroll',await p.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth),'fig pos',await p.$eval('.l2fig',x=>getComputedStyle(x).position+' order '+getComputedStyle(x).order));
await p.evaluate(()=>scrollTo(0,900));await p.waitForTimeout(1200);await p.screenshot({path:'shots/scroll-l2-phone.png'});
await b.close();})();
