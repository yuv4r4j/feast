const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const U='file://'+process.cwd()+'/demo/smokey-demo.html';
for(const vw of [[1300,900],[390,844]]){const p=await b.newPage({viewport:{width:vw[0],height:vw[1]}});const e=[];p.on('pageerror',x=>e.push(x.message));
const hs=async t=>{if(await p.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth))console.log('  HSCROLL',t);};
const txt=s=>p.$eval(s,x=>x.textContent).catch(()=>'(none)');
await p.goto(U+'#automl');await p.waitForTimeout(300);console.log('==',vw[0],'| bar:',await txt('.verdict .big'));
await p.click('button[data-aml="train"]');await p.waitForTimeout(150);await hs('train');
console.log(' table:',await p.evaluate(()=>[...document.querySelectorAll('table')].pop().innerText.split('\n').slice(1).map(r=>r.replace(/\t/g,' | ')).join(' // ').slice(0,420)));
await p.click('button[data-amltry="pfn26"]');console.log(' 2.6:',await txt('.ref b'));
await p.click('button[data-b="f_mitra:on"]');await p.waitForTimeout(100);console.log(' ctx field:',await p.$$eval('button[data-b^="ctx:"]',a=>a.length),'| bar:',await txt('.verdict .big'));
await p.click('button[data-aml="cmp"]');await p.waitForTimeout(150);await hs('cmp');
console.log(' leaderboard:',await p.evaluate(()=>[...document.querySelectorAll('table tbody tr')].map(r=>r.cells[0].innerText.replace(/\n/g,' ')+' '+r.cells[1].innerText+' slope '+r.cells[5].innerText).join(' | ')));
console.log(' note:',await p.evaluate(()=>[...document.querySelectorAll('.note b,.wb b')].map(x=>x.textContent).join(' || ').slice(0,200)));
// select TabICL, shap
await p.evaluate(()=>{[...document.querySelectorAll('button[data-amlsel]')].find(x=>/TabICL/.test(x.textContent)).click();});await p.waitForTimeout(150);
await p.click('button[data-aml="mli"]');await p.waitForTimeout(150);await hs('mli tfm');
console.log(' shap tfm:',await txt('#view h2'),'|',await p.evaluate(()=>[...document.querySelectorAll('.strip b,.strip .count')].slice(0,3).map(x=>x.getAttribute('data-n')||x.textContent).join(' / ')),'|',await txt('.ref b'));
await p.click('button[data-aml="out"]');await p.click('button[data-act="amlfreeze"]');console.log(' freeze tfm:',await txt('.ref b'));
// GBM shap
await p.click('button[data-aml="cmp"]');await p.evaluate(()=>{[...document.querySelectorAll('button[data-amlsel]')].find(x=>/XGBoost/.test(x.textContent)).click();});await p.click('button[data-aml="mli"]');await p.waitForTimeout(150);
const g=await p.evaluate(()=>({meth:document.querySelector('.strip b').textContent,bars:document.querySelectorAll('figure.fig')[0].querySelectorAll('rect').length,wf:document.querySelectorAll('figure.fig')[1].querySelectorAll('rect').length,pred:[...document.querySelectorAll('figure.fig')[1].querySelectorAll('text.v')].pop().textContent,rc:document.querySelector('.note p')?.textContent}));console.log(' shap gbm:',JSON.stringify(g));
for(const i of [1,2]){await p.click(`button[data-shapacc="${i}"]`);await p.waitForTimeout(100);console.log('  acc',i,await p.evaluate(()=>[...document.querySelectorAll('figure.fig')[1].querySelectorAll('text.v')].pop().textContent+' | '+(document.querySelector('.note b')?.textContent||'').slice(0,70)));}
await hs('mli gbm');
if(vw[0]===1300){await p.click('button[data-shapacc="0"]');const y=await p.evaluate(()=>document.querySelector('figure.fig').getBoundingClientRect().top+scrollY-420);for(let q=0;q<=y+400;q+=200){await p.evaluate(v=>scrollTo(0,v),q);await p.waitForTimeout(40);}await p.evaluate(v=>scrollTo(0,v),y);await p.waitForTimeout(1500);await p.screenshot({path:'shots/shap.png'});
 await p.click('button[data-aml="train"]');await p.waitForTimeout(200);const y2=await p.evaluate(()=>[...document.querySelectorAll('h2')].find(h=>/foundation/.test(h.textContent)).getBoundingClientRect().top+scrollY-200);for(let q=0;q<=y2+300;q+=200){await p.evaluate(v=>scrollTo(0,v),q);await p.waitForTimeout(40);}await p.evaluate(v=>scrollTo(0,v),y2);await p.waitForTimeout(1200);await p.screenshot({path:'shots/tfm.png'});}
console.log(' errors',e);await p.close();}
await b.close();})();
