const { chromium } = require('playwright');
const U='file://'+process.cwd()+'/demo/smokey-demo.html#automl';
(async()=>{const b=await chromium.launch();
for(const vw of [[1300,900],[390,844]]){const p=await b.newPage({viewport:{width:vw[0],height:vw[1]}});const e=[];p.on('pageerror',x=>e.push(x.message));
await p.goto(U);await p.waitForTimeout(700);
const hs=async(n)=>{if(await p.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth))console.log('  HSCROLL',n);};
const cl=async s=>{await p.click(s);await p.waitForTimeout(150);};
console.log(vw[0],'verdict:',await p.$eval('.verdict .big',x=>x.textContent));
await cl('button[data-b="win:24"]');console.log(' rows',await p.$eval('.strip .count',x=>x.getAttribute('data-n')||x.textContent),'|',await p.$eval('.verdict .big',x=>x.textContent));await hs('prep');
await cl('button[data-aml="feat"]');await cl('button[data-b="cmax:0.6"]');console.log(' feat',await p.$eval('#view p b',x=>x.textContent));
await p.check('input[data-bf="months_on_book"]');await p.waitForTimeout(150);console.log(' forced',await p.$eval('#view p b',x=>x.textContent),await p.$$eval('.chip.Watch',x=>x.length));await hs('feat');
await cl('button[data-aml="dim"]');await cl('button[data-b="dr:pca"]');console.log(' pca:',await p.$eval('.ref b',x=>x.textContent));await cl('button[data-b="dr:cluster"]');console.log(' cluster n',await p.$eval('.strip .count',x=>x.getAttribute('data-n')||x.textContent));await hs('dim');
await cl('button[data-aml="data"]');await cl('button[data-b="ratio:80/10/10"]');console.log(' data:',await p.$eval('.ref b',x=>x.textContent));await hs('data');
await cl('button[data-aml="train"]');console.log(' train:',await p.$$eval('.ref b',x=>x.map(y=>y.textContent).join(' / ')));
await cl('button[data-aml="data"]');await cl('button[data-b="ratio:60/20/20"]');await cl('button[data-aml="train"]');await cl('button[data-b="mode:manual"]');await cl('button[data-b="depth:4"]');console.log(' train ok:',await p.$eval('.note b',x=>x.textContent));await hs('train');
await cl('button[data-aml="cmp"]');const row=async()=>p.$eval('tr.rowsel',x=>x.innerText.replace(/\s+/g,' '));console.log(' cmp:',await row());
await cl('button[data-aml="out"]');await cl('button[data-act="amlfreeze"]');console.log(' freeze before recal:',await p.$eval('.ref b, .okb b',x=>x.textContent));
await cl('button[data-aml="cmp"]');await cl('button[data-b="recal:platt"]');console.log(' platt:',await row());
await cl('button[data-amlsort="cal"]');console.log(' first by calibration:',await p.$eval('tbody tr',x=>x.innerText.split('\t')[0]));
await cl('button[data-act="bpeek"]');console.log(' peek1:',await p.$eval('.wb b',x=>x.textContent));await cl('button[data-act="bpeek"]');console.log(' peek2:',await p.$eval('.ref b',x=>x.textContent));await hs('cmp');
if(vw[0]===1300){await p.evaluate(()=>scrollTo(0,0));await p.waitForTimeout(900);await p.screenshot({path:'shots/build-cmp.png',fullPage:true});}
await cl('button[data-aml="out"]');await cl('button[data-act="amlfreeze"]');console.log(' freeze after recal:',await p.$eval('.ref b, .okb b',x=>x.textContent));
await cl('button[data-aml="mli"]');await hs('mli');
await cl('button[data-act="breset"]');console.log(' reset:',await p.$eval('.verdict .big',x=>x.textContent));
console.log(' errors',e);await p.close();}
await b.close();})();
