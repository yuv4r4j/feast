const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const U='file://'+process.cwd()+'/demo/smokey-demo.html';
for (const vw of [[1300,900],[390,844]]){
const p=await b.newPage({viewport:{width:vw[0],height:vw[1]}});const e=[];p.on('pageerror',x=>e.push(x.message));
const go=async h=>{await p.goto(U+'#'+h);await p.evaluate(h=>{location.hash=h},h);await p.waitForTimeout(250);};
const hs=async t=>{const o=await p.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth);if(o)console.log('  HSCROLL',t);};
const txt=async s=>p.$eval(s,x=>x.textContent).catch(()=>'(none)');
const bottom=async()=>{const h=await p.evaluate(()=>document.body.scrollHeight);for(let y=0;y<=h;y+=300){await p.evaluate(y=>window.scrollTo(0,y),y);await p.waitForTimeout(40);}await p.waitForTimeout(500);};
console.log('==',vw[0]);
await p.goto(U);await p.click('#m-free');
// validator
await go('validator');await hs('validator');
await p.click('button[data-valov="0:ok"]');await p.click('button[data-valov="1:f"]');
await p.click('button[data-a="val.plan:x"]');console.log(' plan:',await txt('.ref b'));
await p.click('button[data-a="val.t_nov:on"]');console.log(' tests:',await p.evaluate(()=>[...document.querySelectorAll('p.mut b')].map(x=>x.textContent).filter(t=>/tests/.test(t)).join()));
await p.click('button[data-a="val.tol:0.010"]');console.log(' tol:',await p.evaluate(()=>[...document.querySelectorAll('.ref b')].map(x=>x.textContent).join(' || ')));
await p.click('button[data-a="val.tol:0.002"]');console.log(' tol .002:',await txt('.wb b'));
await p.click('button[data-a="val.chal:glm"]');await p.click('button[data-a="val.sample:nov"]');
console.log(' nov:',await p.evaluate(()=>[...document.querySelectorAll('.ref b')].map(x=>x.textContent).join(' || ')),'| lines',await p.$$eval('svg.ch path.ln',a=>a.length),'| bar',await txt('.verdict .big'));
await hs('validator after');await bottom();if(vw[0]===1300)await p.screenshot({path:'shots/ctl-validator.png',fullPage:true});
// approval reads validator state
await p.evaluate(()=>{location.hash='approval'});await p.waitForTimeout(250);await hs('approval');
console.log(' approval strip:',await p.$$eval('.strip .count',a=>a.map(x=>x.getAttribute('data-n')||x.textContent).join(',')));
await p.click('button[data-a="apr.exp:24"]');console.log(' exp:',await txt('.ref b'));
await p.click('button[data-a="apr.use:cap"]');await p.click('button[data-act="aprsolo"]');console.log(' solo:',await p.evaluate(()=>[...document.querySelectorAll('.ref b')].map(x=>x.textContent).join(' || ')));
await p.click('button[data-act="aprsign"]');console.log(' sign:',await txt('.okb p'));
// ops sees limit
await p.evaluate(()=>{location.hash='ops'});await p.waitForTimeout(250);await hs('ops');
console.log(' ops limit:',await p.evaluate(()=>[...document.querySelectorAll('dl.kv dd')].pop().textContent));
await p.click('button[data-a="ops.group:feed"]');console.log(' group rows:',await p.$$eval('table tbody tr.rowsel',a=>a.length));
await p.click('button[data-a="ops.mode:direct"]');console.log(' direct:',await txt('.ref b'));
await p.click('button[data-a="ops.mode:staged"]');await p.click('button[data-a="ops.share:25"]');await p.click('button[data-act="opsplan"]');console.log(' plan:',await txt('.okb b'),'|',await p.evaluate(()=>[...document.querySelectorAll('svg.ch text')].map(x=>x.textContent).filter(t=>/scored|Staged/.test(t)).join(' / ')));
await bottom();if(vw[0]===1300)await p.screenshot({path:'shots/ctl-ops.png',fullPage:true});
// owner
await p.evaluate(()=>{location.hash='owner'});await p.waitForTimeout(250);
console.log(' adj closed fields:',await p.$$eval('details.adj:not([open])',a=>a.length));
await p.click('details.adj>summary');await p.waitForTimeout(200);
await p.click('button[data-a="own.ew:0.15"]');console.log(' ew loose:',await txt('details.adj .ref b'));
await p.click('button[data-a="own.ew:0.08"]');console.log(' ew:',await p.evaluate(()=>[...document.querySelectorAll('details.adj .bfield p.mut')].map(x=>x.textContent).filter(t=>/alert/.test(t)).join()),'| open kept',await p.$$eval('details.adj[open]',a=>a.length));
await p.click('button[data-a="own.days:180"]');console.log(' days:',await txt('details.adj .ref b'));
await p.click('button[data-a="own.exp:fix"]');console.log(' exp:',await p.evaluate(()=>[...document.querySelectorAll('details.adj .bfield p.mut')].map(x=>x.textContent).filter(t=>/score goes/.test(t)).join()));
console.log(' summary:',await txt('details.adj>summary'));await hs('owner');await bottom();if(vw[0]===1300)await p.screenshot({path:'shots/ctl-owner.png',fullPage:true});
await p.evaluate(()=>{location.hash='homr'});await p.waitForTimeout(250);console.log(' homr h1:',await txt('h1'),'| items',await p.$$eval('article.item',a=>a.length));await hs('homr');
await p.evaluate(()=>{location.hash='ops'});await p.waitForTimeout(250);console.log(' ops ew note:',await txt('.note b'));
// hov
await p.evaluate(()=>{location.hash='hov'});await p.waitForTimeout(250);await p.click('details.adj>summary');await p.waitForTimeout(150);
console.log(' hov first:',await txt('details.adj tr.rowsel td'));await p.click('button[data-a="hov.rank:skill"]');console.log(' by skill:',await txt('details.adj tr.rowsel td'));
await p.click('button[data-a="hov.scope:target"]');console.log(' scope:',await txt('details.adj .ref b'));await p.click('button[data-a="hov.scope:deep"]');await hs('hov');
// policy
await p.evaluate(()=>{location.hash='policy'});await p.waitForTimeout(300);await hs('policy');
console.log(' pol dots',await p.$$eval('#l2unit .d',a=>a.length),'counts',await p.$$eval('.strip .count',a=>a.map(x=>x.getAttribute('data-n')||x.textContent).join(',')));
await p.click('button[data-act="polprop"]');console.log(' prop none:',await txt('.wb b'));
await p.click('button[data-a="pol.t1:15"]');await p.click('button[data-a="pol.t3:11"]');console.log(' counts',await p.$$eval('.strip .count',a=>a.map(x=>x.getAttribute('data-n')||x.textContent).join(',')),'|',await txt('.verdict .big'));
await p.click('button[data-a="pol.psi:0.08"]');await p.click('button[data-a="pol.bads:3000"]');await p.click('button[data-a="pol.cal:0.15"]');
console.log(' limits:',await p.evaluate(()=>[...document.querySelectorAll('.bfield p.mut')].map(x=>x.textContent).filter(t=>/watch or worse|QCE05/.test(t)).join(' | ')));
await p.click('button[data-act="polnow"]');console.log(' now:',await txt('.ref b'));await p.click('button[data-act="polprop"]');console.log(' prop:',await txt('.okb b'));
// scroll through steps, record dot positions per step
const pos=[];for(let i=0;i<4;i++){await p.click(`button[data-l2="${i}"]`);await p.waitForTimeout(1500);pos.push(await p.evaluate(()=>{const d=[...document.querySelectorAll('#l2unit .d')];const u=document.getElementById('l2unit').getBoundingClientRect();let out=0;d.forEach(x=>{const r=x.getBoundingClientRect();if(r.right>u.right+1||r.bottom>u.bottom+1)out++;});return d.slice(0,3).map(x=>x.style.left+'/'+x.style.top).join(' ')+' out:'+out+' on:'+[...document.querySelectorAll('.l2step')].findIndex(s=>s.classList.contains('on'))+' sticky:'+Math.round(u.top);}));
 if(vw[0]===1300&&(i===1||i===3))await p.screenshot({path:`shots/ctl-policy-${i}.png`});if(vw[0]===390&&i===2)await p.screenshot({path:`shots/ctl-policy-phone.png`});}
console.log(' steps:\n  '+pos.join('\n  '));
await p.evaluate(()=>{location.hash='l1'});await p.waitForTimeout(250);console.log(' l1 banner:',await txt('.wb b'));
// compliance
await p.evaluate(()=>{location.hash='compliance'});await p.waitForTimeout(250);await hs('compliance');
console.log(' cmp counts',await p.$$eval('.strip .count',a=>a.map(x=>x.getAttribute('data-n')||x.textContent).join(',')));
await p.click('button[data-a="cmp.thr:0.90"]');await p.click('button[data-a="cmp.fail:esc"]');await p.click('button[data-a="cmp.zip3:on"]');
console.log(' cmp counts',await p.$$eval('.strip .count',a=>a.map(x=>x.getAttribute('data-n')||x.textContent).join(',')),'red bars',await p.$$eval('rect.f-red',a=>a.length));
await p.click('button[data-act="cmpprop"]');console.log(' ',await txt('.okb b'));await bottom();if(vw[0]===1300)await p.screenshot({path:'shots/ctl-compliance.png',fullPage:true});
await p.evaluate(()=>{location.hash='automl'});await p.waitForTimeout(200);await p.click('button[data-aml="mli"]');console.log(' build phase 7:',await p.evaluate(()=>[...document.querySelectorAll('.strip .mut')].map(x=>x.textContent).filter(t=>/compliance/.test(t)).join()));
// audit
await p.evaluate(()=>{location.hash='audit'});await p.waitForTimeout(250);await hs('audit');
await p.click('button[data-a="aud.rule:ref"]');await p.click('button[data-a="aud.n:50"]');await p.click('button[data-act="auddraw"]');
console.log(' audit counts',await p.$$eval('.strip .count',a=>a.map(x=>x.getAttribute('data-n')||x.textContent).join(',')),'filled',await p.$$eval('.audg i.on',a=>a.length),'of',await p.$$eval('.audg i',a=>a.length),'rows',await p.$$eval('tbody tr',a=>a.length));
await p.click('button[data-act="audedit"]');console.log(' edit:',await txt('.ref b'));await p.click('button[data-act="audexp"]');console.log(' exp:',await txt('.okb b'));await hs('audit after');
if(vw[0]===1300)await p.screenshot({path:'shots/ctl-audit.png',fullPage:true});
// l0 lens
await p.evaluate(()=>{location.hash='l0'});await p.waitForTimeout(250);await p.click('button[data-a="svp.miss:on"]');await p.click('button[data-act="svprm"]');console.log(' l0:',await txt('.ref b'),'rows',await p.$$eval('table tbody tr',a=>a.length));await hs('l0');
// reset
await p.evaluate(()=>{location.hash='validator'});await p.waitForTimeout(250);await p.click('button[data-areset="val"]');console.log(' reset:',await txt('.verdict .big'));
// roles
for(const role of ['apr','comp','aud','homr','val']){await go('start');await p.click(`button[data-role="${role}"]`);await p.waitForTimeout(200);let steps=[];for(let i=0;i<10;i++){steps.push(await p.evaluate(()=>location.hash));await hs(role+' '+steps[steps.length-1]);const n=await p.$('.nextbar button.p[data-go]:not([data-go="start"])');if(!n)break;await n.click();await p.waitForTimeout(150);}console.log(' role',role,steps.join(' > '));}
console.log(' errors',e);await p.close();}
await b.close();})();
