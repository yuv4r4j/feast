const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();
for (const vw of [[1440,900],[390,844]]){
const p=await b.newPage({viewport:{width:vw[0],height:vw[1]}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await p.goto('file://'+process.cwd()+'/demo/smokey-demo.html');await p.waitForTimeout(400);
for(const r of ['start','l0','l2','l1','drift','model','feature','tier','automl','registry','owner','hov','ops','close']){await p.evaluate(h=>location.hash=h,r);await p.waitForTimeout(250);
 const o=await p.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,h:document.body.scrollHeight,tabs:getComputedStyle(document.getElementById('tabs')).display}));
 console.log(vw[0],r,o.sw>o.cw?'HSCROLL '+o.sw:'ok','height',o.h,'tabs',o.tabs);
 if(vw[0]===1440&&['start','drift','l0'].includes(r))await p.screenshot({path:`shots/demo-${r}.png`,fullPage:true});}
await p.click('#m-free');await p.waitForTimeout(200);console.log('free tabs',await p.evaluate(()=>getComputedStyle(document.getElementById('tabs')).display));
await p.evaluate(()=>location.hash='model');await p.waitForTimeout(200);
for(const id of ['XIE01','ACE03','ACE09','ACE05','QCE02']){await p.click(`button[data-pick="${id}"]`);await p.waitForTimeout(150);console.log(id,await p.$eval('.verdict',e=>e.textContent));}
console.log('errors',errs);await p.close();}
await b.close();})();
