const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();
for (const vw of [[1300,900],[390,844]]){
const p=await b.newPage({viewport:{width:vw[0],height:vw[1]}});const e=[];p.on('pageerror',x=>e.push(x.message));
await p.goto('file://'+process.cwd()+'/demo/smokey-demo.html#start');await p.waitForTimeout(500);
for(const role of ['svp','owner','dev','val','hov','homr','ops','apr','comp','aud']){
 await p.goto('file://'+process.cwd()+'/demo/smokey-demo.html#start');await p.waitForTimeout(200);
 await p.click(`button[data-role="${role}"]`);await p.waitForTimeout(200);
 let steps=[];for(let i=0;i<10;i++){const h=await p.evaluate(()=>location.hash);const sw=await p.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth);steps.push(h+(sw?'!HS':''));
  const n=await p.$('.nextbar button.p[data-go]:not([data-go="start"])');if(!n)break;await n.click();await p.waitForTimeout(150);}
 const end=await p.$eval('.nextbar .mut',x=>x.textContent).catch(()=>'');
 console.log(vw[0],role,steps.join(' > '),'|',end);}
await p.goto('file://'+process.cwd()+'/demo/smokey-demo.html#validator');await p.waitForTimeout(200);
await p.click('button[data-act="valapprove"]');console.log(await p.$eval('.ref b',x=>x.textContent));
await p.goto('file://'+process.cwd()+'/demo/smokey-demo.html#homr');await p.waitForTimeout(200);
await p.click('button[data-act="homrlower"]');console.log(await p.$eval('.ref b',x=>x.textContent));
await p.selectOption('#role','ops');await p.waitForTimeout(200);console.log('select ops ->',await p.evaluate(()=>location.hash));
if(vw[0]===1300){await p.goto('file://'+process.cwd()+'/demo/smokey-demo.html#start');await p.waitForTimeout(900);await p.screenshot({path:'shots/demo-roles.png'});}
console.log('errors',e);await p.close();}
await b.close();})();
