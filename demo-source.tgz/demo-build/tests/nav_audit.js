const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const U='file://'+process.cwd()+'/demo/smokey-demo.html';
for(const vw of [[1300,900],[390,844]]){const p=await b.newPage({viewport:{width:vw[0],height:vw[1]}});const e=[];p.on('pageerror',x=>e.push(x.message));
await p.goto(U);await p.waitForTimeout(300);await p.click('#m-free');await p.waitForTimeout(200);
const info=await p.evaluate(()=>{const t=document.getElementById('tabs');const a=[...t.querySelectorAll('a')];const r=t.getBoundingClientRect();return {n:a.length,scrollW:t.scrollWidth,clientW:t.clientWidth,overflow:getComputedStyle(t).overflowX,hiddenTabs:a.filter(x=>{const q=x.getBoundingClientRect();return q.right>r.right+1||q.left<r.left-1;}).map(x=>x.textContent),hdrH:document.querySelector('header.top').offsetHeight,hdrPos:getComputedStyle(document.querySelector('header.top')).position};});
console.log(vw[0],'tabs',JSON.stringify(info));
// routes: every go/link target exists
const routes=await p.evaluate(()=>[...document.querySelectorAll('#tabs a')].map(a=>a.getAttribute('href').slice(1)));
const bad=[];for(const r of routes){await p.evaluate(h=>{location.hash=h},r);await p.waitForTimeout(120);
 const o=await p.evaluate(()=>({tg:[...document.querySelectorAll('[data-go]')].map(x=>x.dataset.go),cur:document.querySelector('#tabs a[aria-current]')?.textContent,curVisible:(()=>{const t=document.getElementById('tabs'),c=t.querySelector('a[aria-current]');if(!c)return null;const q=c.getBoundingClientRect(),r=t.getBoundingClientRect();return q.left>=r.left-1&&q.right<=r.right+1;})(),scrollY:window.scrollY,tourTxt:document.getElementById('tour').textContent.slice(0,60),back:!!document.querySelector('[data-go]')}));
 o.tg.forEach(t=>{if(!routes.includes(t))bad.push(r+'->'+t);});
 if(o.curVisible===false)bad.push(r+': current tab not visible');}
console.log(' bad',JSON.stringify(bad));
// tour mode: off-path screen message; which routes unreachable from any tour
const cov=await p.evaluate(()=>{return null;});
// title / document.title per route, focus after nav, hash back button
await p.evaluate(()=>{location.hash='policy'});await p.waitForTimeout(150);await p.evaluate(()=>{location.hash='owner'});await p.waitForTimeout(150);await p.goBack();await p.waitForTimeout(200);
console.log(' back ->',await p.evaluate(()=>location.hash),'title',await p.title(),'focus',await p.evaluate(()=>document.activeElement.tagName));
// model link from owner table then way back
await p.evaluate(()=>{location.hash='owner'});await p.waitForTimeout(150);await p.evaluate(()=>window.scrollTo(0,3000));await p.click('button[data-model="XCE03"]');await p.waitForTimeout(700);
console.log(' after model link: hash',await p.evaluate(()=>location.hash),'scrollY',await p.evaluate(()=>scrollY),'h1',await p.$eval('h1',x=>x.textContent));
// tour mode on new screens
await p.click('#m-tour');await p.waitForTimeout(150);for(const r of ['approval','policy','compliance','audit','registry']){await p.evaluate(h=>{location.hash=h},r);await p.waitForTimeout(120);console.log(' tour@',r,'|',await p.$eval('#tour',x=>x.textContent.replace(/\s+/g,' ').slice(0,90)),'| tabs',await p.evaluate(()=>getComputedStyle(document.getElementById('tabs')).display));}
console.log(' errors',e.length);await p.close();}
await b.close();})();
