const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();for(const w of [1300,390]){const p=await b.newPage({viewport:{width:w,height:850}});const errs=[];p.on('pageerror',e=>errs.push(e.message));await p.goto('file://'+process.cwd()+'/demo/smokey-demo.html#trail');await p.waitForTimeout(500);
const T=async s=>(await p.locator(s).first().innerText().catch(()=>'-')).replace(/\n/g,' ').slice(0,230);
console.log(w,'h1:',await T('#view h1'));console.log(' sum:',await T('.verdict .big'));console.log(' rows',await p.locator('#view table').first().locator('tbody tr').count(),'bars',await p.locator('rect.gbar').count(),'all-model rows',await p.locator('#view table').nth(1).locator('tbody tr').count());
await p.click('[data-a="trail.kind:ref"]');await p.waitForTimeout(150);console.log(' refusals rows',await p.locator('#view table').first().locator('tbody tr').count(),'|',await T('#view table tbody tr'));
await p.click('[data-act="trailfix"]');await p.waitForTimeout(150);console.log(' fix:',await T('#view .ref'));
await p.click('[data-act="trailexp"]');await p.waitForTimeout(150);console.log(' exp:',await T('#view .okb'));
const k=await p.locator('#view table').nth(w===1300?1:0).locator('[data-trail]').first().getAttribute('data-trail').catch(()=>null);
await p.locator('#view [data-trail]').nth(3).click();await p.waitForTimeout(250);console.log(' picked:',await T('#view h1'));
await p.evaluate(()=>{location.hash='model'});await p.waitForTimeout(250);await p.locator('.nextbar [data-trail]').click();await p.waitForTimeout(400);console.log(' from model sheet ->',await p.evaluate(()=>location.hash),await T('#view h1'));
console.log(' agd',await p.locator('section.agd').count(),'hscroll',await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),'errors',errs);
if(w===1300){await p.evaluate(()=>{location.hash='trail'});await p.waitForTimeout(300);await p.evaluate(()=>{window.scrollTo(0,0)});await p.waitForTimeout(1200);await p.screenshot({path:'shots/trail-top.png'});await p.evaluate(()=>window.scrollTo(0,820));await p.waitForTimeout(1400);await p.screenshot({path:'shots/trail-mid.png'});}}
await b.close();})();
