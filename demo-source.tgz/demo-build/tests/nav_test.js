const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const U='file://'+process.cwd()+'/demo/smokey-demo.html';
for(const vw of [[1300,900],[1024,768],[390,844]]){const p=await b.newPage({viewport:{width:vw[0],height:vw[1]}});const e=[];p.on('pageerror',x=>e.push(x.message));
await p.goto(U);await p.waitForTimeout(300);await p.click('#m-free');await p.waitForTimeout(200);
const routes=await p.evaluate(()=>[...document.querySelectorAll('.jump option')].map(o=>o.value).filter((v,i,a)=>a.indexOf(v)===i));
let bad=[];for(const r of routes){await p.evaluate(h=>{location.hash=h},r);await p.waitForTimeout(110);
 const o=await p.evaluate(()=>{const t=document.querySelector('#tabs .navs'),c=t&&t.querySelector('a[aria-current]');const vis=el=>{if(!el)return false;const q=el.getBoundingClientRect();return q.width>0&&q.left>=0&&q.right<=innerWidth+1;};const phone=innerWidth<=760;
  return {cur:phone?vis(document.querySelector('#mini .jump')):vis(c),grp:phone?true:[...document.querySelectorAll('#tabs .navg a')].every(vis),hs:document.documentElement.scrollWidth>document.documentElement.clientWidth,tg:[...document.querySelectorAll('[data-go]')].map(x=>x.dataset.go),sel:document.querySelector('.jump').value,title:document.title,focus:document.activeElement.tagName};});
 if(!o.cur)bad.push(r+':current not visible');if(!o.grp)bad.push(r+':group hidden');if(o.hs)bad.push(r+':hscroll');if(o.sel!==r)bad.push(r+':jump shows '+o.sel);o.tg.forEach(t=>{if(!routes.includes(t))bad.push(r+'->'+t);});if(o.focus!=='H1')bad.push(r+':focus '+o.focus);}
console.log(vw[0],'routes',routes.length,'bad',JSON.stringify(bad),'hdr',await p.evaluate(()=>document.querySelector('header.top').offsetHeight));
// jump select
await p.selectOption(vw[0]<=760?'#mini .jump':'#jumpwrap .jump','policy');await p.waitForTimeout(250);console.log(' jump ->',await p.evaluate(()=>location.hash),'|',await p.title());
// phone: nav reachable after scrolling
await p.evaluate(()=>window.scrollTo(0,1500));await p.waitForTimeout(300);console.log(' after scroll: nav visible',await p.evaluate(()=>{const el=innerWidth<=760?document.getElementById('mini'):document.querySelector('header.top');const q=el.getBoundingClientRect();return q.top>=0&&q.bottom<=innerHeight&&q.height>0;}));
// lifecycle
await p.evaluate(()=>{location.hash='lifecycle'});await p.waitForTimeout(200);await p.click('button[data-lc="QCE03"]');await p.waitForTimeout(150);
console.log(' lifecycle:',await p.$eval('.verdict .big',x=>x.textContent.slice(0,60)),'stages',await p.$$eval('article.item',a=>a.length),'now',await p.$eval('article.item.now h4',x=>x.textContent));
await p.click('article.item.now button[data-go]');await p.waitForTimeout(200);console.log(' open stage ->',await p.evaluate(()=>location.hash));
// model back link
await p.evaluate(()=>{location.hash='owner'});await p.waitForTimeout(200);await p.evaluate(()=>{[...document.querySelectorAll('button[data-model="XCE03"]')].pop().click();});await p.waitForTimeout(600);
console.log(' model back link:',await p.$eval('#view .linkbtn',x=>x.textContent));await p.click('#view .linkbtn');await p.waitForTimeout(300);console.log('  ->',await p.evaluate(()=>location.hash));
// tour off-path
await p.click('#m-tour');await p.waitForTimeout(150);await p.evaluate(()=>{location.hash='policy'});await p.waitForTimeout(200);
console.log(' off-path:',await p.$eval('#tour',x=>x.textContent.replace(/\s+/g,' ').slice(30,200)));
await p.click('#tour button[data-role2]');await p.waitForTimeout(250);console.log('  switch ->',await p.evaluate(()=>location.hash),await p.$eval('#tour .stepno',x=>x.textContent));
if(vw[0]!==1024){await p.evaluate(()=>{location.hash='lifecycle'});await p.waitForTimeout(300);await p.evaluate(()=>scrollTo(0,0));await p.waitForTimeout(700);await p.screenshot({path:'shots/nav-'+vw[0]+'.png'});}
console.log(' errors',e);await p.close();}
await b.close();})();
