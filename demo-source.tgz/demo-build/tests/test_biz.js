const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const U='file://'+process.cwd()+'/demo/smokey-demo.html';
for(const vw of [[1300,900],[390,844]]){const p=await b.newPage({viewport:{width:vw[0],height:vw[1]}});const e=[];p.on('pageerror',x=>e.push(x.message));
const hs=async t=>{if(await p.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth))console.log('  HSCROLL',t);};
const txt=s=>p.$eval(s,x=>x.textContent).catch(()=>'(none)');const refs=()=>p.evaluate(()=>[...document.querySelectorAll('.ref b')].map(x=>x.textContent).join(' || '));
const cnt=()=>p.$$eval('.strip .count',a=>a.map(x=>x.getAttribute('data-n')||x.textContent).join(','));
const go=async h=>{await p.evaluate(h=>{location.hash=h},h);await p.waitForTimeout(220);await hs(h);};
const shot=async n=>{if(vw[0]!==1300)return;const h=await p.evaluate(()=>document.body.scrollHeight);for(let y=0;y<=h;y+=350){await p.evaluate(v=>scrollTo(0,v),y);await p.waitForTimeout(30);}await p.waitForTimeout(500);await p.screenshot({path:'shots/biz-'+n+'.png',fullPage:true});};
await p.goto(U);await p.waitForTimeout(300);await p.click('#m-free');console.log('==',vw[0]);
await go('campaign');console.log(' camp:',await cnt());
await p.click('button[data-act="campearly"]');console.log('  early:',await refs());
await p.click('button[data-act="campsim"]');await p.click('button[data-act="campsub"]');await p.click('button[data-act="campself"]');console.log('  self:',await refs());
await p.click('button[data-a="camp.line:15"]');await p.waitForTimeout(100);console.log('  after change state:',await p.evaluate(()=>[...document.querySelectorAll('.seg button[disabled][aria-pressed="true"]')].map(x=>x.textContent).join()),'h2:',await p.evaluate(()=>[...document.querySelectorAll('h2')].map(x=>x.textContent)[0]));
await p.click('button[data-act="campsim"]');await p.click('button[data-act="campsub"]');await p.click('button[data-act="campapp"]');console.log('  gate:',await refs());
await p.click('button[data-a="camp.line:10"]');await p.click('button[data-a="camp.h:6.5"]');console.log('  h6.5:',await cnt());for(const q of [['camp.v','800'],['camp.h','5.5'],['camp.obj','roa']]){await p.click(`button[data-a="${q[0]}:${q[1]}"]`);await p.waitForTimeout(60);console.log('   '+q.join('=')+':',await cnt());}await p.click('button[data-a="camp.v:600"]');await p.click('button[data-a="camp.h:6.5"]');await p.click('button[data-a="camp.obj:profit"]');await p.click('button[data-act="campsim"]');await p.click('button[data-act="campsub"]');await p.click('button[data-act="campapp"]');console.log('  approved:',await txt('.okb b'));await p.click('button[data-act="camprel"]');console.log('  released:',await txt('.okb p'));await hs('campaign end');await shot('campaign');
await go('livetest');const vd=()=>p.evaluate(()=>[...document.querySelectorAll('.verdict .big')].pop().textContent);console.log(' lt B:',await vd());
for(const c of ['A','C']){await p.click(`button[data-a="lt.cls:${c}"]`);await p.waitForTimeout(80);console.log('  '+c+':',await vd());}
await p.click('button[data-a="lt.cls:B"]');await p.click('button[data-a="lt.mde:1.0"]');await p.click('button[data-a="lt.acc:9000"]');console.log('  B 1.0/9000:',await vd(),'|',await p.evaluate(()=>[...document.querySelectorAll('.bfield p.mut b')].map(x=>x.textContent).join(' ; ')));
await p.click('button[data-act="ltnofreeze"]');console.log('  nofreeze:',await refs());await p.click('button[data-act="ltfreeze"]');await p.click('button[data-act="ltlaunch"]');await p.click('button[data-act="ltpeek"]');console.log('  peek:',await refs());
await p.click('button[data-a="lt.mde:0.5"]');console.log('  amend:',await refs(),'| mde still',await p.$eval('button[data-a^="lt.mde"][aria-pressed="true"]',x=>x.textContent));await shot('livetest');
await go('cycle');console.log(' cycle:',await txt('.verdict .big'),'| rects',await p.$$eval('svg.ch rect',a=>a.length));await p.click('button[data-a="cyc.view:stage"]');await hs('cycle stage');await shot('cycle');
await go('recal');console.log(' recal small:',await txt('.okb b'));
for(const d of ['medium','large','slope','immature']){await p.click(`button[data-a="rc.drift:${d}"]`);await p.waitForTimeout(80);console.log('  '+d+':',(await txt('.okb b'))+' / '+(await refs()));}
await p.click('button[data-a="rc.drift:small"]');await p.click('button[data-a="rc.runs:2"]');console.log('  runs 2:',await refs());await p.click('button[data-a="rc.runs:4"]');await shot('recal');
await go('research');await p.click('button[data-act="rsreg"]');console.log(' research reg:',await refs());await p.click('button[data-rs="2"]');await p.click('button[data-act="rsexp"]');console.log('  exp:',await refs());await p.click('button[data-act="rsprom"]');console.log('  prom expired:',await txt('.wb b'));await p.click('button[data-rs="0"]');await p.click('button[data-act="rsprom"]');console.log('  prom:',await txt('.okb b'));await shot('research');
await go('platform');console.log(' platform:',await cnt(),'tables',await p.$$eval('table',a=>a.length));await p.click('button[data-act="pfprom"]');await p.click('button[data-act="pfret"]');console.log('  ',await refs());await shot('platform');
await go('model');await p.click('button[data-agq="0"]');console.log(' agent:',(await txt('.note b')),'| sources',await p.$$eval('.note .linkbtn',a=>a.length));await p.click('button[data-agq="3"]');console.log('  act:',await refs());
await go('ops');await p.click('button[data-act="trigc"]');console.log(' trig:',await refs());
await go('lifecycle');console.log(' lifecycle types rows:',await p.evaluate(()=>[...document.querySelectorAll('table')].pop().querySelectorAll('tbody tr').length),'drawn/part/spec',await cnt());
// biz tour
await go('start');await p.click('button[data-role="biz"]');await p.waitForTimeout(200);let steps=[];for(let i=0;i<8;i++){steps.push(await p.evaluate(()=>location.hash));await hs('tour '+steps[i]);const n=await p.$('.nextbar button.p[data-go]:not([data-go="start"])');if(!n)break;await n.click();await p.waitForTimeout(150);}console.log(' biz tour',steps.join(' > '));
console.log(' errors',e);await p.close();}
await b.close();})();
