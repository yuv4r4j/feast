import re
old_tpl=open('backup-pre-controls/demo_tpl.html').read()
built=open('backup-pre-controls/smokey-demo.html').read()
pre,post=old_tpl.split('/*DATA*/')
assert built.startswith(pre) and built.endswith(post)
DATA=built[len(pre):len(built)-len(post)]
s=old_tpl
def rep(a,b,cnt=1):
    global s
    assert s.count(a)>=1,a[:70]
    s=s.replace(a,b,cnt)
# 1 remove old role views
for v in ['validator','homr','owner','hov','ops']:
    m=re.search(r'^V\.'+v+r'=function.*?(?=^V\.[a-z0-9]+=function|^var TABS=)',s,re.S|re.M)
    assert m,v; s=s[:m.start()]+s[m.end():]
# 2 insert logic
rep('var TABS=',open('controls_logic.js').read()+'\nvar TABS=')
# 3 tabs, tours, look, select
rep("['validator','Validator'],['homr','Head of model risk'],","['validator','Validator'],['approval','Approval'],['homr','Head of model risk'],['policy','Policy'],['compliance','Compliance'],['audit','Audit'],")
rep("['owner','Dispose of the XCE01 breach','Choose a disposition and record it. Then try closing a finding yourself.'],","['owner','Dispose of the XCE01 breach','Choose a disposition and record it. Then open Adjust: set an early warning, and correct the exposure behind your tier.'],")
rep("['validator','Your case file','Replicate the developer\\'s numbers, add the November sensitivity, try to approve.'],","['validator','Your case file','Review what the developer changed. Then choose your own sample and challenger: try November 2025.'],")
rep("['hov','One pod holds the backlog','Toggle the what-if: re-sequencing does not save 15 January.'],","['hov','One pod holds the backlog','Toggle the what-if. Then open Adjust: rank nominees your way and deepen the review.'],")
rep("['validator','What your validators see','Replication within tolerance; validators recommend, they do not approve.'],","['validator','What your validators see','Their own plan, sample and challenger; validators recommend, they do not approve.'],")
rep("['homr','Four decisions','Approve the re-tiering, then try to lower a tier: overrides only raise.'],","['homr','Your decisions','Approve the re-tiering, then try to lower a tier: overrides only raise.'],\n  ['policy','Set the policy, see what moves','Change a tier band, then scroll: the 40 squares regroup. Propose it; it needs a second approver.'],")
rep("['ops','Alerts needing action','Same two bureau features breach in all six models.'],","['ops','Alerts and your rollout plan','Group the six alerts by feed. Then choose how XCE05 rolls out; the digest and usage limit are fixed.'],")
rep("['feature','Feeds behind the alerts','One stale feature view and the bureau feed.']]}};","""['feature','Feeds behind the alerts','One stale feature view and the bureau feed.'],
  ['platform','Where each model runs','Endpoints, batch jobs and bureau platforms, each checked against the approval.']]},
 biz:{name:'Business lead, card strategy',who:'Faster, and provably so',steps:[
  ['cycle','Where the months go','Work, queues and waiting for outcomes, measured the same way for every release.'],
  ['livetest','What sets the test length','Three kinds of test. Only one fits inside six months.'],
  ['campaign','A campaign in hours, signed','Set the objective and hurdles, run the solver, then try to approve it yourself.'],
  ['recal','Recalibration that runs itself','Inside bounds model risk approved once. Outside them, a person decides.'],
  ['research','Research with one way out','Light on paperwork, strict on data.']]},
 apr:{name:'Approval authority',who:'Decide, with terms',steps:[
  ['approval','One decision waiting','See what the developer changed and what the validator made of it. Set the conditions as terms, then sign.'],
  ['validator','The validator\\'s evidence','Their own sample and challenger, next to the developer\\'s numbers.'],
  ['ops','Where your terms land','The usage limit you set is fixed on the rollout plan.']]},
 comp:{name:'Compliance, fair lending',who:'Set the test builders must pass',steps:[
  ['compliance','Your test, your level','Choose the measure, the level and what a failure does. The chart shows which models fall below.'],
  ['automl','Where builders meet it','Phase 7 of the model build shows your check as a limit; locked features come from your list.'],
  ['approval','Where approvers see it','The approval authority decides with the evidence in one place.']]},
 aud:{name:'Internal audit',who:'Test the record yourself',steps:[
  ['audit','Draw your own sample','Pick a period and a kind of event, draw a sample, then try to correct an event.'],
  ['registry','A control to test','An MLflow alias is never read as approval; a mismatch opens an exception.'],
  ['policy','Who can change the rules','A policy change needs a second approver and an effective date.']]}};""")
# placeholder
rep("validator:'Your numbers next to the developer\\'s. Then try to approve.',homr:'Four decisions; overrides only raise a tier.',","validator:'Four parts: what the developer changed, your plan, your sample and challenger, results. Pick November 2025.',approval:'Conditions are terms you choose, not free text. The 24-month option is refused.',homr:'Your decisions; overrides only raise a tier.',policy:'Change a band. The counts update, and the squares regroup as you scroll.',compliance:'Move the level: the bars below it turn red.',audit:'Draw a sample. Then try to correct an event.',")
rep("owner:'Record a choice, then try to close the finding yourself.',hov:'Tick the what-if. The date still slips.',ops:'Same two bureau features breach in all six models.',","owner:'Record a choice. Then open Adjust below the buttons.',hov:'Tick the what-if. Then open Adjust at the bottom.',ops:'Group alerts by feed. Then set the rollout plan; three values are fixed.',")
rep('<option value="ops">Model operations</option>','<option value="ops">Model operations</option><option value="apr">Approval authority</option><option value="comp">Compliance, fair lending</option><option value="aud">Internal audit</option><option value="biz">Business lead, card strategy</option>')
rep("l0:'Three items. Each has an owner and one button.'","l0:'Three items. Each has an owner and one button. At the bottom: what just missed.'")
# 4 handlers
rep("  if(d.valcase){","""  if(d.a){var ai=d.a.indexOf(':'),ak=d.a.slice(0,ai),av=d.a.slice(ai+1);if(d.ref){st.Atry[ak]=d.ref;render();return;}delete st.Atry[ak];st.A[ak]=av;var ap=ak.split('.')[0];bizReset(ap);if(ap==='pol'){st.polProp=false;st.polTry=false;}if(ap==='cmp')st.cmpProp=false;if(ap==='apr'){st.aprDone=false;st.aprTry=false;}if(ap==='ops'&&ak!=='ops.group')st.opsPlan=false;if(ap==='aud')st.audExp=false;if(ap==='own')st.ownerDone=false;render();return;}
  if(d.areset){[st.A,st.Atry].forEach(function(o){Object.keys(o).forEach(function(k){if(k.indexOf(d.areset+'.')===0)delete o[k];});});render();return;}
  if(d.valov){var vq=d.valov.split(':');st.valOv=st.valOv||{};st.valOv[+vq[0]]=vq[1];render();return;}
  if(d.act==='aprsign'){st.aprDone=true;st.aprTry=false;render();return;}
  if(d.act==='aprsolo'){st.aprTry=true;st.aprDone=false;render();return;}
  if(d.act==='opsplan'){st.opsPlan=true;render();return;}
  if(d.act==='polprop'){st.polProp=true;st.polTry=false;render();return;}
  if(d.act==='polnow'){st.polTry=true;render();return;}
  if(d.act==='cmpprop'){st.cmpProp=true;render();return;}
  if(d.act==='auddraw'){st.audSeed=(st.audSeed||0)+1;st.audExp=false;render();return;}
  if(d.act==='audexp'){if(!st.audSeed)st.audSeed=1;st.audExp=true;render();return;}
  if(d.act==='audedit'){st.audTry=true;render();return;}
  if(d.act==='svprm'){st.svpTry=true;render();return;}
  if(d.valcase){""")
# 5 toggle
rep("document.addEventListener('toggle',function(){scScan();},true);","document.addEventListener('toggle',function(e){var t=e.target;if(t&&t.dataset&&t.dataset.adj)st.adjOpen[t.dataset.adj]=t.open;scScan();},true);")
# 6 scroll kinds
rep("var anchor=kind==='draw'||kind==='grow'?","var anchor=kind==='draw'||kind==='grow'||kind==='growx'?")
rep("add('.gbar','grow',0.34);","add('.gbar','grow',0.34);add('.gbarx','growx',0.40);")
rep(",details.m,.note,.wb,.ref,.okb','fade',0.26);",",details.m,.note,.wb,.ref,.okb,.fig,details.adj,.audg','fade',0.26);")
rep("else if(it.kind==='grow'){it.el.style.transform='scaleY('+p.toFixed(3)+')';}","else if(it.kind==='grow'){it.el.style.transform='scaleY('+p.toFixed(3)+')';}\n    else if(it.kind==='growx'){it.el.style.transform='scaleX('+p.toFixed(3)+')';}")
rep("'Unit chart, step '+(cur+1)+' of 4'","'Unit chart, step '+(cur+1)+' of '+L.steps.length")
rep('''aria-label="Unit chart, step 1 of 4">'+labs+dots+'</div><figcaption class="mut">Filled square''','''aria-label="Unit chart, step 1 of 4"><div class="l2in">'+labs+dots+'</div></div><figcaption class="mut">Filled square''')
# 9 automl text
rep("""<span class="mut">threshold set by compliance</span>""","""<span class="mut">level '+ag('cmp.thr')+', set by compliance</span>""")
# 7 css
rep(".l2wrap{display:grid",""".kind{display:block;font-size:10.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;margin-top:5px;color:var(--muted)}
.kind.dec{color:var(--blue)}.kind.lim{color:var(--amber)}.kind.fix{display:inline;margin:0 0 0 6px}
.adjb{display:flex;flex-direction:column;gap:14px;padding:6px 0 4px 16px;border-left:3px solid var(--ink)}
details.adj>summary{font-size:15px}
.fig{margin:0;display:flex;flex-direction:column;gap:6px;min-width:0}
.fig svg.ch{max-width:620px}
.gbarx{transform-box:fill-box;transform-origin:0 50%}
svg.ch .f-blue{fill:var(--blue2)}
.verdict .btn{margin-left:auto}
.audg{display:grid;grid-template-columns:repeat(auto-fill,12px);gap:3px;max-width:620px}
.audg i{width:12px;height:12px;background:var(--hair);display:block}
.audg i.on{background:var(--ink)}
.unit.pol{height:300px}
.unit.pol .polin{position:absolute;left:0;top:0;width:330px;height:160px;transform-origin:0 0;transform:scale(1.7)}
.unit.pol .d{width:15px;height:15px}
.unit.pol .gl{font-size:8.5px;font-weight:600;white-space:nowrap}
.unit .d.k{background:var(--ink);border-color:var(--ink)}
.unit .d.tool{background:var(--rule);border-color:var(--rule)}
@media (max-width:1080px){.unit.pol .polin{transform:scale(1.3)}.unit.pol{height:240px}}
@media (max-width:760px){.unit.pol .polin{transform:scale(1)}.l2fig .unit.pol{height:190px}header.top{position:static}.l2fig{top:0!important}.l2in{position:absolute;left:0;top:0;width:540px;height:340px;transform-origin:0 0;transform:scale(.62)}.l2fig .unit:not(.pol){height:225px}}
h3{margin:8px 0 0;font-size:17px;font-weight:600;color:var(--ink)}
.l2wrap{display:grid""")
# ---- foundation models and Shapley values in the build studio
rep("V.automl=function(){var tab=st.aml||'prep',sel=st.amlSel||0;",open('tfm_logic.js').read()+"\nV.automl=function(){var tab=st.aml||'prep',sel=st.amlSel||0;")
rep("  '<div class=\"opts\"><button class=\"btn\" data-amltry=\"ens\">Try: allow an ensemble</button></div>'+","  '<div class=\"opts\"><button class=\"btn\" data-amltry=\"ens\">Try: allow an ensemble</button></div>'+")
rep("  (X.low.length?'<div class=\"ref\" role=\"alert\"><b>Training is blocked by phase 4 (rule AML-04).</b></div>':'<div class=\"note\"><b>Ready to train on '+X.n+' features and '+fmt(X.sets[0].rows)+' accounts.</b><p>Every setting from phases 1 to 5 is stored with the run.</p></div>');}","  (X.low.length?'<div class=\"ref\" role=\"alert\"><b>Training is blocked by phase 4 (rule AML-04).</b></div>':'<div class=\"note\"><b>Ready to train on '+X.n+' features and '+fmt(X.sets[0].rows)+' accounts.</b><p>Every setting from phases 1 to 5 is stored with the run.</p></div>')+tfmField(B,X,fmt);}")
rep("'<button class=\"linkbtn\" data-amlsel=\"'+i+'\">'+m.name+'</button>':m.name)+'</td>","'<button class=\"linkbtn\" data-amlsel=\"'+i+'\">'+m.name+'</button>':m.name)+(m.bench?' '+chip('Watch','benchmark'):'')+'</td>")
rep("  '<div class=\"opts\"><button class=\"btn\" data-act=\"bpeek\">Open the hold-out</button></div>'+","  tfmNote(X)+'<div class=\"opts\"><button class=\"btn\" data-act=\"bpeek\">Open the hold-out</button></div>'+")
import re as _r
m=_r.search(r" if\(tab==='mli'\)\{\n.*?\n if\(tab==='out'\)",s,_r.S);assert m
s=s[:m.start()]+" if(tab==='mli'){h+=shapPanel(X,sel,B);}\n if(tab==='out')"+s[m.end():]
rep("(st.amlFrozen?(bad?","(st.amlFrozen?(c2.bench?'<div class=\"ref\" role=\"alert\"><b>Not done. '+c2.short+' is a benchmark and cannot be frozen for a T2 model (rule AML-06).</b><p class=\"mut\">It has no monotonic constraints and its reason codes are approximate. Choose a candidate in phase 6.</p></div>':bad?")
rep("'</div>'):'');}\n return h;};","'</div>')):'');}\n return h;};") if False else None
rep("  if(d.amlsort){","  if(d.shapacc!==undefined){st.shapAcc=+d.shapacc;render();return;}\n  if(d.amlsort){")
rep("svg.ch .f-blue{fill:var(--blue2)}","svg.ch .f-blue{fill:var(--blue2)}\nsvg.ch .f-green{fill:var(--green)}")
rep("automl:'Eight phases. Change a setting and the counts update; the bar above counts your changes from the AutoML defaults.'","automl:'Eight phases. Phase 5 adds open-source foundation models as benchmarks; phase 7 shows Shapley values for any candidate and one applicant.'")
# ---- navigation and lifecycle hub
rep("['close','Proof']];","['close','Proof'],['lifecycle','Lifecycle'],['cycle','Cycle time'],['research','Research'],['platform','Platform'],['recal','Recalibration'],['livetest','Live test'],['campaign','Campaign'],['trail','Audit trail']];\n"+open('nav_logic.js').read()+'\n'+open('owner_output.js').read()+'\n'+open('biz_logic.js').read()+'\n'+open('trail_logic.js').read()+'\n'+open('agent_docs.js').read())
import re as _re
m=_re.search(r"document\.getElementById\('tabs'\)\.innerHTML=TABS\.map\(.*?\.join\(''\);",s,_re.S);assert m;s=s[:m.start()]+"document.getElementById('tabs').innerHTML=navHtml(r);"+s[m.end():]
m=_re.search(r"  else tour='<span class=\"lab\">'\+TOURS\[ROLE\]\.name\+' walkthrough</span><h3>'.*?</div>';",s,_re.S);assert m;s=s[:m.start()]+"  else tour=offPath(r);"+s[m.end():]
rep("document.getElementById('view').innerHTML=look+V[r]()+foot;scAfterRender(r);}","document.getElementById('view').innerHTML=look+V[r]()+foot;scAfterRender(r);navAfter(r,nx);}")
rep("  if(d.model){st.sel=d.model;go('model');return;}","  if(d.model){st.from=route();st.sel=d.model;go('model');return;}\n  if(d.lc){st.lc=d.lc;if(route()==='lifecycle')render();else go('lifecycle');return;}\n  if(d.role2){setRole(d.role2);MODE='tour';try{localStorage.setItem('smk-mode',MODE);}catch(x){}go(d.at);return;}")
rep("  if(d.valcase){","""  if(d.act==='campsim'){st.camp.state='Simulated';st.camp.tryMsg='';render();return;}
  if(d.act==='campsub'){st.camp.state='Submitted';st.camp.tryMsg='';render();return;}
  if(d.act==='campself'){st.camp.tryMsg='self';render();return;}
  if(d.act==='campearly'){st.camp.tryMsg='early';render();return;}
  if(d.act==='campapp'){if(+ag('camp.line')>10){st.camp.tryMsg='gate';}else{st.camp.state='Approved';st.camp.tryMsg='';}render();return;}
  if(d.act==='camprel'){st.camp.state='Released';st.camp.tryMsg='';render();return;}
  if(d.act==='ltfreeze'){st.lt={state:'Frozen',hash:hash8(ag('lt.cls')+ag('lt.mde')+ag('lt.acc')+ag('lt.early')),snap:{'lt.cls':ag('lt.cls'),'lt.mde':ag('lt.mde'),'lt.acc':ag('lt.acc'),'lt.early':ag('lt.early')}};render();return;}
  if(d.act==='ltnofreeze'){st.lt.tryMsg='nofreeze';render();return;}
  if(d.act==='ltlaunch'){st.lt.state='Live';st.lt.tryMsg='';render();return;}
  if(d.act==='ltpeek'){st.lt.tryMsg='peek';render();return;}
  if(d.rs!==undefined){st.rs={sel:+d.rs};render();return;}
  if(d.act==='rsprom'){st.rs.prom=st.rs.sel;st.rs.tryMsg='';render();return;}
  if(d.act==='rsreg'){st.rs.tryMsg='reg';render();return;}
  if(d.act==='rsexp'){st.rs.tryMsg='exp';render();return;}
  if(d.act==='pfprom'){st.pfTry=true;render();return;}
  if(d.act==='pfret'){st.pfRet=true;render();return;}
  if(d.act==='trigc'){st.trigTry=true;render();return;}
  if(d.agq!==undefined){st.agq=+d.agq;render();return;}
  if(d.trail){st.trail=d.trail;st.trailTry='';st.trailAll=false;if(route()!=='trail'){st.from=route();go('trail');}else{render();window.scrollTo({top:0,behavior:'auto'});}return;}
  if(d.act==='trailfix'){st.trailTry='fix';render();return;}
  if(d.act==='trailexp'){st.trailTry='exp';render();return;}
  if(d.act==='trailall'){st.trailAll=true;render();return;}
  if(d.agd){var q=d.agd.split(':');st.agd=st.agd||{};st.agd[q[0]]=q[1];render();return;}
  if(d.valcase){""")
rep("  if(d.valcase){","  if(d.oo){st.oo=d.oo;render();return;}\n  if(d.act==='ooprint'){window.print();return;}\n  if(d.valcase){")
rep("  if(e.target.id==='whatif')","  if(e.target.classList&&e.target.classList.contains('jump')){go(e.target.value);return;}\n  if(e.target.id==='whatif')")
rep("close:'A pass mark, and four decisions to start.'","close:'A pass mark, and four decisions to start.',trail:'One model, every entry in order. The summary is the sentence at the top; the table below compares all models.',lifecycle:'Fourteen stages. The bar shows where the chosen model stands; each stage opens its screen.',cycle:'Black is work, red is queue, grey is waiting for outcomes. Only red can be removed by process.',research:'Open the transaction sequence item. Its data grant has ended.',platform:'Two targets do not match the approval, and one is going stale.',recal:'Change what the outcome data shows. Inside the bounds it runs itself; outside, a person decides.',livetest:'Switch between A, B and C. The decision month moves; the outcome wait does not.',campaign:'Raise the hurdle or the line. Run the solver, then try to approve it yourself.'")
rep('<nav class="tabs" id="tabs" aria-label="Screens"></nav>','<nav class="tabs" id="tabs" aria-label="Screens"></nav>')
rep('</header>','</header>\n<div class="mini" id="mini"></div>')
rep("done=Math.min(docTop(anchor)-vh*0.92+span,maxS)","done=docTop(anchor)<vh?0:Math.min(docTop(anchor)-vh*0.92+span,maxS)")
rep('<label class="sel" for="role">','<span class="sel jw">Go to <span id="jumpwrap"></span></span>\n<label class="sel" for="role">')
rep("['start','A control plane, not a dashboard',","['lifecycle','The whole lifecycle first','Fourteen stages from identification to deletion. Pick a model; open any stage.'],\n  ['start','A control plane, not a dashboard',") if False else None
rep(".l2wrap{display:grid","""nav.tabs{display:block;overflow:visible;padding-block:6px 0}
nav.tabs .navg{display:flex;flex-wrap:wrap;gap:2px 4px}
nav.tabs .navg a{font-size:11px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;padding:6px 6px 4px;border-bottom:0;color:var(--muted)}
nav.tabs .navg a[aria-current]{color:var(--bg);background:var(--ink)}
nav.tabs .navs{display:flex;gap:4px;overflow-x:auto;scrollbar-width:thin;border-top:1px solid var(--rule)}
.mini{display:none}
.slide{border:1px solid var(--rule);border-top:3px solid var(--ink);padding:20px 24px;display:flex;flex-direction:column;gap:14px;background:var(--bg)}
.slide h3{margin:0;font-size:22px;font-weight:400;line-height:1.25}
.slideg{display:grid;grid-template-columns:minmax(0,1.9fr) minmax(0,1fr);gap:20px 36px;align-items:center}
.sliden{display:flex;flex-direction:column;gap:14px;font-size:17px;line-height:1.45}
.sliden p{margin:0}
.roadg{display:flex;flex-direction:column;gap:4px;border-top:1px solid var(--rule);padding-top:12px}
.roadg h4{margin:0;font-size:15px;font-weight:700;color:var(--blue)}
.roads{margin:0;font-size:13.5px;font-style:italic;color:var(--blue2)}
table.road{border-collapse:collapse;width:100%;font-size:13.5px;min-width:640px}
table.road th,table.road td{text-align:left;padding:5px 10px 5px 0;border:0;vertical-align:baseline;white-space:nowrap}
table.road thead tr:first-child th{font-size:13px;font-weight:700;border-bottom:2px solid var(--ink);text-transform:none;letter-spacing:0;color:var(--ink)}
table.road thead tr.sub th{font-style:italic;font-weight:400;color:var(--muted);text-transform:none;letter-spacing:0;font-size:13px}
table.road th.gap,table.road td.gap{width:28px;border:0!important}
table.road td.k{font-family:var(--mono);font-weight:500}
table.road sup{font-size:9px;color:var(--muted);margin-left:2px}
.slidef{margin:0;font-size:12.5px;font-style:italic;color:var(--muted)}
.slide svg.ch text{font-size:12px}.slide svg.ch text.v{font-size:13px}.slide svg.ch text.v.on{fill:var(--bg)}
@media (max-width:860px){.slideg{grid-template-columns:minmax(0,1fr)}}
@media print{body *{visibility:hidden!important}#ownerslide,#ownerslide *{visibility:visible!important}#ownerslide{position:absolute;left:0;top:0;width:100%;border:0}.gbarx{transform:none!important}.fig{opacity:1!important;transform:none!important}}
.jw select{max-width:170px}
#role{max-width:190px}
.tour{top:calc(var(--hdr,118px) + 14px)}
figure.l2fig{top:calc(var(--hdr,118px) + 16px)}
#view h1:focus{outline:none}
.item.now{border:2px solid var(--ink)}
@media (max-width:760px){nav.tabs,.jw{display:none!important}.mini{display:flex;gap:10px;align-items:center;position:sticky;top:0;z-index:6;background:var(--bg);border-bottom:1px solid var(--rule);padding:8px 16px}.mini select{flex:1 1 auto;min-width:0;min-height:44px}.mini .btn{min-height:44px}.l2fig{top:62px!important}}
.l2wrap{display:grid""")
s=s.replace("header.top{position:static}.l2fig{top:0!important}","header.top{position:static}")
# ---- weave the business and platform screens into the start page, role walkthroughs and existing screens
rep("['close','How we will know it works','A fifteen-minute test with five executives, and four decisions to start.']]}","['cycle','Where the months go','Approval to rollout, split into work, queue and waiting for outcomes.'],\n  ['close','How we will know it works','A fifteen-minute test with five executives, and four decisions to start.']]}")
rep("['tier','Your tier is changing','Find XCE01 and your other models in the transition grid.']]}","['tier','Your tier is changing','Find XCE01 and your other models in the transition grid.'],\n  ['recal','When your model recalibrates itself','Inside the bounds you are told afterwards. Try a large drift: a person decides first.'],\n  ['livetest','How long your replacement must be tested','XCE05 replacing XCE04. Pick the test class and read the decision month.']]}")
rep("['model','What validation will see','The tier card sets the depth of validation; the inventory record must be complete.']]}","['model','What validation will see','The tier card sets the depth of validation; the inventory record must be complete.'],\n  ['research','Before a model exists','Research items, data grants and the one gate that leads to a build.']]}")
rep("['tier','Depth follows the tier','T1 means full validation with replication.']]}","['tier','Depth follows the tier','T1 means full validation with replication.'],\n  ['livetest','The test plan you can hold them to','Frozen before launch. Try to change it, then try to decide early.']]}")
rep("['l1','Portfolio posture','Live models by in-force and proposed tier.']]}","['l1','Portfolio posture','Live models by in-force and proposed tier.'],\n  ['recal','The bounds you approve once','Set the envelope. Inside it runs are automatic; outside it they come to you.'],\n  ['platform','Where approvals can be bypassed','Pointers anyone with access can move, checked against what you approved.']]}")
rep("['ops','Where your terms land','The usage limit you set is fixed on the rollout plan.']]}","['ops','Where your terms land','The usage limit you set is fixed on the rollout plan.'],\n  ['campaign','Your limit, enforced in a campaign','Set the highest line to $15,000: the line model you approved stops at $10,000.']]}")
rep("['approval','Where approvers see it','The approval authority decides with the evidence in one place.']]}","['approval','Where approvers see it','The approval authority decides with the evidence in one place.'],\n  ['campaign','Checks before a list is released','Firm offer, ability to pay and record retention, checked on every scenario.']]}")
rep("['policy','Who can change the rules','A policy change needs a second approver and an effective date.']]}","['policy','Who can change the rules','A policy change needs a second approver and an effective date.'],\n  ['platform','Does production match the approval?','Two targets differ and one piece of evidence is stale.']]}")
rep("<button class=\"btn\" data-go=\"lifecycle\">See the 14-stage lifecycle →</button></div>';};})();","<button class=\"btn\" data-go=\"lifecycle\">See the 14-stage lifecycle →</button></div>'+\n '<h2>Around the model: what the business asked for and what IT proposed</h2><div class=\"g3\">'+[['cycle','Cycle time','Where the 12 to 18 months go: work, queue, waiting for outcomes.'],['livetest','Live test','Three kinds of test. One fits inside six months.'],['campaign','Campaign','An optimiser builds it; a committee signs the scenario.'],['recal','Recalibration','Automatic inside bounds model risk approved once.'],['research','Research','Light on paperwork, strict on data, one way out.'],['platform','Platform','Snowflake, batch, bureau hosting: each checked against the approval.']].map(function(x){return '<button class=\"note bizc\" data-go=\"'+x[0]+'\"><b>'+x[1]+' →</b><p>'+x[2]+'</p></button>';}).join('')+'</div>';};})();")
rep("#view h1:focus{outline:none}","#view h1:focus{outline:none}\n.unit.cyc .d{width:10px;height:10px;border-width:1px;cursor:default}.unit.cyc .gl{font-weight:600;white-space:nowrap}.dstat{padding:8px 14px;font-size:13px;border-left:6px solid var(--ink);background:var(--panel,rgba(127,127,127,.08))}.dstat.ill{border-left-style:dashed}.agd{border-left:6px solid var(--agent);background:var(--agentw);margin-top:28px;padding:16px 20px;display:flex;flex-direction:column;gap:12px}.agd .lab,.agd dl.kv dt{color:var(--agent)}.agd .note{border-left-color:var(--agent);background:var(--bg)}.agtag{display:inline-block;background:var(--agent);color:var(--bg);font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;padding:3px 8px;margin-right:8px;vertical-align:middle}h2.agh{border-bottom-color:var(--agent)}.note.ag{border-left:6px solid var(--agent);background:var(--agentw)}.agd ol{margin:8px 0 0;padding-left:20px}.agd li{margin:4px 0}button.bizc{font:inherit;text-align:left;cursor:pointer;color:inherit;min-height:44px}button.bizc:hover,button.bizc:focus-visible{outline:2px solid var(--ink);outline-offset:2px}\n.g3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}@media (max-width:760px){.g3{grid-template-columns:1fr}}")
assert s.count("--blue:#104683;")==1 and s.count("--blue:#8fb3ff;")==2
s=s.replace("--blue:#104683;","--agent:#6B2FA0;--agentw:#F3ECFA;--blue:#104683;").replace("--blue:#8fb3ff;","--agent:#c9a4ff;--agentw:#2a1f3a;--blue:#8fb3ff;")
# ---- R2D3 pass: table rows and agent blocks reveal on scroll; one JSON data block (spec 013)
rep("add(\'.rise,.strip>div,.item,.read,.rolecard,.verdict,details.m,.note,.wb,.ref,.okb,.fig,details.adj,.audg\',\'fade\',0.26)","add('.rise,.strip>div,.item,.read,.rolecard,.verdict,details.m,.note,.wb,.ref,.okb,.fig,details.adj,.audg,.agd,.tblw tbody tr,dl.kv,.bizc','fade',0.26)")
rep("<script>\n/*DATA*/\n</script>","<script id=\"smokey-data\" type=\"application/json\">/*DATA*/</script>\n<script>window.SMK=JSON.parse(document.getElementById('smokey-data').textContent);</script>")
import json as _json
_d=_json.load(open('smk.json'))
_d={'meta':{'schema':'smokey-data/1.0','source':'synthetic','as_of':'2026-11-20','environment':'','refreshed_by':'','refreshed_at':'','row_counts':{'models':len(_d['models']),'inventory':len(_d['inv']),'tier_models':len(_d['tier']['models'])}},**_d,
 'biz':{'cycle_releases':[['XCE04 v5.6',[5,2.5,2,1,3,1,2,12,2]],['ACE19 v2.3',[4,3,1.5,1,2.5,1,2,12,1.5]],['QCE01 v2.0',[6,4,2,1.5,4,1.5,3,12,2]],['ACE15 v3.4',[3,1.5,1.5,.5,2,1,1.5,6,1]],['XIE01 v4.0',[5,3.5,2,1,3,1,0,0,1]],['ACE18 v3.4',[3.5,2,1.5,.5,2.5,1,1.5,6,1]]],
        'campaign_segments':[[0.9,2.1,2.4,14],[1.1,2.8,3.1,12],[1.3,3.4,3.8,10],[1.6,4.1,4.4,8],[1.9,4.9,4.9,7],[2.2,5.8,5.1,6],[2.6,6.9,5.6,5],[3.0,8.2,5.4,4],[3.5,9.8,4.6,3],[4.1,11.9,2.0,2.5]]}}
DATA=_json.dumps(_d,separators=(',',':'),ensure_ascii=False).replace('</','<\\/')
# ---- focus shim: scripted screens resolve their example models from the data block (spec 013 FR-006)
rep("var TI={};S.tier.models.forEach(function(m){TI[m.id]=m;});","""var TI={};S.tier.models.forEach(function(m){TI[m.id]=m;});
var FOCUS=(S.meta&&S.meta.focus)||{};
(function(){var br=S.models.filter(function(m){return m.h==='Breach';}).sort(function(a,b){return a.tier-b.tier;});
 var pick=function(k,i){return byId[FOCUS[k]]?FOCUS[k]:((br[i]||S.models[i]||S.models[0]).id);};
 FOCUS.breach_model=(byId.XCE01&&!FOCUS.breach_model)?'XCE01':pick('breach_model',0);
 FOCUS.watch_model=(byId.XCE04&&!FOCUS.watch_model)?'XCE04':pick('watch_model',1);
 if(!byId.XCE01)byId.XCE01=byId[FOCUS.breach_model];if(!byId.XCE04)byId.XCE04=byId[FOCUS.watch_model];
 var t0=S.tier.models[0].id;if(!TI.XCE01)TI.XCE01=TI[FOCUS.breach_model]||TI[t0];
 FOCUS.tier_example=TI[FOCUS.tier_example]?FOCUS.tier_example:(TI.ACE05?'ACE05':t0);
 var has=function(k){return S.reg.some(function(r){return r.model_id===k;});},dis=S.reg.filter(function(r){return String(r.agrees_with_control_plane)==='false';})[0]||S.reg[0];
 FOCUS.registry_mismatch=has(FOCUS.registry_mismatch)?FOCUS.registry_mismatch:(has('MCD03')?'MCD03':dis.model_id);})();""")
rep("ownerTry:'',intake:'accept'};","ownerTry:'',intake:'accept'};\nst.sel=FOCUS.breach_model;st.tsel=FOCUS.tier_example;if(!S.feat.some(function(f){return f.f===st.feat;}))st.feat=S.feat[0].f;")
rep("var sel=TI[st.tsel]?st.tsel:'ACE05';","var sel=TI[st.tsel]?st.tsel:FOCUS.tier_example;")
rep("['XCE01','XCE04','XIE01','ACE03','ACE09','ACE05','QCE02'].map(function(x){return '<button class=\"btn'+(x===st.sel?' p':'')","(function(){var a=['XCE01','XCE04','XIE01','ACE03','ACE09','ACE05','QCE02'].filter(function(x){return byId[x]&&byId[x].id===x;});return a.length>=3?a:S.models.slice().sort(function(a,b){return a.tier-b.tier;}).slice(0,7).map(function(m){return m.id;});})().map(function(x){return '<button class=\"btn'+(x===st.sel?' p':'')")
rep("S.reg.filter(function(r){return r.model_id==='MCD03';})","S.reg.filter(function(r){return r.model_id===FOCUS.registry_mismatch;})")
rep("o=r13.filter(function(r){return String(r.control_plane_version)==='3.3';})[0],n=r13.filter(function(r){return String(r.control_plane_version)==='3.4';})[0];","o=r13.filter(function(r){return String(r.control_plane_version)==='3.3';})[0]||r13[0],n=r13.filter(function(r){return String(r.control_plane_version)==='3.4';})[0]||r13[r13.length-1];")
rep("<td>'+BRD.b[m.id].f.length+'</td>","<td>'+(BRD.b[m.id]?BRD.b[m.id].f.length:0)+'</td>")
rep("['platform','Does production match the approval?','Two targets differ and one piece of evidence is stale.']]}","['platform','Does production match the approval?','Two targets differ and one piece of evidence is stale.'],\n  ['trail','One model, start to finish','Read the summary, filter to refusals, then try to correct an entry.']]}")
rep("['livetest','How long your replacement must be tested','XCE05 replacing XCE04. Pick the test class and read the decision month.']]}","['livetest','How long your replacement must be tested','XCE05 replacing XCE04. Pick the test class and read the decision month.'],\n  ['trail','The record of your model','Every decision, refusal and automatic event on XCE01, with a one-line summary.']]}")
open('demo/demo_tpl.html','w').write(s)
assert s.count('/*DATA*/')==1
open('demo/smokey-demo.html','w').write(s.replace('/*DATA*/',DATA))
print(len(s))
